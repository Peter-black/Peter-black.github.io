Instructions for game:

In the menu press any key to start the game. After entering the game you may need to click on the 
window again for focus.

TETRIS CONTROLS:

LEFT - move tetromino left
RIGHT- move tetromino right
UP - rotate tetromino
DOWN - speed up tetromino
SPACE- slam the tetromino

BREAKOUT CONTROLS:

LEFT - move paddle left
RIGHT- move paddle right
SPACE - launch ball



~Peter Black 2014
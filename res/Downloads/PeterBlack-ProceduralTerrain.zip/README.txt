When you run the program it may take a few seconds to load. 
This is because the fracture based terrain is generating and 
it uses many iterations of the algorithm to generate better 
looking terrain.

-------Controls--------

-------Camera
WASD � Movement of the camera in each direction
QE � Descend and ascend the camera respectively
ARROWS � Tilting of the camera in each direction (looking around)

-------Effects
1 � Toggle Blur effect
2 � Toggle Saturation effect
3 � Toggle Wireframe mode
4 � Toggle Fracturing
5 � Toggle Simplex Noise
6 � Toggle Edge Detection

-------Adjustments
R � Generate new Simplex Seed
G/H � Adjust water tessellation
J/K � Adjust Saturation
N/M � Adjust Blur

-------Other
ESC - Exit
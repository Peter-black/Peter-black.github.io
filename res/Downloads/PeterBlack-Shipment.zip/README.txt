This is an OpenGL Demo of the shipment map from Call of Duty 4.

Its main features are, texturing, primative model generation, model loading, Camera, skyboxin and lighting.

Controls:

WASD: 			Walk around
Mouse Click & Drag: 	Look around
R: 			(un)Lock to head height
F:			Toggle Wireframe Mode
G:			Control Global lighting
H:			Spawn Circulating Spheres and Lights
Q/E:			Move Lights around the map


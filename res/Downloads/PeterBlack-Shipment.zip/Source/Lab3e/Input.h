#ifndef INPUT_H
#define INPUT_H
// Input class


#include <Windows.h>

class Input
{
	typedef struct Mouse
	{
		int x,y;
		int dx, dy;
		bool left, right;
	};

public:
	void SetKeyDown(WPARAM);
	void SetKeyUp(WPARAM);

	bool isKeyDown(int);
	void setMouseX(int);
	void setMouseY(int);
	void setMouseLeft(bool);
	int getMouseX();
	int getMouseY();
	int getMouseDX();
	int getMouseDY();
	bool getMouseLeft();

private:
	bool keys[256];
	Mouse mouse;
};

#endif
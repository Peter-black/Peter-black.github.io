#include <Windows.h>
#include "Vec3.h"
#include "Input.h"

class Camera{

public:
	Camera();
	~Camera();
	void Update();
	void HandleInput(Input* input, RECT* screenRect, float delta);

	void MoveForward(float speed);
	void MoveSide(float speed);
	void MoveYaw(float speed);
	void MovePitch(float speed);

	Vec3 getPosition();
	Vec3 getForward();
	Vec3 getLookAt();
	Vec3 getUp();
	Vec3 getRight();
	void setHeight(float height);
	void setSpeed(float speed);

private:
	Vec3 position;
	Vec3 forward;
	Vec3 lookAt;
	Vec3 up;
	Vec3 right;
	Vec3 rotation;
	float speed;
};
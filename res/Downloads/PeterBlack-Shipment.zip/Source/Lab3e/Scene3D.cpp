#include "Scene3D.h"

bool Scene3D::CreatePixelFormat(HDC hdc) 
{ 
    PIXELFORMATDESCRIPTOR pfd = {0}; 
    int pixelformat; 
 
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);	// Set the size of the structure
    pfd.nVersion = 1;							// Always set this to 1
	// Pass in the appropriate OpenGL flags
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER; 
    pfd.dwLayerMask = PFD_MAIN_PLANE;			// standard mask (this is ignored anyway)
    pfd.iPixelType = PFD_TYPE_RGBA;				// RGB and Alpha pixel type
    pfd.cColorBits = COLOUR_DEPTH;				// Here we use our #define for the color bits
    pfd.cDepthBits = COLOUR_DEPTH;				// Ignored for RBA
    pfd.cAccumBits = 0;							// nothing for accumulation
    pfd.cStencilBits = 0;						// nothing for stencil
 
	//Gets a best match on the pixel format as passed in from device
    if ( (pixelformat = ChoosePixelFormat(hdc, &pfd)) == false ) 
    { 
        MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK); 
        return false; 
    } 
 
	//sets the pixel format if its ok. 
    if (SetPixelFormat(hdc, pixelformat, &pfd) == false) 
    { 
        MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK); 
        return false; 
    } 
 
    return true;
}

void Scene3D::ResizeGLWindow(int width, int height)// Initialize The GL Window
{
	if (height==0)// Prevent A Divide By Zero error
	{
		height=1;// Make the Height Equal One
	}

	glViewport(0,0,width,height);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	//calculate aspect ratio
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height, 0.1 ,350.0f);

	glMatrixMode(GL_MODELVIEW);// Select The Modelview Matrix
	glLoadIdentity();// Reset The Modelview Matrix
}

void Scene3D::InitializeOpenGL(int width, int height) 
{  
    hdc = GetDC(*hwnd);//  sets  global HDC

    if (!CreatePixelFormat(hdc))//  sets  pixel format
        PostQuitMessage (0);


    hrc = wglCreateContext(hdc);	//  creates  rendering context from  hdc
    wglMakeCurrent(hdc, hrc);		//	Use this HRC.

	ResizeGLWindow(width, height);	// Setup the Screen
}

void Scene3D::Init(HWND* wnd, Input* in)
{
	hwnd = wnd;
	input = in;

	GetClientRect(*hwnd, &screenRect);	//get rect into our handy global rect
	InitializeOpenGL(screenRect.right, screenRect.bottom); // initialise openGL

	//OpenGL settings
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_COLOR_MATERIAL);						//Allow textures to interact with lights
	glEnable(GL_LIGHTING);								//Enable Lighting
	glEnable( GL_BLEND );								//Enable transparency and blending
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	cam = Camera();

	lightRotation = 0;
	wireframeMode = false;
	walkingMode = true;
	enableSun = true;
	enableBalls = false;

	//Load models and generate display lists
	car.Load("mdl/car_scrap.obj", "img/rust.png");
	lightSphere.Load("mdl/smallSphere.obj", "img/sphereTex.jpg"); 

	plane = shape.generatePlane(LoadTexture("img/Grass.jpg"),24,24,24,24,1,1);
	wall = shape.generatePlane(LoadTexture("img/wall.png"),24,2,10,1,2,1);
	skybox = shape.generateSkybox(LoadTexture("img/skybox.png"));

	containerBlue = shape.generateContainer(LoadTexture("img/container2.png"), 2);
	containerOneWallBlue = shape.generateContainer(LoadTexture("img/container2.png"), 1);
	containerRed = shape.generateContainer(LoadTexture("img/container.png"), 2);
	containerNoWallRed = shape.generateContainer(LoadTexture("img/container.png"), 0);
}

void Scene3D::DrawScene(float dt) 
{
	delta = dt;

	HandleInput();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);// Clear The Screen And The Depth Buffer
	glLoadIdentity();// load Identity Matrix

	//Update
	cam.Update();

	//Camera
	gluLookAt(cam.getPosition().getX(), cam.getPosition().getY(), cam.getPosition().getZ(),//Where we are, 
			  cam.getLookAt().getX(), cam.getLookAt().getY(), cam.getLookAt().getZ(),//What we look at, 
			  cam.getUp().getX(), cam.getUp().getY(), cam.getUp().getZ()); //which way is up

	//Wireframe Mode
	if(wireframeMode)glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
	else glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

	//Set up the sun's variables
	GLfloat Light_Ambient[] = {0.2f, 0.2f, 0.2f, 1.0f};
	GLfloat Light_Diffuse[] = {0.7f, 0.7f, 0.7f, 1.0f};
	GLfloat Light_Specular[] = {0.7f, 0.7f, 0.7f, 1.0};
	GLfloat Light_Position[]= {1.0f, 1.0f, 1.0f, 0.0f};

	//Set up the light for the flying balls
	GLfloat Moving_Light_Diffuse[] = {0.7f, 0.0f, 0.7f, 1.0f};
	GLfloat Moving_Light_Specular[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat Moving_Light_Position[]= {1.0f, 1.0f, 1.0f, 1.0f};

	//DIRECTIONAL LIGHT (SUN)
	glLightfv(GL_LIGHT0, GL_AMBIENT,  Light_Ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE,  Light_Diffuse);
	glLightfv(GL_LIGHT0, GL_POSITION, Light_Position);
	glLightfv(GL_LIGHT0, GL_SPECULAR, Light_Specular);
	
	//Turn the sun on and off
	if(enableSun)glEnable(GL_LIGHT0);
	else glDisable(GL_LIGHT0);

	//FLYING LIGHT
	if(lightRotation >= 360) lightRotation = 0;

	//Move in circle radius 7, around 12,12 the center of the grass
	float xPos = 7*cos(lightRotation / (180/3.141)) + 12;
	float yPos = 1;
	float zPos = 7*sin(lightRotation / (180/3.141)) - 12;

	Moving_Light_Position[0] = xPos;
	Moving_Light_Position[1] = yPos;
	Moving_Light_Position[2] = zPos;

	glLightfv(GL_LIGHT1, GL_DIFFUSE,  Moving_Light_Diffuse);
	glLightfv(GL_LIGHT1, GL_SPECULAR, Moving_Light_Specular);
	glLightfv(GL_LIGHT1, GL_POSITION, Moving_Light_Position);
	//Turn the balls on and off
	if(enableBalls)glEnable(GL_LIGHT1);
	else glDisable(GL_LIGHT1);

	if(walkingMode){
		cam.setHeight(1);
		cam.setSpeed(10);
	}else{
		cam.setSpeed(30);
	}

	//Draw Skybox
	glPushMatrix();
		glTranslatef(cam.getPosition().getX(), cam.getPosition().getY(), cam.getPosition().getZ());
		glCallList(skybox);
	glPopMatrix();

	//Draw Grass floor
	glPushMatrix();
		glRotatef(90, -1, 0, 0);
			glCallList(plane);
	glPopMatrix();

	//Draw Edge fence
	glPushMatrix();
		glPushMatrix();
			glTranslatef(0,0,-24);
			glCallList(wall);
		glPopMatrix();
		glRotatef(90,0,1,0);
		glCallList(wall);
		glRotatef(90,0,1,0);
		glTranslatef(-24,0,0);
		glCallList(wall);
		glRotatef(90,0,1,0);
		glTranslatef(-24,0,0);
		glCallList(wall);
	glPopMatrix();

	//Draw Flying lightballs
	if(enableBalls){
		glPushMatrix();
			glScalef(0.5f,0.5f,0.5f);
			glTranslatef(xPos*2, yPos*2 ,zPos*2);
				lightSphere.Render();
				//Second small ball orbits the big one
				glPushMatrix();
					glScalef(0.5f,0.5f,0.5f);
					glRotatef(lightRotation, 0, 1, 0);
					glTranslatef(5,0,0);
						lightSphere.Render();
				glPopMatrix();
		glPopMatrix();
	}

	//Draw cars
	glPushMatrix();
		glScalef(0.3f, 0.3f, 0.3f);
		glTranslatef(70, 0, -10);
		glRotatef(-45, 0, 1, 0);
			car.Render();
		glTranslatef(-35, 0, -40);
		glRotatef(120, 0, 1, 0);
			car.Render();
	glPopMatrix();

	//Draw center containers
	glPushMatrix();
		glTranslatef(8, 0.01f, -11);
		glCallList(containerBlue);
		glTranslatef(1.75f, 0, 0);
		glCallList(containerBlue);
		glTranslatef(3, 0, 0);
		glCallList(containerBlue);
		glTranslatef(0, 1.75f, 0);
		glCallList(containerBlue);
		glTranslatef(1.75f, 0, 0);
		glCallList(containerBlue);
		glTranslatef(0, -1.75f, 0);
		glCallList(containerBlue);
		glTranslatef(0, 0, -7);
		glCallList(containerBlue);
		glTranslatef(-1.75f, 0, 0);
		glCallList(containerBlue);
		glTranslatef(-3, 0, 0);
		glTranslatef(0, 1.75f, 0);
		glCallList(containerBlue);
		glTranslatef(-1.75f, 0, 0);
		glCallList(containerBlue);
		glTranslatef(0, -1.75f, 0);
		glCallList(containerBlue);
	glPopMatrix();

	//Draw center semi hollow container
	glPushMatrix();
		glTranslatef(11.5f, 0.01f, -13);
		glRotatef(180, 0, 1, 0);
			glCallList(containerOneWallBlue);
	glPopMatrix();

	//Draw top and bottom edge containers
	glPushMatrix();
		glRotatef(-90, 0, 1, 0);
		glTranslatef(-1.75f, 0.01f, -14.5f);
			glCallList(containerBlue);
		glTranslatef(-1.75f, 0, 0);
			glCallList(containerOneWallBlue);
	glPopMatrix();

	glPushMatrix();
		glRotatef(90, 0, 1, 0);
		glTranslatef(20.5f, 0.01f, 9.5f);
			glCallList(containerBlue);
		glTranslatef(1.75f, 0, 0);
			glCallList(containerOneWallBlue);
	glPopMatrix();

	//Draw Left and right edge containers
	glPushMatrix();
		glTranslatef(1.75f,0.01f,-14.5f);
		glRotatef(-20,0,1,0);
			glCallList(containerNoWallRed);
		glRotatef(20,0,1,0);
		glTranslatef(1.75,0,0);
			glCallList(containerRed);
		glTranslatef(15.25,0,0);
			glCallList(containerRed);
		glTranslatef(1.75f,0,0);
		glRotatef(20,0,1,0);
			glCallList(containerNoWallRed);
	glPopMatrix();

	SwapBuffers(hdc);// Swap the frame buffers.
}		

void Scene3D::Resize()
{
	if(hwnd == NULL)
		return;

	GetClientRect(*hwnd, &screenRect);	
	ResizeGLWindow(screenRect.right, screenRect.bottom);	
}

void Scene3D::HandleInput()
{
	//Camera input
	cam.HandleInput(input, &screenRect, delta);

	if(input->isKeyDown(0x46)){//F
		wireframeMode = !wireframeMode;
		input->SetKeyUp(0x46);
	}
	if(input->isKeyDown(0x47)){//G
		enableSun = !enableSun;
		input->SetKeyUp(0x47);
	}
	if(input->isKeyDown(0x51)){//Q
		lightRotation++;//Move the flying balls
	}
	if(input->isKeyDown(0x45)){//E
		lightRotation--;//Move the flying balls
	}
	if(input->isKeyDown(0x48)){//H
		enableBalls = !enableBalls;
		input->SetKeyUp(0x48);
	}
	if(input->isKeyDown(0x52)){//R
		walkingMode = !walkingMode;
		input->SetKeyUp(0x52);
	}
}

GLuint Scene3D::LoadTexture(char* filename)
{
	GLuint texture = SOIL_load_OGL_texture
	(
		filename,
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT | SOIL_FLAG_INVERT_Y
	);

	//check for an error during the load process
	if(texture==0 )
	{
		printf( "SOIL loading error: '%s'\n", SOIL_last_result() );
	}

	return texture;

}

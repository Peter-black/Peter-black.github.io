// Input class

#include "Input.h"

void Input::SetKeyDown(WPARAM key)
{
	keys[key] = true;
}

void Input::SetKeyUp(WPARAM key)
{
	keys[key] = false;
}

bool Input::isKeyDown(int key)
{
	return keys[key];
}

void Input::setMouseX(int pos)
{
	mouse.dx = mouse.x - pos;
	mouse.x = pos;
}

void Input::setMouseY(int pos)
{
	mouse.dy = mouse.y - pos;
	mouse.y = pos;
}

void Input::setMouseLeft(bool down)
{
	mouse.left = down;
}

int Input::getMouseX()
{
	return mouse.x;
}

int Input::getMouseY()
{
	return mouse.y;
}

int Input::getMouseDX()
{
	//Stops camera from drifting 
	//(mouse.dx can't be set to 0 because mouse pos doesn't update if staying still)
	int returnVal = mouse.dx;
	mouse.dx = 0;
	return returnVal;
}

int Input::getMouseDY()
{
	int returnVal = mouse.dy;
	mouse.dy = 0;
	return returnVal;
}

bool Input::getMouseLeft()
{
	return mouse.left;
}


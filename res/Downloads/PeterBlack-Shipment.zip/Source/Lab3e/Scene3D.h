#ifndef SCENE3D_H
#define SCENE3D_H

#include <windows.h>
#include <stdio.h>
#include <vector>
#include <mmsystem.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include "Input.h"
#include "Camera.h"
#include "Model.h"
#include "Shape.h"
#include "Vec3.h"

#define COLOUR_DEPTH 16	//Colour depth

class Scene3D
{
public:
	void Init(HWND*, Input*);	//initialse function
	void DrawScene(float);	// render scene
	void Resize();

protected:
	bool CreatePixelFormat(HDC);
	void ResizeGLWindow(int, int);	//width and height
	void InitializeOpenGL(int, int); // width and height
	void HandleInput();
	GLuint LoadTexture(char*);

	//vars
	HWND* hwnd;
	Input* input;
	RECT screenRect;
	HDC	hdc;
	HGLRC hrc;			//hardware RENDERING CONTEXT
	int s_wdith, s_height;
	float delta;
	//Different interaction states/commands
	bool wireframeMode, walkingMode;
	bool enableSun, enableBalls;
	
	Camera cam;
	Shape shape;//Shape generator
	Model car;
	Model lightSphere;
	float lightRotation;

	//Display Lists of objects
	GLuint skybox;
	GLuint plane, wall;
	GLuint containerBlue, containerOneWallBlue, containerRed, containerNoWallRed;
};

#endif
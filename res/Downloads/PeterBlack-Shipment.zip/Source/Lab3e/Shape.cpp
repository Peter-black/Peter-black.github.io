#include "Shape.h"

GLuint Shape::generateSkybox(GLuint texture){
	GLuint Skybox = glGenLists(1);
	glNewList(Skybox, GL_COMPILE);

		glBindTexture(GL_TEXTURE_2D, texture);
		glDisable(GL_DEPTH_TEST);//Skybox always rendered far away
		glDisable(GL_LIGHTING);//lights mess with the skybox
		glBegin(GL_QUADS);
			//(from inside)
			//front
			glNormal3f( 0.0f,  0.0f, 1.0f);
			glTexCoord2f(0.25f, 0.5f);
			glVertex3f(	-1.0, -1.0, -1.0);	
			glNormal3f( 0.0f,  0.0f, 1.0f);
			glTexCoord2f(0.5f, 0.5f);
			glVertex3f( 1.0, -1.0, -1.0);
			glNormal3f( 0.0f,  0.0f, 1.0f);
			glTexCoord2f(0.5f, 0.75f);
			glVertex3f( 1.0, 1.0, -1.0);
			glNormal3f( 0.0f,  0.0f, 1.0f);
			glTexCoord2f(0.25f, 0.75f);
			glVertex3f(	-1.0, 1.0, -1.0);	
			//left
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.5f);
			glVertex3f(	-1.0, -1.0, 1.0);	
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.25f, 0.5f);
			glVertex3f( -1.0, -1.0, -1.0);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.25f, 0.75f);
			glVertex3f( -1.0, 1.0, -1.0);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.75f);
			glVertex3f(	-1.0, 1.0, 1.0);	
			//back
			glNormal3f( 0.0f,  0.0f, -1.0f);
			glTexCoord2f(0.75f, 0.5f);
			glVertex3f(	1.0, -1.0, 1.0);	
			glNormal3f( 0.0f,  0.0f, -1.0f);
			glTexCoord2f(1.0f, 0.5f);
			glVertex3f( -1.0, -1.0, 1.0);
			glNormal3f( 0.0f,  0.0f, -1.0f);
			glTexCoord2f(1.0f, 0.75f);
			glVertex3f( -1.0, 1.0, 1.0);
			glNormal3f( 0.0f,  0.0f, -1.0f);
			glTexCoord2f(0.75f, 0.75f);
			glVertex3f(	1.0, 1.0, 1.0);
			//right
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.5f, 0.5f);
			glVertex3f(	1.0, -1.0, -1.0);	
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.75f, 0.5f);
			glVertex3f( 1.0, -1.0, 1.0);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.75f, 0.75f);
			glVertex3f( 1.0, 1.0, 1.0);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.5f, 0.75f);
			glVertex3f(	1.0, 1.0, -1.0);	
			//top
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.25f, 0.75f);
			glVertex3f(	-1.0, 1.0, -1.0);	
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.5f, 0.75f);
			glVertex3f( 1.0, 1.0, -1.0);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.5f, 1.0f);
			glVertex3f( 1.0, 1.0, 1.0);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.25f, 1.0f);
			glVertex3f(	-1.0, 1.0, 1.0);
			//bottom
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.25f, 0.25f);
			glVertex3f(	-1.0, -1.0, -1.0);	
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.5f, 0.25f);
			glVertex3f( 1.0, -1.0, -1.0);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.5f, 0.5f);
			glVertex3f( 1.0, -1.0, 1.0);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.25f, 0.5f);
			glVertex3f(	-1.0, -1.0, 1.0);
		glEnd();
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);
		glBindTexture(GL_TEXTURE_2D, NULL);

	glEndList();
	return Skybox;
}

GLuint Shape::generatePlane(GLuint texture, float width, float height, int divisionsX, int divisionsY, float texRepeatsX, float texRepeatsY)
{
	float triWidth = width/divisionsX;
	float triHeight = height/divisionsY;

	GLuint plane = glGenLists(1);
	glNewList(plane, GL_COMPILE);

	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glBegin(GL_TRIANGLES);

	for(int i = 0; i < divisionsX; i++){
		for(int j = 0; j < divisionsY; j++){

			glTexCoord2f(0,0);
			glNormal3f(0,0,1);
			glVertex3f(0 + (i*triWidth),0 + (j*triHeight),0);

			glTexCoord2f(texRepeatsX,0);
			glNormal3f(0,0,1);
			glVertex3f(triWidth + (i*triWidth),0 + (j*triHeight),0);

			glTexCoord2f(texRepeatsX,texRepeatsY);
			glNormal3f(0,0,1);
			glVertex3f(triWidth + (i*triWidth),triHeight + (j*triHeight),0);


			glTexCoord2f(0,0);
			glNormal3f(0,0,texRepeatsY);
			glVertex3f(0 + (i*triWidth),0 + (j*triHeight),0);

			glTexCoord2f(texRepeatsX,texRepeatsY);
			glNormal3f(0,0,1);
			glVertex3f(triWidth + (i*triWidth),triHeight + (j*triHeight),0);

			glTexCoord2f(0,texRepeatsY);
			glNormal3f(0,0,1);
			glVertex3f(0 + (i*triWidth),triHeight + (j*triHeight),0);
		}
	}

	glEnd();
	glBindTexture(GL_TEXTURE_2D, NULL);

	glEndList();

	return plane;
}

GLuint Shape::generateContainer(GLuint texture, int doors)
{
	float w = 1.75f;//width
	float h  = 1.75;//height
	float l = 5;//length
	
	GLuint container = glGenLists(1);
	glNewList(container, GL_COMPILE);

		glBindTexture(GL_TEXTURE_2D, texture);
		glBegin(GL_TRIANGLES);
			if(doors == 2){
				//front
				glNormal3f( 0.0f,  0.0f, -1.0f);
				glTexCoord2f(0.f, 0.333f);
				glVertex3f(0,0,0);
				glNormal3f( 0.0f,  0.0f, -1.0f);
				glTexCoord2f(0.333f, 0.333f);
				glVertex3f(w,0,0);
				glNormal3f( 0.0f,  0.0f, -1.0f);
				glTexCoord2f(0.333f, 0.6666f);
				glVertex3f(w,h,0);
				glNormal3f( 0.0f,  0.0f, -1.0f);
				glTexCoord2f(0.0f, 0.333f);
				glVertex3f(0,0,0);
				glNormal3f( 0.0f,  0.0f, -1.0f);
				glTexCoord2f(0.333f, 0.6666f);
				glVertex3f(w,h,0);
				glNormal3f( 0.0f,  0.0f, -1.0f);
				glTexCoord2f(0.0f, 0.6666f);
				glVertex3f(0,h,0);
			}
			//right
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(w,0,0);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.6666f);
			glVertex3f(w,0,l);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(w,h,l);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(w,0,0);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(w,h,l);
			glNormal3f( 1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(w,h,0);
			//back
			if(doors == 1 || doors == 2){
				glNormal3f( 0.0f,  0.0f, 1.0f);
				glTexCoord2f(0.333f, 0.333f);
				glVertex3f(w,0,l);
				glNormal3f( 0.0f,  0.0f, 1.0f);
				glTexCoord2f(0.6666f, 0.333f);
				glVertex3f(0,0,l);
				glNormal3f( 0.0f,  0.0f, 1.0f);
				glTexCoord2f(0.6666f, 0.6666f);
				glVertex3f(0,h,l);
				glNormal3f( 0.0f,  0.0f, 1.0f);
				glTexCoord2f(0.333f, 0.333f);
				glVertex3f(w,0,l);
				glNormal3f( 0.0f,  0.0f, 1.0f);
				glTexCoord2f(0.6666f, 0.6666f);
				glVertex3f(0,h,l);
				glNormal3f( 0.0f,  0.0f, 1.0f);
				glTexCoord2f(0.333f, 0.6666f);
				glVertex3f(w,h,l);
			}
			//left
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(0,0,l);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.6666f);
			glVertex3f(0,0,0);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0,h,0);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(0,0,l);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0,h,0);
			glNormal3f( -1.0f,  0.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0,h,l);
			//top
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(w,h,0);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(1.0f, 0.6666f);
			glVertex3f(w,h,l);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0,h,l);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(w,h,0);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0,h,l);
			glNormal3f( 0.0f,  1.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(0,h,0);
			//bot
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(0,0,0);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(1.0f, 0.6666f);
			glVertex3f(0,0,l);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(w,0,l);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.0f, 0.6666f);
			glVertex3f(0,0,0);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(w,0,l);
			glNormal3f( 0.0f,  -1.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(w,0,0);


		glEnd();

		glBindTexture(GL_TEXTURE_2D, NULL);
	glEndList();

	return container;
}




#include "Camera.h"

Camera::Camera(){
	position.set(2,1,-5);//set spawn point
	forward.set(0,0,1);
	lookAt.set(0,0,7);
	up.set(0,1,0);
	rotation.set(0,0,0);
	right.set(1,0,0);
	speed = 10;
}

Camera::~Camera(){
}

void Camera::Update(){
	float cosR, cosP, cosY;
	float sinR, sinP, sinY;	
	
	cosY = cosf(rotation.getX()*3.1415f/180);//Yaw
	cosP = cosf(rotation.getY()*3.1415f/180);//Pitch
	cosR = cosf(rotation.getZ()*3.1415f/180);//Roll
	sinY = sinf(rotation.getX()*3.1415f/180);
	sinP = sinf(rotation.getY()*3.1415f/180);
	sinR = sinf(rotation.getZ()*3.1415f/180);

	forward.setX(sinY * cosP);
	forward.setY(sinP);
	forward.setZ(cosP * -cosY);

	//LookAt point
	lookAt = position + forward;

	// Up Vector
	up.setX(-cosY * sinR - sinY * sinP * cosR);
	up.setY(cosP * cosR);
	up.setZ(-sinY * sinR - sinP * cosR * -cosY);

	// Side Vector
	right = forward.cross(up);
}

void Camera::HandleInput(Input* input, RECT* sRect, float dt){
	if(input->getMouseLeft()){
		MoveYaw(-input->getMouseDX()*50*dt);
		MovePitch(input->getMouseDY()*50*dt);
	}

	if(input->isKeyDown(VK_BACK)){
		exit(0);
	}
	if(input->isKeyDown(0x57)){//W key
		MoveForward(speed*dt);
	}
	if(input->isKeyDown(0x53)){//S key
		MoveForward(-speed*dt);
	}
	if(input->isKeyDown(0x41)){//A key
		MoveSide(-speed*dt);
	}
	if(input->isKeyDown(0x44)){//D key
		MoveSide(speed*dt);
	}
	
}

void Camera::MoveForward(float speed){
	position = position.add(forward, speed);
}

void Camera::MoveSide(float speed){
	position = position.add(right, speed);
}

void Camera::MoveYaw(float speed){
	rotation.setX(rotation.getX()+speed);
}

void Camera::MovePitch(float speed){
	rotation.setY(rotation.getY()+speed);
}

Vec3 Camera::getPosition(){
	return position;
}

Vec3 Camera::getForward(){
	return forward;
}

Vec3 Camera::getLookAt(){
	return lookAt;
}

Vec3 Camera::getUp(){
	return up;
}

void Camera::setHeight(float height){
	position.setY(height);
}

void Camera::setSpeed(float speed){
	this->speed;
}
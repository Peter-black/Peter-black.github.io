#ifndef _SHAPE_H_
#define _SHAPE_H_


// INCLUDES //
#include <Windows.h>
#include <fstream>
#include <gl/gl.h>
#include <gl/glu.h>
using namespace std;


class Shape
{

public:
	GLuint generateSkybox(GLuint texture);//Makes an inward facing unit cube with tex coords designed for cubemaps
	GLuint generatePlane(GLuint texture, float width, float height, int divisionsX, int divisionsY, float texRepeatsX, float texRepeatsY);//Like a customiseable piece of paper
	GLuint generateContainer(GLuint texture, int doors);//Makes a cuboid with certain faces missing depending on doors, mapped to container texture
};

#endif
This is a simple darts game for the GBA where you play against an opponent.
You take shots at the board first aiming for a number then choosing whether to
shoot for the single, double, triple or bull. Some random miss chance is applied
and you continue like a real darts game.
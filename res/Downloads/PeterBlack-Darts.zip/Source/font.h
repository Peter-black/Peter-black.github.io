/* Font tile data for AG0700.
 */

#ifndef FONT_H
#define FONT_H

#include <stdint.h>

// Bold 8x8 font.
// (From the X11 clB8x8 font.)
extern const uint8_t font_white[128][64];
extern const uint8_t font_green[128][64];
extern const uint8_t darts[2][64];

#endif

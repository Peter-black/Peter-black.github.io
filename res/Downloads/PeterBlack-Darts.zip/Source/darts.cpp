#include <stdint.h>
#include <stdlib.h>
#include <string>
#include <math.h>
#include "gba.h"
#include "font.h"
#include "dboard.h"

#define PI 3.14159265359

void drawDartBoard(int, int);
void drawDart(int, int, bool);
void clearDarts(bool);

void enterMenu(int);

std::string toString(int);
void drawText(int, int, std::string, int);
void clearText();

//-----PLAYER CLASS-----
class Player{
	bool won;
	int score;
	int bullChance, singleChance, multipleChance;

public:
	Player(int, int, int, int);
	bool shoot();					//Chooses ideal shot for player and attempts it. Returns true if it's a winning shot.
	bool playerShoot(int type, int number);
	int throwNumber(int);	//Returns result of attempt at throwing specific number
	int throwDouble(int);
	int throwTreble(int);
	int throwBull();				//Returns result of attempt at throwing a bull
	int getScore();
	void setScore(int);
	bool hasWon();
};
//-----PLAYER CLASS-----

const int NUM_SEGMENTS = 20;
int dartboard[] = {20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5}; //Contains the order of numbers on a dartboard

Player player(0,0,0,0);
Player sid(0,0,0,0);

bool playerTurn = true;
int dartNumber = 0;
bool numSelect = true;
bool typeSelect = false;
int selection = 0;
int aimedNumber = 0;

void init(){
	// Set display options.
	REG_DISPCNT = DCNT_MODE0 | DCNT_OBJ | DCNT_BG0 | DCNT_BG1 | DCNT_BG2 | DCNT_BG3;
	
	// Set background 0 options.
	REG_BG0CNT = BG_CBB(0) | BG_SBB(30) | BG_8BPP | BG_REG_32x32;
	REG_BG0HOFS = 0;
	REG_BG0VOFS = 0;
	// Set background 1 options.
	REG_BG1CNT = BG_CBB(0) | BG_SBB(29) | BG_8BPP | BG_REG_32x32;
	REG_BG1HOFS = 0;
	REG_BG1VOFS = 0;
	// Set background 2 options.
	REG_BG2CNT = BG_CBB(0) | BG_SBB(28) | BG_8BPP | BG_REG_32x32;
	REG_BG2HOFS = 0;
	REG_BG2VOFS = 0;
	// Set background 3 options.
	REG_BG3CNT = BG_CBB(0) | BG_SBB(27) | BG_8BPP | BG_REG_32x32;
	REG_BG3HOFS = 0;
	REG_BG3VOFS = 0;
	
	LoadTileData(0, 0, dboardTiles, dboardTilesLen);
	LoadPaletteBGData(0, dboardPal, dboardPalLen);
	
	LoadTileData(4, 0, font_white, 8192);
	LoadTileData(4, 128, font_green, 8192);
	LoadTileData(4, 256, darts, 128);
	LoadPaletteObjData(0, dboardPal, dboardPalLen);
	
	//Clear backgrounds
	for (int y = 0; y < 32; ++y){
	for (int x = 0; x < 32; ++x){
		SetTile(30, x, y, 0);
		SetTile(29, x, y, 50);
		SetTile(28, x, y, 0);
		SetTile(27, x, y, 0);
	}
	}
}

void gameInit(){
	ClearObjects();
	drawDartBoard(1,2);
	
	(&player)->~Player();
    new (&player) Player(501,70,80,50);
	
	(&sid)->~Player();
    new (&sid) Player(501,72,80,52);
	
	playerTurn = true;
	dartNumber = 0;
	numSelect = true;
	typeSelect = false;
	selection = 0;
	aimedNumber = 0;
}

int main()
{
	init();
	
	enterMenu(0);
	
	//GAME LOOP
	int keyPressCoolDown = 30;
	while (true)
	{	
		//INPUT
		keyPressCoolDown--;
		if(keyPressCoolDown <= 0)keyPressCoolDown = 0;
		
		if((REG_KEYINPUT & KEY_RIGHT) == 0 && keyPressCoolDown == 0){
			selection++;
			keyPressCoolDown = 3;
		}
		if((REG_KEYINPUT & KEY_LEFT) == 0 && keyPressCoolDown == 0){
			selection--;
			keyPressCoolDown = 3;
		}
		if((REG_KEYINPUT & KEY_A) == 0 && keyPressCoolDown == 0){
			if(numSelect){
				aimedNumber = dartboard[selection];
				numSelect = false;
				typeSelect = true;
				keyPressCoolDown = 10;
			}else if(typeSelect){
				player.playerShoot(selection, aimedNumber);
				if(dartNumber < 2){
					numSelect = true;
					dartNumber++;
				}else{
					playerTurn = false;
					dartNumber = 0;
					clearDarts(false);
				}
				
				typeSelect = false;
				selection = 0;
				aimedNumber = 0;
				keyPressCoolDown = 15;
			}
			
		}
		
		if(numSelect && selection < 0)selection = NUM_SEGMENTS-1;
		if(numSelect && selection >= NUM_SEGMENTS)selection = 0;
		if(typeSelect && selection < 0)selection = 3;
		if(typeSelect && selection > 3)selection = 0;
		
		//GAME
		if(!playerTurn){
			if(dartNumber < 3){
				sid.shoot();
				dartNumber++;
			}else{
				playerTurn = true;
				numSelect = true;
				dartNumber = 0;
				clearDarts(true);
			}
		}
		
		if(player.hasWon()){
			enterMenu(2);
		}
		if(sid.hasWon()){
			enterMenu(2);
		}
		
		
		//RENDER
		for(int i = 0; i < NUM_SEGMENTS; i++){
			float angle = ((2*PI)/20.0)*i;
			int xCoord = 70 * sin(angle);
			int yCoord = 70 * -cos(angle);
			if(65+xCoord <= 0)xCoord = -65;
			int colour = 0;
			if(numSelect && i == selection)colour = 1;
			drawText(65 + xCoord, 75 + yCoord, toString(dartboard[i]), colour);
		}
		
		drawText(165, 10, "Scores", 0);
		drawText(160, 25, "You:", 0);
		drawText(198, 25, toString(player.getScore()), 1);
		drawText(160, 40, "Sid:", 0);
		drawText(198, 40, toString(sid.getScore()), 1);
		
		if(playerTurn)drawText(155, 65, "Your turn", 1);
		else drawText(155, 65, "Sid's turn", 0);
		
		drawText(158, 77, "Dart No:", 0);
		if(!playerTurn)drawText(220, 77, toString(dartNumber), 1);
		else drawText(220, 77, toString(dartNumber+1), 1);
		
		
		if(typeSelect && selection == 0)drawText(165, 95, "SINGLE", 1);
		else drawText(165, 95, "SINGLE", 0);
		if(typeSelect && selection == 1)drawText(165, 110, "DOUBLE", 1);
		else drawText(165, 110, "DOUBLE", 0);
		if(typeSelect && selection == 2)drawText(165, 125, "TRIPLE", 1);
		else drawText(165, 125, "TRIPLE", 0);
		if(typeSelect && selection == 3)drawText(165, 140, "BULL", 1);
		else drawText(165, 140, "BULL", 0);
		
		WaitVSync();
		UpdateObjects();
		
		if(!playerTurn){
			for(int i = 0; i < 120; i++){
				WaitVSync();
			}
		}
		
		clearText();
	}

	return 0;

}

void drawDartBoard(int xLoc, int yLoc){
	for (int y = 0; y < 8; ++y){
		for (int x = 0; x < 8; ++x){
			SetTile(30, x+xLoc, y+yLoc, x +(y*8));//top-left segment
			SetTile(30, 8+x+xLoc, y+yLoc, ((7-x) +(y*8))| SE_HFLIP);//top-right segment
			SetTile(30, x+xLoc, 8+y+yLoc, (x +((7-y)*8))| SE_VFLIP);//bottom-left segment
			SetTile(30, 8+x+xLoc, 8+y+yLoc, ((7-x) +((7-y)*8))| SE_HFLIP | SE_VFLIP);//bottom-right segment
		}
	}
}

void drawDart(int numberHit,int multi, bool player){
	int play = 0;
	int dart = 256;
	int xRand = (rand() % 4) - 2;
	int yRand = (rand() % 4) - 2;
	if(!player){
		play = 3;
		dart = 257;
	}
	
	int distance = 0;
	
	switch(multi){
		case 0: distance = 45;
		break;
		case 1: distance = 57;
		break;
		case 2: distance = 35;
		break;
		case 3: distance = 0;
		break;
	}
	
	for(int i = 0; i < NUM_SEGMENTS; i++){
		if(dartboard[i] == numberHit || numberHit == 50){
		
			float angle = ((2*PI)/20.0)*i;
			int xCoord = distance * sin(angle);
			int yCoord = distance * -cos(angle);
		
			SetObject(dartNumber + play,
				ATTR0_SHAPE(0) | ATTR0_8BPP | ATTR0_REG | ATTR0_Y(75+yCoord+yRand),
				ATTR1_SIZE(0) | ATTR1_X(68+xCoord+xRand),
				ATTR2_ID8(dart));
				
			break;
		}
	}
}

void clearDarts(bool player){
	int play = 0;
	if(!player)play = 3;
	for(int i = 0; i < 3; i++){
		SetObject(i+play, ATTR0_HIDE, 0, 0);
	}
}

void enterMenu(int menu){
	for (int y = 0; y < 32; ++y){
		for (int x = 0; x < 32; ++x){
			SetTile(30, x, y, 0);
		}
	}
	clearDarts(true);
	clearDarts(false);

	bool active = true;
	int option = 0;
	int keyPressCoolDown = 30;
	
	//MENU LOOP
	while(active){
		keyPressCoolDown--;
		if(keyPressCoolDown <= 0)keyPressCoolDown = 0;
		clearText();
		switch(menu){
			case 0://Main menu
			if((REG_KEYINPUT & KEY_UP) == 0){
				option = 0;
			}
			if((REG_KEYINPUT & KEY_DOWN) == 0){
				option = 1;
			}
			if((REG_KEYINPUT & KEY_A) == 0 && keyPressCoolDown == 0){
				if(option == 0){
					active = false;
					gameInit();
				}else{
					menu = 1;
					keyPressCoolDown = 30;
				}
			}
			drawText(30,20,"Darts World Championship", 0);
			drawText(105,65,"PLAY", 0);
			drawText(75,90,"INSTRUCTIONS", 0);
			
			if(option == 0)drawText(90, 65, ">      <", 1);
			if(option == 1)drawText(60, 90, ">              <", 1);
			break;
			
			case 1://Credits
			if((REG_KEYINPUT & KEY_A) == 0 && keyPressCoolDown == 0){
				menu = 0;
				keyPressCoolDown = 30;
			}
			if((REG_KEYINPUT & KEY_B) == 0 && keyPressCoolDown == 0){
				menu = 0;
				keyPressCoolDown = 30;
			}
			
			drawText(10, 40, "INSTRUCTIONS:", 0);
			
			drawText(20,60, "LEFT  -", 1);
			drawText(84,60, "Cycle selections", 0);
			drawText(20,75, "RIGHT -", 1);
			drawText(84,75, "Cycle selections", 0);
			drawText(20,90, "A     -", 1);
			drawText(84,90, "Select", 0);

			drawText(15, 135, "created by Peter Black", 0);
			drawText(45, 145, "for C++ 2014", 0);
			break;
			
			case 2://Game Over
			if((REG_KEYINPUT & KEY_A) == 0 && keyPressCoolDown == 0){
				active = false;
				gameInit();
			}
			if((REG_KEYINPUT & KEY_B) == 0 && keyPressCoolDown == 0){
				menu = 0;
				ClearObjects();
				keyPressCoolDown = 30;
			}
		
			drawText(82,30,"GAME OVER", 0);
			drawText(45,60,"Your Score:", 0);
			drawText(140,60,toString(player.getScore()), 1);
			drawText(37,75,"Sid's Score:", 0);
			drawText(140,75,toString(sid.getScore()), 1);
			drawText(77, 125,"A = ", 1);
			drawText(109, 125,"Retry", 0);
			drawText(65, 135,"B = ", 1);
			drawText(97, 135,"Main Menu", 0);
			
			
			break;
		}
		
		
		WaitVSync();
		UpdateObjects();
	}
}

std::string toString(int number){
	int holder = number;
	
	int digits = 0; 
	
	do { holder /= 10; digits++; } while (holder > 0);
	char arr[digits+1];
	arr[digits] = 0;
	
	int divider = 1;
	for(int i = 0; i < digits; i++) divider *= 10;
	int value = 0;
	
	for(int i = 0; i < digits; i++){
		divider /= 10;
		
		int holder = number;
		value = holder/divider;
		
		arr[i] = (value%10) +48;
	}
	
	std::string str(arr);
	return str;
}

int activeLetters = 0;
void drawText(int x, int y, std::string string, int colour){
	int shift = 0;
	if(colour == 1)shift = 128;
	
	int startPos = activeLetters;
	
	for(int i = 0; i < string.length(); i++){
		activeLetters++;
		SetObject(startPos+i+6,
	          ATTR0_SHAPE(0) | ATTR0_8BPP | ATTR0_REG | ATTR0_Y(y),
			  ATTR1_SIZE(0) | ATTR1_X(x+(i*8)),
			  ATTR2_ID8(string.at(i) + shift));
	}
}

void clearText(){
	for(int i = 0; i < activeLetters; i++){
		SetObject(i+6, ATTR0_HIDE, 0, 0);
	}
	activeLetters = 0;
}


//=======PLAYER CLASS METHODS=======
Player::Player(int Score, int bullPercent, int singlePercent, int multiplePercent){
	score = Score;
	bullChance = bullPercent;
	singleChance = singlePercent;
	multipleChance = multiplePercent;
	won = false;
}


int Player::throwNumber(int number){
	if(number == 25){
		if(rand() % 100 < bullChance){
			return 25;
		}else{
			return dartboard[rand() % NUM_SEGMENTS];
		}
	}

	if(rand() % 100 < singleChance){//hit or miss
		return number;
	}else{//miss left or right
		for(int i = 0; i != number; i++){
			if(rand() % 2 == 0){
				if(i+1 > NUM_SEGMENTS-1) return dartboard[0];
				return dartboard[i+1];
			}else{
				if(i-1 < 0)return dartboard[NUM_SEGMENTS-1];
				return dartboard[i-1];
			}
		}
	}
return 0;//error catcher
}

int Player::throwDouble(int number){
	int accuracy = rand() % 100;
	if(accuracy < multipleChance){//hit or miss
		return number*2;
	}else if (accuracy < singleChance){
		return number;
	}else{//miss left or right
		for(int i = 0; i != number; i++){
			if(rand() % 2 == 0){
				if(i+1 > NUM_SEGMENTS-1) return dartboard[0];
				return dartboard[i+1];
			}else{
				if(i-1 < 0)return dartboard[NUM_SEGMENTS-1];
				return dartboard[i-1];
			}
		}
	}
return 0;//error catcher
}

int Player::throwTreble(int number){
	int accuracy = rand() % 100;
	if(accuracy < multipleChance){//hit or miss
		return number*3;
	}else if (accuracy < singleChance){
		return number;
	}else{//miss left or right
		for(int i = 0; i != number; i++){
			if(rand() % 2 == 0){
				if(i+1 > NUM_SEGMENTS-1) return dartboard[0];
				return dartboard[i+1];
			}else{
				if(i-1 < 0)return dartboard[NUM_SEGMENTS-1];
				return dartboard[i-1];
			}
		}
	}
return 0;//error catcher
}

int Player::throwBull(){
	if(rand() % 100 < bullChance){
		return 50;
	}else{
		return dartboard[rand() % NUM_SEGMENTS];
	}
}

bool Player::shoot(){
	int initScore = score;
	
	int throwVal = 0;
	bool dubOrBullWin = false;//makes sure win wasn't via a misfire

	if(score > 61){//Bring score down
		throwVal = throwTreble(20);
		if(throwVal == 20*3){
			drawDart(throwVal/3, 2, false);
		}else{
			drawDart(throwVal, 0, false);
		}
	}else if(score > 50){//carefully bring down
		int aimNum = floor(score/3);
		if(score - (aimNum*3) == 1)aimNum--;
		throwVal = throwTreble(aimNum);
		if(throwVal == aimNum*3){
			drawDart(throwVal/3, 2, false);
		}else{
			drawDart(throwVal, 0, false);
		}
	}else if(score == 50){//go for bullwin
		throwVal = throwBull();
		if(throwVal == 50){
			dubOrBullWin = true;
			drawDart(throwVal, 3, false);
		}else{
			drawDart(throwVal, 0, false);
		}
	}else if(score > 40){//even more carefully bring down
		int aimNum = floor(score/3);
		if(score - (aimNum*3) == 1)aimNum--;
		throwVal = throwTreble(aimNum);
		if(throwVal == aimNum*3){
			drawDart(throwVal/3, 2, false);
		}else{
			drawDart(throwVal, 0, false);
		}
	}else if(score % 2 == 0){//if even go for win
		int aimNum = floor(score/2);
		if(score - (aimNum*2) == 1)aimNum--;
		throwVal = throwDouble(aimNum);
		if(throwVal == aimNum*2){
			dubOrBullWin = true;
			drawDart(throwVal/2, 1, false);
		}else{
			drawDart(throwVal, 0, false);
		}
	}else{//make it even
		throwVal = throwNumber(1);
		drawDart(throwVal, 0, false);
	}

	score = initScore;//safety reset
	score -= throwVal;//update score
	if(score == 1 || score <= -1)score = initScore;//if not a clean finish
	if(score == 0 && !dubOrBullWin)score = initScore;//if not a clean finish
	
	if(score == 0 && dubOrBullWin){
		won = true;
		return true;
	}
	
	return false;
}

bool Player::playerShoot(int type, int number){
	int initScore = score;
	
	int throwVal = 0;
	bool dubOrBullWin = false;//makes sure win wasn't via a misfire
		
	switch(type){
		case 0: throwVal = throwNumber(number);
				drawDart(throwVal, 0, true);
		break;
		
		case 1: throwVal = throwDouble(number);
				if(throwVal == number*2){
					dubOrBullWin = true;
					drawDart(throwVal/2, 1, true);
				}else{
					drawDart(throwVal, 0, true);
				}
		break;
			
		case 2: throwVal = throwTreble(number);
				if(throwVal == number*3){
					drawDart(throwVal/3, 2, true);
				}else{
					drawDart(throwVal, 0, true);
				}
		break;
		
		case 3: throwVal = throwBull();
				if(throwVal == 50){
					dubOrBullWin = true;
					drawDart(50, 3, true);
				}else{
					drawDart(throwVal, 0, true);
				}
		break;
	}
	
	score -= throwVal;//update score
	if(score == 1 || score <= -1)score = initScore;//if not a clean finish
	if(score == 0 && !dubOrBullWin)score = initScore;//if not a clean finish
	
	if(score == 0 && dubOrBullWin){
		won = true;
		return true;
	}
	return false;
}

int Player::getScore(){
	return score;
}

void Player::setScore(int score){
	this->score = score;
}

bool Player::hasWon(){
	return won;
}
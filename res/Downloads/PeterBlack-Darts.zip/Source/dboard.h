
//{{BLOCK(dboard)

//======================================================================
//
//	dboard, 128x64@8, 
//	Transparent palette entry: 2.
//	+ palette 256 entries, not compressed
//	+ 128 tiles not compressed
//	Total size: 512 + 8192 = 8704
//
//	Time-stamp: 2014-05-18, 14:37:18
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.6
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_DBOARD_H
#define GRIT_DBOARD_H

#define dboardTilesLen 8192
extern const unsigned short dboardTiles[4096];

#define dboardPalLen 512
extern const unsigned short dboardPal[256];

#endif // GRIT_DBOARD_H

//}}BLOCK(dboard)

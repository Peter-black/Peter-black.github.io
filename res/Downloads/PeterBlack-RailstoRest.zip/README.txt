A short game questioning whether it's our material possessions that make us who we are, or, if it is in fact something deeper, something inside that makes us truly unique.

NOTE: When playing the game, characters can be spoken to multiple times so make sure to get the most out of every conversation! You will have to talk to other characters to trigger further conversations.
A #RainbowJam16 entry with the theme of Identity. As a team we wanted to make something that would get players thinking after they played the game. We wanted them questioning if they put too much value in material possessions and how they look, even questioning the way they treat others.

It's less than a weeks worth of work so don't judge too harshly :)

Controls:

WASD - Move your character

Enter - Interact

LMB - Interact, Select choices, Advance dialogue

Credits:

Programmers: Matthew Owens, Peter Black

Designer: Nik P. Balson

Character Art: Alissa Dolan (Frootsnak)

Environment Art: JL Brady (PixelBrady)

Spare Tool: Stuart McKie

intro sound effects are credited as:
https://www.freesound.org/people/smmassuda/sounds/136629/


package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class ExpBar extends Gui{

	public ExpBar() {
		look = Sprites.guiExp[0][3];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
	}
}
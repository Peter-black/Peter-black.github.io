package com.Lpb.Gui;

import com.Lpb.Game;
import com.Lpb.InputHandler;
import com.Lpb.Events.Rank;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Sprites.Sprite;

public class Gui {
	Sprite look;
	
	public static Gui holder = new Holder();
	public static Gui minimap = new MiniMap();
	public static Gui healthBar = new HealthBar();
	public static Gui healthFill = new HealthFill();
	public static Gui activeSlot = new ActiveSlot();
	public static Gui slot = new Slot();
	public static Gui expBar = new ExpBar();
	public static Gui expFill = new ExpFill();
	public static Gui crosshair = new Crosshair();

	public Gui(){
	}
	
	public void render(int xPos, int yPos, Screen screen) {
		
		int health = (int)(((double)Game.player.health/(double)100) * 78);
		int expFiller = (int)((double)(28)*(double)(Rank.getPercentageComplete()/(double)100));
		
		holder.render(8, screen.h - 88, screen);
		minimap.render(screen.w - 433 - Game.player.pX/16, screen.h -51- Game.player.pY/16, screen);
		
		healthBar.render(8, screen.h-96, screen);
		for(int i = 0; i < health; i++)healthFill.render(9+i,screen.h-96, screen);
		//healthFill.render(9, screen.h-95, screen);
		
		for(int i = 0; i < Inventory.maxItems; i++)slot.render(screen.w - 80, (screen.h-32)-(i*24)-0, screen);
		activeSlot.render(screen.w - 80, (screen.h-32)-(Inventory.selectedItem*24)-0, screen);
		
		expBar.render(screen.w/2 - 128, screen.h - 16, screen);
		for(int i = 0; i < expFiller; i++)expFill.render(screen.w/2 - 128 + i*9, screen.h - 16, screen);	
		
		crosshair.render((int)InputHandler.mX - 4, (int)InputHandler.mY - 4, screen);
		
		//HEALTH
		Font.drawString("Health", 8, Game.image.getHeight() - 104, -16777216, screen);
		Font.drawString(""+Game.player.health, 71, Game.image.getHeight() - 104, -16777216, screen);
		//EXP
		Font.drawString("EXP: " + Rank.exp + "/" + Rank.getLevelUpExp(Rank.rank), Game.image.getWidth()/2 - 120, Game.image.getHeight() - 25, -16777216, screen);
		Font.drawString("RANK: " + Rank.rank, Game.image.getWidth()/2 + 85, Game.image.getHeight() - 25, -16777216, screen);
		//ABOUT
		Font.drawString(Game.NAME, 1, 0, -16777216, screen);
		Font.drawString("X: "+Game.player.pX+" , Y: "+Game.player.pY, 1, 10, -16777216, screen);
		Font.drawString("FPS: "+ Game.fps, 1, 20, -16777216, screen);
	}
}

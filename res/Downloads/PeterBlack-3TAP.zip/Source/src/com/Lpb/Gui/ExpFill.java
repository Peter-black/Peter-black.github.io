package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class ExpFill extends Gui{

	public ExpFill() {
		look = Sprites.guiExpFill[0][2];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
	}
}
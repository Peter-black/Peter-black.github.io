package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class Holder extends Gui{

	public Holder() {
		look = Sprites.guiHolder[0][1];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
	}
}
package com.Lpb.Gui;

import com.Lpb.Game;
import com.Lpb.Entity.Mob;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class MiniMap extends Gui{

	public MiniMap() {	
	}
	
	public void render(int x, int y, Screen screen) {
		if(Game.currLevel.id == 0){
			look = Sprites.level[0][0];
		}
		else if(Game.currLevel.id == 1){
			look = Sprites.level1[0][0];
		}
		screen.renderRect(10, screen.h - 86, 76, 76, -16777216);
		screen.renderSprite(x, y, 10, screen.h - 86, 85, screen.h - 11, look);
		screen.renderRect(47, screen.h - 86 + 36, 1, 1, -16776961);
		
		for(int i = 0; i < Mob.mobs.length; i++){
    	for(int j = 0; j < Mob.mobNum; j++){
    		if(Mob.mobs[i][j] != null){
    			//if inside minimap box render mobs
    			if(47 + (Mob.mobs[i][j].x/16) - Game.player.pX/16 >= 10 &&
    			   47 + (Mob.mobs[i][j].x/16) - Game.player.pX/16 < 86){
    			if(screen.h - 86 + 36 + (Mob.mobs[i][j].y/16) - Game.player.pY/16 >= screen.h - 86 &&
    			   screen.h - 86 + 36 + (Mob.mobs[i][j].y/16) - Game.player.pY/16 < screen.h - 10){	
    				screen.renderRect(47 + (Mob.mobs[i][j].x/16) - Game.player.pX/16,screen.h - 86 + 36 + (Mob.mobs[i][j].y/16) - Game.player.pY/16, 1, 1, -65536);		
    			}
    			}
    		}
    	}
    	}
	}
}
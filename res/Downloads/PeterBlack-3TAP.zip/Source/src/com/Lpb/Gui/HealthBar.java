package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class HealthBar extends Gui{

	public HealthBar() {
		look = Sprites.guiHealth[0][1];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
	}
}
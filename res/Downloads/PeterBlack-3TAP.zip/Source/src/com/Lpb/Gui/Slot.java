package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class Slot extends Gui{

	public Slot() {
		look = Sprites.guiSlots[1][2];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
	}
}

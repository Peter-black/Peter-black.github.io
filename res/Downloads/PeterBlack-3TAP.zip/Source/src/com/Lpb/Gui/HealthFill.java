package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class HealthFill extends Gui{

	public HealthFill() {
		look = Sprites.guiHealthFill[10][0];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
		//int width = (int)(((double)Game.player.health/(double)100) * 78);
		//screen.renderRect(width, 6, x, y, -62872);
	}
}
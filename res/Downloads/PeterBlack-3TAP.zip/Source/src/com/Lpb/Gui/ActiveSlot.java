package com.Lpb.Gui;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class ActiveSlot extends Gui{

	public ActiveSlot() {
		look = Sprites.guiSlots[0][2];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, look);
	}
}
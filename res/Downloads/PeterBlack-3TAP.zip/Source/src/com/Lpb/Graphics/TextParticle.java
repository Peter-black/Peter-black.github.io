package com.Lpb.Graphics;

public class TextParticle extends Particle{

	public TextParticle(String message, int X, int Y, int color) {
		super(message, X, Y, color);
		msg = message;
		x = X;
		y = Y;
		col = color;
		xx = x;
		yy = y;
		zz = 2;//spawn height
		xa = random.nextGaussian() * 0.3;//x dir
		ya = random.nextGaussian() * 0.2;//y dir
		za = random.nextFloat() * 0.7 + 2;//spurt
	}

	public void tick() {
		time++;
		if(time > 60){
			remove = true;
		}
		xx += xa;
		yy += ya;
		zz += za;
		if (zz < 0) {
			zz = 0;
			za *= -0.5;//bounce
			xa *= 0.6;//x skid
			ya *= 0.6;//y skid
		}
		za -= 0.15;//gravity
		x = (int) xx;
		y = (int) yy;
	}

	public void render(int xOffs, int yOffs, Screen screen) {
		screen.setOffs(xOffs, yOffs);
		//Font.drawString(msg, x - msg.length() * 6, y, -16777216, screen);//shadow
		Font.drawString(msg, x - msg.length() * 6 + 1, y - (int) (zz) + 1, -16777216, screen);
		Font.drawString(msg, x - msg.length() * 6, y - (int) (zz), col, screen);
		screen.setOffs(0, 0);
	}

}

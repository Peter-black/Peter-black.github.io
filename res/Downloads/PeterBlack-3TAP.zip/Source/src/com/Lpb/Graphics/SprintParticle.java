package com.Lpb.Graphics;

public class SprintParticle extends Particle {
	
	public SprintParticle(int X, int Y, int width, int height, int dir, int color) {
		super(X,Y,width,height,dir,color);
		x = X;
		y = Y;
		w = width;
		h = height;
		col = color;
		xx = x;
		yy = y;
		zz = 2;//spawn height
		int xDirDiff = 0 , yDirDiff = 0;
		if(dir == 1)xDirDiff = -1;
		if(dir == 3)xDirDiff = 1;
		if(dir == 2)yDirDiff = -1;
		if(dir == 0)yDirDiff = 1;
		xa = random.nextGaussian() * 0.3 + xDirDiff;//x dir
		ya = random.nextGaussian() * 0.2 + yDirDiff;//y dir
		za = random.nextFloat();//spurt
	}

	public void tick() {
		time++;
		if(time > 20){
			remove = true;
		}
		xx += xa;
		yy += ya;
		zz += za;
		if (zz < 0) {
			zz = 0;
			za *= -0.1;//bounce
			xa *= 0.1;//x skid
			ya *= 0.1;//y skid
		}
		za -= 0.15;//gravity
		x = (int) xx;
		y = (int) yy;
	}

	public void render(int xOffs, int yOffs, Screen screen) {
		screen.setOffs(xOffs, yOffs);
		screen.renderRect(x - w, y - (int)(zz), w, h, col);
		screen.setOffs(0, 0);
	}

}

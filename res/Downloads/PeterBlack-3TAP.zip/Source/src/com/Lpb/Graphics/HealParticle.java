package com.Lpb.Graphics;

public class HealParticle extends Particle {
	
	public HealParticle(int X, int Y, int width, int height, int color) {
		super(X,Y,width,height,color);
		x = X;
		y = Y;
		w = width;
		h = height;
		col = color;
		xx = x;
		yy = y;
		zz = 1;//spawn height
		xa = random.nextGaussian() * 0.15;//x dir
		ya = random.nextGaussian() * 0.05;//y dir
		za = random.nextFloat() * 0.05;//spurt
	}

	public void tick() {
		time++;
		if(time > 40){
			remove = true;
		}
		xx += xa;
		yy += ya;
		zz += za;
		if (zz < 0) {
			zz = 0;
			za *= 0.5;//bounce
			xa *= -0.5;//x skid
			ya *= -0.5;//y skid
		}
		za += 0.01;//gravity
		x = (int) xx;
		y = (int) yy;
	}

	public void render(int xOffs, int yOffs, Screen screen) {
		screen.setOffs(xOffs, yOffs);
		screen.renderRect(x - w, y - (int)(zz), w, h, col);
		screen.setOffs(0, 0);
	}

}

package com.Lpb.Graphics;

import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Font {
	private static String chars = " " + //
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ" + //
			"abcdefghijklmnopqrstuvwxyz" + //
			"1234567890,.!?'()<>[]{}\\/" + //
			"~&%@*:;�$-+=_#^|�� ";
			//�� makes the infinity symbol.
	
	public static final int MENU_FONT = 0,
							DEFAULT_FONT = 1;
	
	private static Sprite[] picture = new Sprite[chars.length()-1];
	
	public static void drawString(String msg, int x, int y, int color, Screen screen){
		
		for(int i = 0; i < picture.length; i++){

			picture[i] = Sprites.font[i][0];
			
		}
		
		int j = 0;
		
		for (int i = 0; i < msg.length(); i++) {
			
			int ix = chars.indexOf(msg.charAt(i));
	
			if (ix >= 0) {	
				screen.renderSprite(x + j * 6, y, picture[ix], color, 0);
			}
			
			if(ix < 0){y += 10; j = -1;} // Carriage return values (-1 because j++ straight after);
			
			j++;
		}
	}
	
	public static void drawString(String msg, int x, int y, int color, int font, Screen screen){
		
		int gap = 6, hop = 10;
	
		switch(font){
		case DEFAULT_FONT: for(int i = 0; i < picture.length; i++)picture[i] = Sprites.font[i][0];
						   gap = 6;
						   hop = 10;
				break;
		case MENU_FONT: for(int i = 0; i < picture.length; i++)picture[i] = Sprites.menuFont[i][0];
						gap = 12;
						hop = 20;
				break;		 
		}
		
		int j = 0;
		
		for (int i = 0; i < msg.length(); i++) {
			
			int ix = chars.indexOf(msg.charAt(i));
	
			if (ix >= 0) {	
				screen.renderSprite(x + j * gap, y, picture[ix], color, 0);
			}
			
			if(ix < 0){y += hop; j = -1;} // Carriage return values (-1 because j++ straight after);
			
			j++;
		}
	}
}

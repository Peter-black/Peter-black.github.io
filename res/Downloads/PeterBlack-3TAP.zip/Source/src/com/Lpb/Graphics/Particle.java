package com.Lpb.Graphics;

import java.util.Random;

public class Particle {
	protected int time = 0;
	public boolean remove = false;

	protected String msg;
	protected int col;
	protected Random random = new Random();
	protected int x, y, w, h;
	protected double xa, ya, za, xx, yy, zz;

	public Particle(int X, int Y, int width, int height, int color) {
		x = X;
		y = Y;
		w = width;
		h = height;
		col = color;
		xx = x;
		yy = y;
		zz = 2;//spawn height
		xa = random.nextGaussian() * 0.3;//x dir
		ya = random.nextGaussian() * 0.2;//y dir
		za = random.nextFloat() * 0.7 + 2;//spurt
	}
	
	public Particle(String message, int X, int Y, int color) {
		msg = message;
		x = X;
		y = Y;
		col = color;
		xx = x;
		yy = y;
		zz = 2;//spawn height
		xa = random.nextGaussian() * 0.3;//x dir
		ya = random.nextGaussian() * 0.2;//y dir
		za = random.nextFloat() * 0.7 + 2;//spurt
	}
	
	public Particle(int X, int Y, int width, int height, int dir, int color) {
		x = X;
		y = Y;
		w = width;
		h = height;
		col = color;
		xx = x;
		yy = y;
		zz = 2;//spawn height
		int xDirDiff = 0 , yDirDiff = 0;
		if(dir == 1)xDirDiff = -1;
		if(dir == 3)xDirDiff = 1;
		if(dir == 2)yDirDiff = -1;
		if(dir == 0)yDirDiff = 1;
		xa = random.nextGaussian() * 0.3 + xDirDiff;//x dir
		ya = random.nextGaussian() * 0.2 + yDirDiff;//y dir
		za = random.nextFloat() * 0.7 + 1;//spurt
	}

	public void tick() {
		time++;
		if(time > 60){
			remove = true;
		}
		xx += xa;
		yy += ya;
		zz += za;
		if (zz < 0) {
			zz = 0;
			za *= -0.5;//bounce
			xa *= 0.6;//x skid
			ya *= 0.6;//y skid
		}
		za -= 0.15;//gravity
		x = (int) xx;
		y = (int) yy;
	}

	public void render(int xOffs, int yOffs, Screen screen) {
		screen.setOffs(xOffs, yOffs);
		//screen.renderRect(x - w, y, w, h, -16777216);//shadow
		//screen.renderRect(x - w + 1, y - (int)(zz) + 1, w, h, -16777216);
		screen.renderRect(x - w, y - (int)(zz), w, h, col);
		screen.setOffs(0, 0);
	}

}

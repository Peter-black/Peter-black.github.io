package com.Lpb;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Particle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Gui.Gui;
import com.Lpb.Sounds.Sound;
import com.Lpb.Entity.Mob;
import com.Lpb.Entity.Npc;
import com.Lpb.Entity.Player;
import com.Lpb.Entity.Troll;
import com.Lpb.Entity.Zombie;
import com.Lpb.Events.EventHandler;
import com.Lpb.Events.Rank;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Level.ItemMap;
import com.Lpb.Level.Level;
import com.Lpb.Menu.Menu;
import com.Lpb.Sprites.SpriteSheetLoader;
import com.Lpb.Sprites.Sprites;
import com.Lpb.Tiles.ParticleTile;
import com.Lpb.Tiles.Tile;

/*
 * @author Randor
 * @version 2.2
 */

public class Game extends Canvas implements Runnable {
	private static final long serialVersionUID = 1L;

	public static JFrame frame;
	public static int WIDTH = 960;
	public static int HEIGHT = 540;
	public static Dimension GAME_DIM = new Dimension(WIDTH, HEIGHT);
	public static String NAME = "3TAP Alpha[2.2]";
	public static Icon icon = new ImageIcon("res/icon.png");
	public static boolean fullscreen = false;
	public static boolean Vsync = true;
	public static BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
	public int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();

	public static SpriteSheetLoader loader;
	public static Screen screen;
	
	public static final Level LEVEL_ONE = new Level(1,64,64,Sprites.level1[0][0]);
	public static final ItemMap ITEMMAP_ONE = new ItemMap(1,64,64,Sprites.level1[1][0]);
	public static final Level LEVEL = new Level(0,16,16,Sprites.level[0][0]);
	public static final ItemMap ITEMMAP = new ItemMap(0,16,16,Sprites.level[1][0]);
	public static Level currLevel = LEVEL_ONE;
	public static Level[] levels = new Level[2];
	public static ItemMap currItemMap;
	public static ItemMap[] itemMaps = new ItemMap[levels.length];
	public static ArrayList<Particle> particles = new ArrayList<Particle>();
	
	public InputHandler input = new InputHandler(this);
	public static Player player;
	public static boolean zHB = false;
	public static Gui gui;
	public static Inventory inventory;
	
	public boolean running = false;
	public static int fps = 0;
	public static boolean paused = false;
	public static int xScroll = -192;
	public static int yScroll = -142;
	
	public static int tick = 0;
	
	//STATS
	public static int totalKills = 0;
	public static int totalDeaths = 0;
	public static int totalMoneyGained = 0;
	public static int totalMoneySpent = 0;

	public void start() {
		running = true;
		new Thread(this).start();
	}
	
	public void stop() {
		running = false;
	}
	
	public static void setPaused(boolean pause){
		paused = pause;
	}
	
	public static void toggleFullscreen(){
		if(!fullscreen){
			frame.setVisible(false);
			frame.dispose();	
			frame.setExtendedState(Frame.MAXIMIZED_BOTH);
			frame.setUndecorated(true);
			frame.setVisible(true);
			fullscreen = true;}
		else{
			frame.setVisible(false);
			frame.dispose();
			frame.setExtendedState(Frame.NORMAL);
			frame.setUndecorated(false);	
			frame.pack();
			frame.setVisible(true);
			frame.setLocationRelativeTo(null);	
			fullscreen = false;}
	}

	public Game() {
	}
	
	public void respawn() {
		player.dead = false;
		
		try {Write.load();} 
		catch (IOException e){
		try {Write.save();} catch (Exception e1) {e1.printStackTrace();}
		System.out.println("No save game found, creating new one...");
		e.printStackTrace();}
		catch (Exception e){
		e.printStackTrace();}
	}
	
	public static void resetGame() throws Exception {
		PrintWriter out = new PrintWriter("save/Player.sav");

	    out.println("\n");
	    out.println("0" + "\n");
	    out.println("40" + "\n");
	    out.println("20" + "\n");
	    out.println("-192" + "\n");
	    out.println("-142" + "\n");
	    out.println("100" + "\n");
	    out.println("0" + "\n");
	    out.println("1" + "\n");
	    out.println("666" + "\n");
	    out.println("666" + "\n");
	    out.println("666" + "\n");
	    out.println("\n");

	    out.close();
	    
	    try {Write.load();} 
		catch (IOException e) {
			e.printStackTrace();
			System.out.println("Creating new save file...");
			try {Write.save();} 
			catch (Exception e1) {e1.printStackTrace();}
		} 
		catch (Exception e) {
			System.out.println("Creating new save file...");
			e.printStackTrace();
			try {Write.save();} 
			catch (Exception e1) {e1.printStackTrace();}
		}
	}

	public static void init() {
		loader = new SpriteSheetLoader();
		screen = new Screen(WIDTH, HEIGHT);
		
		try{Sound.init();
		}catch(Exception e){
		e.printStackTrace();}

		setPaused(true);
			
		levels[0] = LEVEL;
		itemMaps[0] = ITEMMAP;
		levels[1] = LEVEL_ONE;
		itemMaps[1] = ITEMMAP_ONE;
		
		player = new Player();
		
		Npc.spawnNpc(Npc.CITIZEN, 2);
		
		Mob.spawnMob(Mob.TROLL, 2);
		Mob.spawnMob(Mob.ZOMBIE, 2);
		
		inventory = new Inventory();
		gui = new Gui();
		
		for(int i = 0; i < itemMaps.length; i++){
			itemMaps[i].loadMap(0, 0, 0, 0, itemMaps[i].levelSprite);
		}
		
		try {Write.load();} 
		catch (IOException e) {
			e.printStackTrace();
			System.out.println("Creating new save file...");
			try {Write.save();
				 Write.load();} 
			catch (Exception e1) {e1.printStackTrace();}
		} 
		catch (Exception e) {
			e.printStackTrace();
			try {Write.save();
				 Write.load();} 
			catch (Exception e1) {e1.printStackTrace();}
		}	

		try {Write.loadStats();} 
		catch (IOException e) {
			e.printStackTrace();
			System.out.println("Creating new stats save file...");
			try {Write.saveStats();
				 Write.loadStats();} 
			catch (Exception e1) {e1.printStackTrace();}
		} 
		catch (Exception e) {
			e.printStackTrace();
			try {Write.saveStats();
				 Write.loadStats();} 
			catch (Exception e1) {e1.printStackTrace();}
		}

		try {Write.loadPrefs();} 
		catch (IOException e) {
			e.printStackTrace();
			System.out.println("Creating new preferences save file...");
			try {Write.savePrefs();
				 Write.loadPrefs();} 
			catch (Exception e1) {e1.printStackTrace();}
		} 
		catch (Exception e) {
			e.printStackTrace();
			try {Write.savePrefs();
				 Write.loadPrefs();} 
			catch (Exception e1) {e1.printStackTrace();}
		}
		
		Menu.setMenu(Menu.SPLASH_SCREEN);
		//Menu.setMenu(Menu.TITLE_MENU);
	}

	public static void Screenshot(){
		Date date = new Date();
	    SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd-hh-mm-ss");
		File output = new File("screenshots/" + ft.format(date) + ".png");
		
		try {
			ImageIO.write(image, "png", output);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Screenshot: " + ft.format(date) + ".png " + "has been saved.");
	}

	public void run() {
		long lastTime = System.nanoTime();
		double unprocessed = 0;
		double nsPerTick = 1000000000.0 / 60;
		int frames = 0;
		int ticks = 0;
		long lastTimer1 = System.currentTimeMillis();

		try {
			init();
		} catch (Exception e1) {System.out.println("Failed to Initilize");}

		while (running) {
			long now = System.nanoTime();
			unprocessed += (now - lastTime) / nsPerTick;
			lastTime = now;
			boolean shouldRender;
			if(Vsync)shouldRender = false;
			else shouldRender = true;
			
			while (unprocessed >= 1) {
				input.tick();
				ticks++;
				tick();
				unprocessed -= 1;
				shouldRender = true;
			}

			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			if (shouldRender) {
				frames++;
				render();
			}

			if (System.currentTimeMillis() - lastTimer1 > 1000) {
				lastTimer1 += 1000;
				System.out.println(ticks + " ticks, " + frames + " fps");
				fps = frames;
				frames = 0;
				ticks = 0;
			}
		}
	}

	public void tick() {		
		if(!Game.paused){
			BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
			Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(
			    cursorImg, new Point(0, 0), "blank cursor");
			frame.getContentPane().setCursor(blankCursor);
		}else{
			frame.getContentPane().setCursor(Cursor.getDefaultCursor());
		}
		
		xScroll = player.pX - screen.w / 2;//some values to keep the camera looking at the player
		yScroll = player.pY - (screen.h - 16) / 2;
		
		if(player.pX < -1) player.pX = -1;
		if(player.pY < -4) player.pY = -4;
		
		if(xScroll < 0) xScroll = 0;
		if(yScroll < 0) yScroll = 0;	
		
		for(int i = 0; i < particles.size(); i++){
			if(particles.get(i) == null)continue;
			particles.get(i).tick();
			if(particles.get(i).remove)particles.remove(i);
		}
		
		if(paused == false){
			for(int i = 0; i < Mob.mobs.length; i++){
	    		for(int j = 0; j < Mob.mobNum; j++){
	    			if(Mob.mobs[i][j] != null)Mob.mobs[i][j].tick();
	    		}
	    	}
			
			for(int i = 0; i < Npc.npcs.length; i++){
	    		for(int j = 0; j < Npc.npcNum; j++){
	    			if(Npc.npcs[i][j] != null)Npc.npcs[i][j].tick();
	    		}
	    	}
			
			player.tick();
		}
		
		EventHandler.tick();
		Rank.tick();
		
		inventory.tick();
		
		for(int i = 0; i < Menu.menus.length; i++){
			if(Menu.menus[i].state)Menu.menus[i].tick();
		}
		
		tick++;
		if(tick >= 9999999)tick = 0;
	}

	public void render() {
		BufferStrategy bs = getBufferStrategy();
		if (bs == null) {
			createBufferStrategy(3);
			requestFocus();
			return;
		}

		currLevel.renderBackground(xScroll, yScroll, screen);
		currItemMap.render(xScroll, yScroll, screen);
		
		for(int i = 0; i < particles.size(); i++){
			if(particles.get(i) == null)continue;
			particles.get(i).render(xScroll, yScroll, screen);
		}
		
		try{
			for(int i = 0; i < Npc.npcs.length; i++){
	    	for(int j = 0; j < Npc.npcNum; j++){
	    		if(Npc.npcs[i][j] != null){
	    			Npc.npcs[i][j].render(xScroll, yScroll, screen);
	    		}
	    	}
	    	}	
		}catch(Exception e){
			System.out.println("Npc render Error.");
			e.printStackTrace();
		}
		 
		try{
			for(int i = 0; i < Mob.mobs.length; i++){
	    	for(int j = 0; j < Mob.mobNum; j++){
	    		if(Mob.mobs[i][j] != null){
	    			Mob.mobs[i][j].render(xScroll, yScroll, screen);
	    		}
	    	}
	    	}	
		}catch(Exception e){
			System.out.println("Mob render Error.");
			e.printStackTrace();
		}
		
		try{
			player.render(xScroll, yScroll, screen);
		}catch(Exception e){
			System.out.println("Player render Error.");
			e.printStackTrace();
		}
		
		//Renders Bullets so that they go under the gui. //Ammo.render(screen)?
		for(int i = 0; i < Inventory.inventory.length; i++){
			if(Inventory.inventory[i] != null ){
				for(int b = 0; b < Inventory.inventory[i].magsize; b++){
					if(Inventory.inventory[i].magazine.get(b) != null ){
						Inventory.inventory[i].magazine.get(b).render(screen);
					}
				}
			}
		}
		
		gui.render(0, 0, screen);
		inventory.render(0, 0, screen);	

		for(int i = 0; i < Menu.menus.length; i++){
			if(Menu.menus[i].state == true){
				Menu.menus[i].render(0, 0, screen);
			}
		}	
		
		EventHandler.render();
		
		if(!hasFocus()){		
			requestFocusInWindow();
			if(tick/20 % 2 == 0)Font.drawString("CLICK TO FOCUS!", screen.w - 90, 0, -16777216, screen);
			else Font.drawString("CLICK TO FOCUS!", screen.w - 90, 0, -1, screen);
		}

		for (int y = 0; y < screen.h; y++) {
			for (int x = 0; x < screen.w; x++) {
				pixels[x + y * WIDTH] = screen.pixels[x + y * screen.w];
			}
		}
		
		//Drawing buffered image to screen.
		Graphics g = bs.getDrawGraphics();
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		g.dispose();
		bs.show();
		
	}
	
	public static void changeLevel(Level Level){
		currLevel = Level;	
		player.changeLevel(currLevel);
		
		for(int i = 0; i < Npc.npcs.length; i++){
		   	for(int j = 0; j < Npc.npcNum; j++){
		   		if(Npc.npcs[i][j] != null){
		   			Npc.npcs[i][j].changeLevel(currLevel);
		   		}
	    }
	    }
		
	    for(int i = 0; i < Mob.mobs.length; i++){
	   	for(int j = 0; j < Mob.mobNum; j++){
	   		if(Mob.mobs[i][j] != null){
	   			Mob.mobs[i][j].changeLevel(currLevel);
	   		}
    	}
    	}
	    
	    currItemMap = itemMaps[currLevel.id];
	}
	
	public static String getDeathString(Object obj){
		if(obj == null)return "DIED!";
		
		if(obj.getClass() == Troll.class){
			obj = null;
			return "KILLED BY A TROLL";
		}else if(obj.getClass() == Zombie.class){
			obj = null;
			return "KILLED BY A ZOMBIE";
		}else if(obj.getClass() == ParticleTile.class){
			if(obj == Tile.fireTile){
				obj = null;
				return "BURNT TO DEATH";
			}
			obj = null;
			return "PARTICLE TILE";
		}
		
		return "DIED!";
	}

	public static void main(String[] args) {	
		Game game = new Game();
		
		game.setPreferredSize(GAME_DIM);
		game.setMaximumSize(GAME_DIM);
		game.setMinimumSize(GAME_DIM);

		frame = new JFrame(NAME);
		frame.setIconImage(((ImageIcon) icon).getImage());
		frame.setLayout(new BorderLayout());
		frame.add(game, BorderLayout.CENTER);
		frame.pack();	
		frame.setVisible(true);
		frame.setResizable(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		game.start();
	}
}
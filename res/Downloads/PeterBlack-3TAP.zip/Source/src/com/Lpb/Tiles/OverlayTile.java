package com.Lpb.Tiles;

import com.Lpb.Game;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class OverlayTile extends Tile {

	Sprite OverlayLeft, OverlayTop, OverlayRight, OverlayBottom;
	
	public OverlayTile(int id, boolean collide, int color) {
		super(id, collide, color);
		
		int x = (id+1)%32;
		int y = ((id+1)-x)/32;
		OverlayLeft = Sprites.tileOverlayVert[x*8][y];
		OverlayTop = Sprites.tileOverlayHorz[id+1][y];
		OverlayRight = Sprites.tileOverlayVert[(x*8)+7][y];
		OverlayBottom = Sprites.tileOverlayHorz[id+1][y+7];
	}

	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x * tile.w, y * tile.h, tile);
		if(Game.currLevel.getTile(x, y-1) != this){
			screen.renderSprite(x* tile.w, y * tile.h, OverlayTop);
		}
		if(Game.currLevel.getTile(x+1, y) != this){
			screen.renderSprite(x* tile.w+28, y * tile.h, OverlayRight);
		}
		if(Game.currLevel.getTile(x, y+1) != this){
			screen.renderSprite(x* tile.w, y * tile.h+28, OverlayBottom);
		}
		if(Game.currLevel.getTile(x-1, y) != this){
			screen.renderSprite(x* tile.w, y * tile.h, OverlayLeft);
		}
	}
	
}
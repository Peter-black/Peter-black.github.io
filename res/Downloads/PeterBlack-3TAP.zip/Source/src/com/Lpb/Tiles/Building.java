package com.Lpb.Tiles;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class Building extends Tile {
	
	public static int xCoord = 192, yCoord = 128;
	
	public Building(int id, boolean collide, int color) {
		super(id, collide, color);

		tile = Sprites.buildings[0][0];
	}

	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, tile);
	}
	
}
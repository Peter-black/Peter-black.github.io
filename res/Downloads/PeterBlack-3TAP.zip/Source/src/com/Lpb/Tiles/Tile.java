package com.Lpb.Tiles;

import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Tile {
	public final int id;
	public final boolean collide;
	public final int color;
	
	public Rectangle colRect;
	public Sprite tile;

	public static Tile[] tiles = new Tile[9];

	public static Tile noTile = new Tile(0, false, -16777216);
	public static Tile grassTile = new Tile(1, false, -16759296);
	public static Tile flowergrassTile = new Tile(2, false, -16759296);
	public static Tile longgrassTile = new Tile(3, false, -16759296);
	public static Tile rockTile = new Tile(4, true, -12171706);
	public static Tile dirtTile = new OverlayTile(5, false, -11524096);
	public static Tile dirtOverlay = new Tile(6, false, -11524096);
	public static Tile fireTile = new ParticleTile(7, false, -16777216);
	public static Tile building = new Building(8, true, -32768);

	public Tile(int id, boolean collide, int color) {
		this.id = id;
		this.collide = collide;
		this.color = color;
		int x = id%32;
		int y = (id-x)/32;
		this.tile = Sprites.terrain[x][y];
		tiles[id] = this;
	}

	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x * tile.w, y * tile.h, tile);
	}

}
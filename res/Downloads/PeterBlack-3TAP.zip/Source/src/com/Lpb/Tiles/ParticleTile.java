package com.Lpb.Tiles;

import com.Lpb.Game;
import com.Lpb.Graphics.FireParticle;
import com.Lpb.Graphics.Screen;

public class ParticleTile extends Tile {
	
	int ticks = 0;
	
	public ParticleTile(int id, boolean collide, int color) {
		super(id, collide, color);
	}

	public void render(int x, int y, Screen screen) {
		ticks++;
		if(ticks == 20){
			Game.particles.add(new FireParticle(x*tile.w+(tile.w/2), y*tile.h+(tile.h/2), 1, 1, color));
			Game.particles.add(new FireParticle(x*tile.w+(tile.w/2), y*tile.h+(tile.h/2), 1, 1, -114431));
		}
		if(ticks == 40){
			Game.particles.add(new FireParticle(x*tile.w+(tile.w/2), y*tile.h+(tile.h/2), 1, 1, -114431));
			ticks = 0;
		}
		screen.renderSprite(x * tile.w, y * tile.h, tile);
	}
	
}
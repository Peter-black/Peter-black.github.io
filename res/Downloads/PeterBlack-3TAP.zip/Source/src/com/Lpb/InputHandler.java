package com.Lpb;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import com.Lpb.Entity.Npc;
import com.Lpb.Events.EventHandler;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Inventory.Item;
import com.Lpb.Menu.Menu;

public class InputHandler implements KeyListener, MouseWheelListener, MouseListener, MouseMotionListener{
	
	public class Key{	
		public boolean state;
		public boolean clicked;
		
		public Key(boolean state, boolean clicked){
			this.state = state;
			this.clicked = clicked;
		}
	}
	
	public Key up = new Key(false, false);
	public Key down = new Key(false, false);
	public Key left = new Key(false, false);
	public Key right = new Key(false, false);
	public Key shift = new Key(false, false);

	public Key one = new Key(false, false);
	public Key two = new Key(false, false);
	public Key three = new Key(false, false);
	
	public Key back = new Key(false, false);
	public Key use = new Key(false, false);
	public Key drop = new Key(false, false);
	public Key shoot = new Key(false, false);
	public Key reload = new Key(false, false);
	
	public Key log = new Key(false, false);
	
	public Key esc = new Key(false, false);
	public Key fullscreen = new Key(false, false);
	public Key screenshot = new Key(false, false);
	
	public boolean 
	inButton = false,
	mouseClicked = false;
	
	public static double mX, mY;
	public int notches;
	
	public InputHandler(Game game){
		game.addKeyListener(this);
		game.addMouseWheelListener(this);
		game.addMouseListener(this);
		game.addMouseMotionListener(this);
	}
	
	public void tick(){
		
		//GENERAL INPUT
		if(!Game.paused){
			
			Game.player.setDX(0);
			Game.player.setDY(0);
			
			if(right.state)Game.player.setDX(1.5);		
			if(left.state)Game.player.setDX(-1);
			if(down.state)Game.player.setDY(1.5);
			if(up.state)Game.player.setDY(-1);
			if(shift.state && right.state)Game.player.setDX(3);
			if(shift.state && left.state)Game.player.setDX(-2);
			if(shift.state && down.state)Game.player.setDY(3);	
			if(shift.state && up.state)Game.player.setDY(-2);	
		
			if(one.state)Inventory.selectedItem = 0;
			if(two.state)Inventory.selectedItem = 1;
			if(three.state)Inventory.selectedItem = 2;
			
			if(use.state && !use.clicked){
				for(int i = 0; i < Npc.npcs.length; i++){
			    for(int j = 0; j < Npc.npcNum; j++){
			    	if(Npc.npcs[i][j] != null && Npc.npcs[i][j].checkForPlayer()){
			    		Npc.npcs[i][j].speak();
			    	}
			    }
			    }	
					
				if(Game.player.checkForBuilding()){
					Game.setPaused(true);
					Menu.setMenu(Menu.SHOP_MENU);
				}
				if(Game.player.checkForItem()){
					//AMMO
					for(int i = 0; i < Item.ammoBoxes.size(); i++){
						if(Game.currItemMap.getItem((Game.player.pX+16)/32, (Game.player.pY+16)/32) == Item.ammoBoxes.get(i)){
							if(Inventory.addAmmo(Item.ammoBoxes.get(i))){
								Game.currItemMap.setItem((Game.player.pX+16)/32, (Game.player.pY+16)/32, null);
							}
							return;
						}
					}
					//ITEMS
					if(Inventory.addItem(Game.currItemMap.getItem((Game.player.pX+16)/32, (Game.player.pY+16)/32))){
						Game.currItemMap.setItem((Game.player.pX+16)/32, (Game.player.pY+16)/32, null);
					}
				}

				use.clicked = true;
			}
			
			if(drop.state && !drop.clicked){
				if(!Game.player.checkForItem()){
					Game.currItemMap.setItem((Game.player.pX+16)/32, (Game.player.pY+16)/32, Inventory.inventory[Inventory.selectedItem]);
					Inventory.removeItem(Inventory.inventory[Inventory.selectedItem]);
				}
				
				drop.clicked = true;
			}
			
			if(shoot.state && !shoot.clicked){
				if(Inventory.inventory[Inventory.selectedItem] != null){
					
					if(Inventory.inventory[Inventory.selectedItem].automatic){
						if(Game.tick%5 == 0)Inventory.inventory[Inventory.selectedItem].use();		
					}else{
						Inventory.inventory[Inventory.selectedItem].use();
						shoot.clicked = true; 
					}
				}else{ shoot.clicked = true; }
			}
			
			if(reload.state && !reload.clicked){
				if(Inventory.inventory[Inventory.selectedItem] != null){
					Inventory.inventory[Inventory.selectedItem].reload();
				}
				reload.clicked = true;
			}
			
			if(log.state && !log.clicked){
				if(Menu.QUEST_LOG.state){Game.setPaused(false);Menu.setMenu(Menu.NO_MENU);}
				else{
					Game.setPaused(true);
					Menu.setMenu(Menu.QUEST_LOG);
				}
				log.clicked = true;
			}
			
			if(esc.state && !esc.clicked){
					if(Menu.PAUSE_MENU.state || Menu.SHOP_MENU.state){Game.setPaused(false);Menu.setMenu(Menu.NO_MENU);}
					else{
						Game.setPaused(true);
						Menu.setMenu(Menu.PAUSE_MENU); 
					}
				esc.clicked = true;
			} 	
		}
	
		//MENU INPUT
		if(Menu.currMenu != Menu.NO_MENU){
			
			if(Menu.currMenu == Menu.PAUSE_MENU || Menu.currMenu == Menu.SHOP_MENU || Menu.currMenu == Menu.QUEST_LOG){
				if(esc.state && !esc.clicked){
					Game.setPaused(false);
					Menu.setMenu(Menu.NO_MENU);
					esc.clicked = true;
				} 
			}else if(Menu.currMenu != Menu.TITLE_MENU){
				if(esc.state && !esc.clicked){
					Menu.setMenu(Menu.parentMenu);
					esc.clicked = true;
				} 
			}
			
			if(Menu.currMenu == Menu.UPGRADE_MENU){
				if(one.state)Inventory.selectedItem = 0;
				if(two.state)Inventory.selectedItem = 1;
				if(three.state)Inventory.selectedItem = 2;
			}
			
			if(Menu.currMenu == Menu.PAUSE_MENU || Menu.currMenu == Menu.SHOP_MENU){
				if(esc.state && !esc.clicked){
					Game.setPaused(false);
					Menu.setMenu(Menu.NO_MENU);
					esc.clicked = true;
				} 
			}
			
			if(Menu.currMenu == Menu.QUEST_LOG){
				if(log.state && !log.clicked){
					Game.setPaused(false);
					Menu.setMenu(Menu.NO_MENU);
					log.clicked = true;
				}
			}
				
			if(down.state && !down.clicked){Menu.currMenu.selectedItem++; down.clicked = true;}
			if(up.state && !up.clicked){Menu.currMenu.selectedItem--; up.clicked = true;}
			
			if(use.state && !use.clicked || mouseClicked){
				Menu.currMenu.chooseOption(Menu.currMenu.selectedItem);
				
				use.clicked = true;
				mouseClicked = false;
			}
		}
		
		if(EventHandler.speechBox.isRunning()){
			Game.setPaused(true);
			if(use.state && !use.clicked){EventHandler.speechBox.stop();use.clicked = true;}
		}
		
		if(EventHandler.speechBoxBoolean.isRunning()){
			Game.setPaused(true);
			if(up.state && !up.clicked){EventHandler.speechBoxBoolean.select();up.clicked = true;}
			if(down.state && !down.clicked){EventHandler.speechBoxBoolean.select();down.clicked = true;}
			if(use.state && !use.clicked){EventHandler.speechBoxBoolean.choose();use.clicked = true;}
		}
		
		//EXTRA INPUT
		if(fullscreen.state && !fullscreen.clicked){
			Game.toggleFullscreen();	
			
			try {Write.savePrefs();} 
			catch (Exception e2) {
			e2.printStackTrace();}
			
			fullscreen.clicked = true;
		}
		
		if(screenshot.state && !screenshot.clicked){Game.Screenshot();screenshot.clicked = true;}
		
	}
	
	public void toggle(KeyEvent ke,boolean pressed){
		int keyCode = ke.getKeyCode();
		
		if(keyCode == KeyEvent.VK_UP) up.state = pressed;
		if(keyCode == KeyEvent.VK_DOWN) down.state = pressed;
		if(keyCode == KeyEvent.VK_LEFT) left.state = pressed;
		if(keyCode == KeyEvent.VK_RIGHT) right.state = pressed;
		if(keyCode == KeyEvent.VK_W) up.state = pressed;
		if(keyCode == KeyEvent.VK_S) down.state = pressed;
		if(keyCode == KeyEvent.VK_A) left.state = pressed;
		if(keyCode == KeyEvent.VK_D) right.state = pressed;
		if(keyCode == KeyEvent.VK_SHIFT) shift.state = pressed;
		
		if(keyCode == KeyEvent.VK_1) one.state = pressed;
		if(keyCode == KeyEvent.VK_2) two.state = pressed;
		if(keyCode == KeyEvent.VK_3) three.state = pressed;

		if(keyCode == KeyEvent.VK_BACK_SPACE) back.state = pressed;
		if(keyCode == KeyEvent.VK_E) use.state = pressed;
		if(keyCode == KeyEvent.VK_ENTER) use.state = pressed;
		if(keyCode == KeyEvent.VK_Q) drop.state = pressed;
		if(keyCode == KeyEvent.VK_R) reload.state = pressed;
		
		if(keyCode == KeyEvent.VK_L) log.state = pressed; 
		
		if(keyCode == KeyEvent.VK_ESCAPE) esc.state = pressed;
		if(keyCode == KeyEvent.VK_F11) fullscreen.state = pressed;
		if(keyCode == KeyEvent.VK_F12) screenshot.state = pressed; 
	}
	
	public void keyTyped(KeyEvent ke) {

	}

	public void keyPressed(KeyEvent ke) {
		toggle(ke,true);
	}
	
	public void keyReleased(KeyEvent e) {
		toggle(e,false);
		if(e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) up.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) down.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_E || e.getKeyCode() == KeyEvent.VK_ENTER) use.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_Q) drop.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_SPACE) shoot.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_R) reload.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_L) log.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE) esc.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_F11) fullscreen.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_F12) screenshot.clicked = false;
	}

	public void mouseWheelMoved(MouseWheelEvent e) {
		notches = e.getWheelRotation();
		
		if(Menu.ACHIEVEMENT_MENU.state || Menu.QUEST_LOG.state){
			if(notches < 0){
				if(!Menu.scrollLockUp)Menu.scroll -= 40;
			}else{
				if(!Menu.scrollLockDown)Menu.scroll += 40;
			}
		}
		
		if(Menu.TITLE_MENU.state || Menu.PAUSE_MENU.state || Menu.SHOP_MENU.state || Menu.OPTIONS_MENU.state ||
		   Menu.BUY_MENU.state || Menu.CHEATS_MENU.state){
		      if (notches < 0) {
		    	  if(Menu.currMenu.selectedItem>0)Menu.currMenu.selectedItem--;
		    	  else Menu.currMenu.selectedItem = Menu.currMenu.maxItems-1;
		      } else {
		    	  if(Menu.currMenu.selectedItem<Menu.currMenu.maxItems-1)Menu.currMenu.selectedItem++;
		    	  else Menu.currMenu.selectedItem = 0;
		      }
		}
		if(!Game.paused || Menu.SELL_MENU.state || Menu.UPGRADE_MENU.state){
			if (notches < 0) {
		    	  if(Inventory.selectedItem<Inventory.maxItems-1)Inventory.selectedItem++;
		    	  else Inventory.selectedItem = 0;
		      } else {
		    	  if(Inventory.selectedItem>0)Inventory.selectedItem--;
		    	  else Inventory.selectedItem = Inventory.maxItems-1;
		      }
		}
	}

	@Override
	public void mouseClicked(MouseEvent me) {
		
	}

	@Override
	public void mouseEntered(MouseEvent me) {
		
	}

	@Override
	public void mouseExited(MouseEvent me) {
		
	}

	@Override
	public void mousePressed(MouseEvent me) {
		setMouseGameCoords(me.getX(), me.getY());
		
		if(!Game.paused)shoot.state = true;
		
		inButton = false;
		
		if(Menu.currMenu == Menu.DEAD_MENU){
			for(int i = 0; i < Menu.currMenu.maxItems; i ++){		
				if(mY >= Game.HEIGHT/2 - (Menu.currMenu.maxItems*15) - 2 + i * 15 &&
				   mY <= Game.HEIGHT/2 - (Menu.currMenu.maxItems*15) + 12 + i * 15){
						
				if(mX >= 180 && 
				   mX <= 300){
					Menu.currMenu.selectedItem = i;
					inButton = true;
				}
				}		
			}
		}else{ 
			for(int i = 0; i < Menu.currMenu.maxItems; i ++){		
				if(mY >= Game.HEIGHT - (Menu.currMenu.maxItems*15) - 2 + i * 15 &&
				   mY <= Game.HEIGHT - (Menu.currMenu.maxItems*15) + 12 + i * 15){
					
				if(mX >= 0 && 
				   mX <= 125){
					Menu.currMenu.selectedItem = i;
					inButton = true;
				}
				}		
			}	
		}
		
		if(inButton){
			mouseClicked = true;
		}
	}

	@Override
	public void mouseReleased(MouseEvent me) {
		mouseClicked = false;
		use.clicked = false; 
		shoot.state = false;
		shoot.clicked = false;
	}

	@Override
	public void mouseDragged(MouseEvent me) {
		setMouseGameCoords(me.getX(), me.getY());
	}

	@Override
	public void mouseMoved(MouseEvent me) {
		setMouseGameCoords(me.getX(), me.getY());
		
		inButton = false;
		
		if(Menu.currMenu != null){
			if(Menu.currMenu == Menu.DEAD_MENU){
				for(int i = 0; i < Menu.currMenu.maxItems; i ++){		
					if(mY >= Game.HEIGHT/2 - (Menu.currMenu.maxItems*15) - 2 + i * 15 &&
					   mY <= Game.HEIGHT/2 - (Menu.currMenu.maxItems*15) + 12 + i * 15){
							
					if(mX >= 180 && 
					   mX <= 300){
						Menu.currMenu.selectedItem = i;
						inButton = true;
					}
					}		
				}		
			}else{ 
				for(int i = 0; i < Menu.currMenu.maxItems; i ++){			
					if(mY >= Game.HEIGHT - (Menu.currMenu.maxItems*15) - 2 + i * 15 &&
					   mY <= Game.HEIGHT - (Menu.currMenu.maxItems*15) + 12 + i * 15){
												
					if(mX >= 0 && 
					   mX <= 125){
						Menu.currMenu.selectedItem = i;
						inButton = true;
					}
					}
				}
			}
		}
	}
	
	public void setMouseGameCoords(int rawX, int rawY){
		if(Game.fullscreen){		
			mX = rawX/(double)(Game.frame.getWidth())*(double)(Game.screen.w);
			mY = rawY/(double)(Game.frame.getHeight())*(double)(Game.screen.h);
		}else{
			mX = rawX/(double)(Game.frame.getWidth()/Game.screen.w);
			mY = rawY/(double)(Game.frame.getHeight()/Game.screen.h);
		}
	}
}
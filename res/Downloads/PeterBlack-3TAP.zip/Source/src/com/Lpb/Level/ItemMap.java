package com.Lpb.Level;

import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.Ammo;
import com.Lpb.Inventory.AmmoBox;
import com.Lpb.Inventory.Item;
import com.Lpb.Sprites.Sprite;

public class ItemMap {
	public int id;
	int w;
	int h;
	public Sprite levelSprite;
	public Item[] tiles;
	
	public ItemMap(int id, int w, int h, Sprite levelSprite) {
		this.id = id;
		this.w = w;
		this.h = h;
		this.levelSprite = levelSprite;
		
		tiles = new Item[w * h];
	}
	
	public Item[] getTiles(){
		return tiles;
	}

	public void render(int xScroll, int yScroll, Screen screen) {
		int xo = xScroll >> 5;
		int yo = yScroll >> 5;

		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;
		
		screen.setOffs(xScroll, yScroll);

		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				if(getItem(x,y) != null)getItem(x,y).renderDropped(x*32, y*32, screen);
			}
		}
		screen.setOffs(0, 0);
	}

	public Item getItem(int x, int y) {
		if (x < 0 || y < 0 || x >= w || y >= h) return null;
		if(tiles[x + y * w] == null) return null;
		return tiles[x + y * w];
	}
	
	public boolean setItem(int x, int y, Item item) {
		if (x < 0 || y < 0 || x >= w || y >= h) return false;
		if (getItem(x,y) == null || item == null){
			if (item == null){tiles[x + y * w] = null; return true;}
			else {tiles[x + y * w] = item; return true;}
		}else return false;
	}

	public void loadMap(int x0, int y0, int x1, int y1, Sprite sprite) {
		for (int y = 0; y < sprite.h; y++) {
			for (int x = 0; x < sprite.w; x++) {
				for (int i = 0; i < Item.items.length; i++){
					if (sprite.pixels[x + y * sprite.w] == -i) {
						if(i == 0 ){tiles[x + x1 + (y + y1) * h] = null;break;}
						if(i == 9 ){tiles[x + x1 + (y + y1) * h] = new AmmoBox(Ammo.PISTOL, 50);break;}
						if(i == 10){tiles[x + x1 + (y + y1) * h] = new AmmoBox(Ammo.SMG, 50);break;}
						if(i == 11){tiles[x + x1 + (y + y1) * h] = new AmmoBox(Ammo.ASSAULT, 50);break;}
						if(i == 12){tiles[x + x1 + (y + y1) * h] = new AmmoBox(Ammo.SHOTGUN, 50);break;}
						tiles[x + x1 + (y + y1) * w] = Item.items[i];
						break;
					}else tiles[x + x1 + (y + y1) * w] = null;
				}			
			}
		}
	}
}
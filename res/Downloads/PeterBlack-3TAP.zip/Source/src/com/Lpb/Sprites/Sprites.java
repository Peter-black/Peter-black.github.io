package com.Lpb.Sprites;

public class Sprites {
	//LEVEL
	public static Sprite[][] terrain = SpriteSheetLoader.cutTiles("/level/terrain.png", 32, 32);
	public static Sprite[][] tileOverlayVert = SpriteSheetLoader.cutTiles("/level/terrain.png", 4, 32);
	public static Sprite[][] tileOverlayHorz = SpriteSheetLoader.cutTiles("/level/terrain.png", 32, 4);
	public static Sprite[][] buildings = SpriteSheetLoader.cutTiles("/level/buildings.png", 64, 48);
	public static Sprite[][] level = SpriteSheetLoader.cutTiles("/level/level.png", 16, 16);
	public static Sprite[][] level1 = SpriteSheetLoader.cutTiles("/level/level1.png", 64, 64);
	//MOBS
	public static Sprite[][] player = SpriteSheetLoader.cutTiles("/mobs/hiresplayer.png", 32, 32);
	public static Sprite[][] citizen = SpriteSheetLoader.cutTiles("/mobs/citizen.png", 32, 36);
	public static Sprite[][] zombie = SpriteSheetLoader.cutTiles("/mobs/zombie.png", 32, 36);
	public static Sprite[][] troll = SpriteSheetLoader.cutTiles("/mobs/troll.png", 64, 72);
	//ITEMS
	public static Sprite[][] items = SpriteSheetLoader.cutTiles("/items/items.png", 64, 32);
	public static Sprite[][] droppedItems = SpriteSheetLoader.cutTiles("/items/items.png", 32, 32);
	public static Sprite[][] jawkModel = SpriteSheetLoader.cutTiles("/items/jawkModel.png", 32, 36);
	public static Sprite[][] SG019Model = SpriteSheetLoader.cutTiles("/items/SG019Model.png", 32, 36);
	public static Sprite[][] knifeModel = SpriteSheetLoader.cutTiles("/items/knifeModel.png", 32, 36);
	public static Sprite[][] knifeSwing = SpriteSheetLoader.cutTiles("/items/knifeSwing.png", 20, 20);
	//FONT
	public static Sprite[][] font = SpriteSheetLoader.cutTiles("/fonts/font.png", 6, 10);
	public static Sprite[][] menuFont = SpriteSheetLoader.cutTiles("/fonts/menuFont.png", 12, 20);
	//GUI
	public static Sprite[][] guiHealth = SpriteSheetLoader.cutTiles("/gui/gui.png", 80, 8);
	public static Sprite[][] guiHealthFill = SpriteSheetLoader.cutTiles("/gui/gui.png", 1, 8);
	public static Sprite[][] guiHolder = SpriteSheetLoader.cutTiles("/gui/gui.png", 80, 80);
	public static Sprite[][] guiSlots = SpriteSheetLoader.cutTiles("/gui/gui.png", 80, 24);
	public static Sprite[][] guiExp = SpriteSheetLoader.cutTiles("/gui/gui.png", 256, 8);
	public static Sprite[][] guiExpFill = SpriteSheetLoader.cutTiles("/gui/gui.png", 13, 8);
	public static Sprite[][] guiCrosshair = SpriteSheetLoader.cutTiles("/gui/gui.png", 9, 9);
	//MENU
	public static Sprite[][] menuBg = SpriteSheetLoader.cutTiles("/gui/menubg.png", 960, 540);
	public static Sprite[][] splash = SpriteSheetLoader.cutTiles("/gui/splash.png", 960, 540);	
}
package com.Lpb.Entity;

import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Sounds.Sound;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Sprites.Sprites;
import com.Lpb.Tiles.Tile;

public class Zombie extends Mob{
	
	public Zombie(int id,int x,int y,int w,int h,int hl,int mh,double s,int ke,boolean d){
		super(id, x, y, w, h, hl, mh, s, ke, d);
		
		walkAnim = new SpriteAnimator(Sprites.zombie,15);
		walkAnim.start();
		}

	public void tick(){
		super.tick();
		if(checkForPlayer())attack(2, 0);
	}
	
	public void proccesCollidingTiles(int[] tiles){
		for(int i = 0; i < 4;i++){
			if(tiles[i] == Tile.rockTile.id){
				//hurt(2, 2);
			}
		}
	}
	
	public void attack(int damage, int knockback){
		if(attackTimer%50 == 0){
			if(this.collideRect.intersects(Game.player.pRect)){
				Sound.ZOMBIE_ATTACK_ONE.play();
				Game.player.hurt(damage, knockback, this);
			}
		}	
		attackTimer++;
	}
	
	public void ambientSound(){
		Random r = new Random();
		Random a = new Random();
		if(tickcount%300 == 0){
			if(r.nextInt(120) == 0){
				if(!Sound.ZOMBIE_CASUAL_ONE.isRunning() && !Sound.ZOMBIE_CASUAL_TWO.isRunning()){
					switch(a.nextInt(2)){
					case 0: Sound.ZOMBIE_CASUAL_ONE.play(); break;
					case 1: Sound.ZOMBIE_CASUAL_TWO.play(); break;
					}
				}
			}
		}
	}
	
	public void die(){
		super.die();
		Sound.ZOMBIE_DEATH.play();
		zNum --;
		mobs[0][id] = null;
	}
}

package com.Lpb.Entity;

import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Geom.Point;
import com.Lpb.Sounds.Sound;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Sprites.Sprites;
import com.Lpb.Tiles.Tile;

public class Troll extends Mob{	
	
	public Troll(int id,int x,int y,int w,int h,int hl,int mh,double s,int ke,boolean d){
		super(id, x, y, w, h, hl, mh, s, ke, d);
		
		walkAnim = new SpriteAnimator(Sprites.troll,15);
		walkAnim.start();
	}

	public void tick() {
		if(dead)return;
			
		collideRect.x = x;
		collideRect.y = y;
		collideRect.w = width;
		collideRect.h = height;
			
		//If moving in a direction, check the collsion infront of you, if you aren't colliding, move.
		int[] tiles = new int[0];
		if(dX > 0.00){tiles = checkCollision(x + (int)(dX+speed) ,y ,width,height);if(tiles.length<6)x += 15 * dX * 0.1;}
		if(dX < 0.00){tiles = checkCollision(x + (int)(dX),y ,width,height);if(tiles.length<6)x += 15 * dX * 0.01;}
		if(dY < 0.00){tiles = checkCollision(x ,y + (int)(dY),width,height);if(tiles.length<6)y += 15 * dY * 0.01;}
		if(dY > 0.00){tiles = checkCollision(x ,y + (int)(dY+speed),width,height);if(tiles.length<6)y += 15 * dY * 0.1;}
		//If you are collinding, do collide.
		if(tiles.length > 6)proccesCollidingTiles(tiles);
		
		if(lastFacing != dirFacing){
			walkAnim.setCurrentSet(dirFacing);
			lastFacing = dirFacing;
		}
			
		pathfind();
		if(checkForPlayer())attack(5, 0);
		ambientSound();
		if(health == 0)die();
	}
	
	protected int[] checkCollision(int x, int y, int sizeX, int sizeY) {
		Point p1 = new Point(x/TILE_SIZE,y/TILE_SIZE);
		Point p2 = new Point((x+sizeX-1)/TILE_SIZE,y/TILE_SIZE);
		Point p3 = new Point((x+sizeX-1)/TILE_SIZE,(y+sizeY-1)/TILE_SIZE);
		Point p4 = new Point(x/TILE_SIZE,(y+sizeY-1)/TILE_SIZE);
		//Bigger model needs more collision points
		Point p5 = new Point(x/TILE_SIZE,(y+(sizeY/2))/TILE_SIZE);
		Point p6 = new Point((x+(sizeX/2))/TILE_SIZE,(y+(sizeY/2))/TILE_SIZE);
		Point p7 = new Point((x+(sizeX/2))/TILE_SIZE,(y+(sizeY-1))/TILE_SIZE);
		
			
		//checks the collision
		if(!checkCollision(p1.x,p1.y)){
			if(!checkCollision(p2.x,p2.y)){
				if(!checkCollision(p3.x,p3.y)){
					if(!checkCollision(p4.x,p4.y)){
						if(!checkCollision(p5.x,p5.y)){
							if(!checkCollision(p6.x,p6.y)){
								if(!checkCollision(p6.x,p6.y)){
									//System.out.print("Not colliding!\n");
									return new int[0];
								}
							}
						}	
					}
				}
			}
		}
			
		int[] tiles = {currLevel.getTile(p1.x,p1.y).id,
				       currLevel.getTile(p2.x,p2.y).id,
				       currLevel.getTile(p3.x,p3.y).id,
				       currLevel.getTile(p4.x,p4.y).id,
				       currLevel.getTile(p5.x,p5.y).id,
				       currLevel.getTile(p6.x,p6.y).id,
				       currLevel.getTile(p7.x,p7.y).id,};
			
		//System.out.print("Colliding!\n");
		return tiles;
	}
	

	public void proccesCollidingTiles(int[] tiles){
		for(int i = 0; i < 4;i++){
			if(tiles[i] == Tile.rockTile.id){
				//hurt(2, 2);
			}
		}
	}
	
	public void attack(int damage, int knockback){
		if(attackTimer%50 == 0){
			if(this.collideRect.intersects(Game.player.pRect)){
				Game.player.hurt(damage, knockback, this);
			}
		}	
		attackTimer++;
	}
	
	public void ambientSound(){
		Random r = new Random();
		Random a = new Random();
		if(tickcount%300 == 0){
			if(r.nextInt(120) == 0){
				if(!Sound.ZOMBIE_CASUAL_ONE.isRunning() && !Sound.ZOMBIE_CASUAL_TWO.isRunning()){
					switch(a.nextInt(2)){
					case 0: Sound.ZOMBIE_CASUAL_ONE.play(); break;
					case 1: Sound.ZOMBIE_CASUAL_TWO.play(); break;
					}
				}
			}
		}
	}
	
	public void die(){
		super.die();
		Sound.ZOMBIE_DEATH.play();
		tNum --;
		mobs[1][id] = null;
	}
}

package com.Lpb.Entity;

import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Geom.Point;
import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Level.Level;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Tiles.Tile;

public class Npc {
	
	//if you want to override any of the npc methods just re-write them in the class
	//if you want to add to them, make the method then inside do super.method(param,param)
	
	//ATTRIBUTES
	public int id;
	public int x;
	public int y;
	public double dX = 0;
	public double dY = 0;
	public int width;
	public int height;
	public int rad = 50;
	public Rectangle collideRect;
	public Rectangle speakRadius = new Rectangle(x-(rad/2), y-(rad/2), rad, rad);
	private int xOffset = 0;
	private int yOffset = 8;
	public int maxHealth;
	public int health;
	public double speed;
	public int killExp;
	public boolean dead = false;
	
	//VARIABLES
	public static final int TILE_SIZE = 32;
	protected Level currLevel;
	public int rDirection;	
	public int dirFacing = 0;
	public int lastFacing = 0;
	public boolean Moving = false;
	protected SpriteAnimator walkAnim;
	protected boolean hurt = false;
	protected int hurtTick = 0;
	protected int attackTimer = 0;
	Random random = new Random();
	protected int tickcount;
	
	//EXTERNAL MANAGEMENT
	public static int cNum = 0;
	public static int npcNum = 0;
		
	public static Npc[] citizens = new Npc[100];
	public static Npc[][] npcs = { citizens };
	
	public static final Npc CITIZEN = new Citizen(0,300,300,32,32,100,100,0.2,10,false);

	//CONSTRUCTOR AND DEFAULT METHODS
	public Npc(int id,int x,int y,int w,int h,int hl,int mh,double s,int ke,boolean d){
		this.id = id;
		this.x = x;
		this.y = y;
		this.width = w;
		this.height = h;
		this.health = hl;
		this.maxHealth = mh;
		this.speed = s;
		this.killExp = ke;
		this.dead = d;
		
		collideRect = new Rectangle(0,0,0,0);
	}
	
	public void setDX(double dx){
		if(dx != 0)Moving = true;
		if(dx < 0.00)dirFacing = 3;
		if(dx > 0.00)dirFacing = 1;
		dX = dx;
	}
	
	public void setDY(double dy){
		if(dy != 0)Moving = true;
		if(dy > 0.00)dirFacing = 2;
		if(dy < 0.00)dirFacing = 0;
		
		dY = dy;
	}
	
	public double getDX(){
		return dX;
	}
	
	public double getDY(){
		return dY;
	}
	
	public void tick() {
		if(dead)return;
		
		collideRect.x = x;
		collideRect.y = y;
		collideRect.w = width;
		collideRect.h = height;
		
		speakRadius.x = x-(rad/2);
		speakRadius.y = y-(rad/2);
		
		//If moving in a direction, check the collsion infront of you, if you aren't colliding, move.
		int[] tiles = new int[0];
		if(dX > 0.00){tiles = checkCollision(x + xOffset + (int)(dX+0.5) ,y + yOffset ,16,16);if(tiles.length<3)x += 15 * dX * 0.1;}
		if(dX < 0.00){tiles = checkCollision(x + xOffset + (int)(dX),y + yOffset,16,16);if(tiles.length<3)x += 15 * dX * 0.01;}
		if(dY < 0.00){tiles = checkCollision(x + xOffset ,y + yOffset + (int)(dY),16,16);if(tiles.length<3)y += 15 * dY * 0.01;}
		if(dY > 0.00){tiles = checkCollision(x + xOffset ,y + yOffset + (int)(dY+0.5),16,16);if(tiles.length<3)y += 15 * dY * 0.1;}
		//If you are collinding, do collide.
		if(tiles.length > 3)proccesCollidingTiles(tiles);
		
		if(lastFacing != dirFacing){
			walkAnim.setCurrentSet(dirFacing);
			lastFacing = dirFacing;
		}
		
		pathfind();
		checkForPlayer();
		ambientSound();
		if(health == 0)die();
	}

	public void pathfind(){
		if(tickcount == 0)rDirection = random.nextInt(10);	
			if(rDirection == 0)setDX(speed+0.5);
			if(rDirection == 1)setDX(-speed);
			if(rDirection == 2)setDY(speed+0.5);
			if(rDirection == 3)setDY(-speed);
			if(rDirection > 3){setDX(0);setDY(0);}
		tickcount++;
		if(tickcount > random.nextInt(60) + 30)tickcount = 0;
	}
	
	protected int[] checkCollision(int x, int y, int sizeX, int sizeY) {
		Point p1 = new Point(x/TILE_SIZE,y/TILE_SIZE);
		Point p2 = new Point((x+sizeX-1)/TILE_SIZE,y/TILE_SIZE);
		Point p3 = new Point((x+sizeX-1)/TILE_SIZE,(y+sizeY-1)/TILE_SIZE);
		Point p4 = new Point(x/TILE_SIZE,(y+sizeY-1)/TILE_SIZE);
			
		//checks the collision
		if(!checkCollision(p1.x,p1.y)){
			if(!checkCollision(p2.x,p2.y)){
				if(!checkCollision(p3.x,p3.y)){
					if(!checkCollision(p4.x,p4.y)){
						//System.out.print("Not colliding!\n");
						return new int[0];
					}
				}
			}
		}
			
		int[] tiles = {currLevel.getTile(p1.x,p1.y).id,
				       currLevel.getTile(p2.x,p2.y).id,
				       currLevel.getTile(p3.x,p3.y).id,
				       currLevel.getTile(p4.x,p4.y).id,};
			
		//System.out.print("Colliding!\n");
		return tiles;
	}
	
	protected boolean checkCollision(int x, int y) {
		Tile tile = currLevel.getTile(x, y);
		if(tile.collide)return true;
		return false;
	}
	
	public void proccesCollidingTiles(int[] tiles){
	}
	
	public boolean checkForPlayer(){
		if(speakRadius != null && Game.player.pRect != null){
			if(speakRadius.intersects(Game.player.pRect)){
				return true;
			}
		}
		
		return false;
	}
	
	public void speak(){
	}
	
	public void attack(int damage, int knockback){
	}
	
	public void hurt(int damage, int knockback){
		hurt = true;
		health -= damage;
		if(health <= 0){
			health = 0;
		}
		
		if(dirFacing == 0){
			y += knockback;
		}
		if(dirFacing == 1){
			x -= knockback;
		}
		if(dirFacing == 2){
			y -= knockback;
		}
		if(dirFacing == 3){
			x += knockback;
		}
		
	}
	
	public void heal(int healing){
		health += healing;
		if(health >= maxHealth){
			health = maxHealth;
		}
	}
	
	public void die(){
		dead = true;
		collideRect = null;
	}
	
	public void ambientSound(){
	}
	
	public void render(int xOffs, int yOffs, Screen screen) {
		if(dead)return;
		screen.setOffs(xOffs, yOffs);
		
		if(hurt){
			screen.renderSprite(x, y, walkAnim.getCurrSprite(), 0, 16); 
			hurtTick++;
			if(hurtTick > 15){
				hurt = false;
				hurtTick = 0;
			}
		}else{
			screen.renderSprite(x, y, walkAnim.getCurrSprite());
		}
		
		screen.setOffs(0, 0);
		if(Moving){
			if(!walkAnim.isRunning()){
				walkAnim.start();
			}
		}else{
			if(walkAnim.isRunning()){
				walkAnim.stop();
			}
		}
		Moving = false;
	}
	
	
	//EXTERNAL METHODS
	public static void spawnNpc(Npc npc, int amount){	
		int spawned = 0;
		if(npc == CITIZEN){
			if(cNum >= citizens.length)return;
			
			for(int i = 0; i < citizens.length; i++){
				if(citizens[i] != null)continue;
				
				citizens[i] = new Citizen(i, npc.x,npc.y,npc.width,npc.height,npc.health,npc.maxHealth,npc.speed,npc.killExp,npc.dead);
				citizens[i].changeLevel(Game.currLevel);
				
				spawned ++;
				if(spawned + cNum > citizens.length){cNum = citizens.length; updateNpcNum(); return;}
				if(spawned >= amount)break;
			}
			cNum += amount;
			if(cNum >= citizens.length)cNum = citizens.length;
		}
		updateNpcNum();	
	}

	public static void removeNpc(Npc npc, int amount){	
		if(npc == CITIZEN){
			if(cNum - amount < 0){
				for(int i = 0; i < cNum; i++){
					citizens[i] = null;
				}
			}else{
				for(int i = cNum - amount; i < cNum; i++){
					citizens[i] = null;
				}
			}
			cNum -= amount;
			if(cNum <= 0)cNum = 0;
		}
		updateNpcNum();
	}
	
	private static int updateNpcNum(){
		npcNum = cNum;
		
		if(npcNum >= 100)npcNum = 100;
		if(npcNum <= 0)npcNum = 0;
		
		return npcNum;
	}
	
	public void changeLevel(Level level) {	
		currLevel = level;
	}
}

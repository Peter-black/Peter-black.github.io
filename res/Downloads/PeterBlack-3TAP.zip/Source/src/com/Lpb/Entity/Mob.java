package com.Lpb.Entity;

import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Events.Rank;
import com.Lpb.Geom.Point;
import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.BloodParticle;
import com.Lpb.Graphics.Particle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Level.Level;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Tiles.Tile;

public class Mob {
	
	//if you want to override any of the mob methods just re-write them in the class
	//if you want to add to them make the method then inside do super.method(param,param)
	
	//ATTRIBUTES
	public int id;
	public int x;
	public int y;
	public double dX = 0;
	public double dY = 0;
	public int width;
	public int height;
	public Rectangle collideRect;
	private int xOffset = 0;
	private int yOffset = 8;
	public int maxHealth;
	public int health;
	public double speed;
	public int killExp;
	public boolean dead = false;
	
	//VARIABLES
	public static final int TILE_SIZE = 32;
	protected Level currLevel;	
	public int xDir, yDir;
	public int rDirection;	
	public int dirFacing = 0;
	public int lastFacing = 0;
	public boolean Moving = false;
	protected SpriteAnimator walkAnim;
	protected boolean hurt = false;
	protected int hurtTick = 0;
	protected int attackTimer = 0;
	Random random = new Random();
	protected int tickcount;
	
	//EXTERNAL MANAGEMENT
	public static int zNum = 0;
	public static int tNum = 0;
	public static int mobNum = 0;
		
	public static Mob[] zombies = new Mob[100];
	public static Mob[] trolls = new Mob[100];
	public static Mob[][] mobs = { zombies, trolls };
	
	public static final Mob ZOMBIE = new Zombie(0,60,20,32,32,100,100,2,10,false);
	public static final Mob TROLL = new Troll(0,8,20,64,64,200,200,1,100,false);

	//CONSTRUCTOR AND DEFAULT METHODS
	public Mob(int id,int x,int y,int w,int h,int hl,int mh,double s,int ke,boolean d){
		this.id = id;
		this.x = x;
		this.y = y;
		this.width = w;
		this.height = h;
		this.health = hl;
		this.maxHealth = mh;
		this.speed = s;
		this.killExp = ke;
		this.dead = d;
		
		collideRect = new Rectangle(0,0,0,0);
	}
	
	public void setDX(double dx){
		if(dx != 0)Moving = true;
		if(dx < 0.00)dirFacing = 3;
		if(dx > 0.00)dirFacing = 1;
		dX = dx;
	}
	
	public void setDY(double dy){
		if(dy != 0)Moving = true;
		if(dy > 0.00)dirFacing = 2;
		if(dy < 0.00)dirFacing = 0;
		
		dY = dy;
	}
	
	public double getDX(){
		return dX;
	}
	
	public double getDY(){
		return dY;
	}
	
	public void tick() {
		if(dead)return;
		
		collideRect.x = x;
		collideRect.y = y;
		collideRect.w = width;
		collideRect.h = height;
		
		//If moving in a direction, check the collsion infront of you, if you aren't colliding, move.
		int[] tiles = new int[0];
		if(dX > 0.00){tiles = checkCollision(x + xOffset + (int)(dX+speed) ,y + yOffset ,16,16);if(tiles.length<3)x += 15 * dX * 0.1;}
		if(dX < 0.00){tiles = checkCollision(x + xOffset + (int)(dX),y + yOffset,16,16);if(tiles.length<3)x += 15 * dX * 0.01;}
		if(dY < 0.00){tiles = checkCollision(x + xOffset ,y + yOffset + (int)(dY),16,16);if(tiles.length<3)y += 15 * dY * 0.01;}
		if(dY > 0.00){tiles = checkCollision(x + xOffset ,y + yOffset + (int)(dY+speed),16,16);if(tiles.length<3)y += 15 * dY * 0.1;}
		//If you are collinding, do collide.
		if(tiles.length > 3)proccesCollidingTiles(tiles);
		
		if(lastFacing != dirFacing){
			walkAnim.setCurrentSet(dirFacing);
			lastFacing = dirFacing;
		}
		
		pathfind();
		checkForPlayer();
		ambientSound();
		if(health == 0)die();
	}
	
	public void pathfind(){
		if(Game.player.pRadius.intersects(collideRect)){
			if(x+(width/2) < Game.player.pX+(Game.player.pW/2) && x+(width/2) != Game.player.pX+(Game.player.pW/2))setDX(speed);
			else if(x+(width/2) > Game.player.pX+(Game.player.pW/2))setDX(-speed);
			else if(x+(width/2) == Game.player.pX+(Game.player.pW/2))setDX(0);
			
			if(y+(height/2) > Game.player.pY+(Game.player.pH/2) && y+(height/2) != Game.player.pY+(Game.player.pH/2))setDY(-speed);
			else if(y+(height/2) < Game.player.pY+(Game.player.pH/2))setDY(speed);
			else if(y+(height/2) == Game.player.pY+(Game.player.pH/2))setDY(0);
		}else{
			if(tickcount == 0)rDirection = random.nextInt(10);	
			if(rDirection == 0)setDX(speed);
			if(rDirection == 1)setDX(-speed);
			if(rDirection == 2)setDY(speed);
			if(rDirection == 3)setDY(-speed);
			if(rDirection > 3){setDX(0);setDY(0);}
			tickcount++;
			if(tickcount > random.nextInt(60) + 30)tickcount = 0;
		}
	}
	
	protected int[] checkCollision(int x, int y, int sizeX, int sizeY) {
		Point p1 = new Point(x/TILE_SIZE,y/TILE_SIZE);
		Point p2 = new Point((x+sizeX-1)/TILE_SIZE,y/TILE_SIZE);
		Point p3 = new Point((x+sizeX-1)/TILE_SIZE,(y+sizeY-1)/TILE_SIZE);
		Point p4 = new Point(x/TILE_SIZE,(y+sizeY-1)/TILE_SIZE);
			
		//checks the collision
		if(!checkCollision(p1.x,p1.y)){
			if(!checkCollision(p2.x,p2.y)){
				if(!checkCollision(p3.x,p3.y)){
					if(!checkCollision(p4.x,p4.y)){
						//System.out.print("Not colliding!\n");
						return new int[0];
					}
				}
			}
		}
			
		int[] tiles = {currLevel.getTile(p1.x,p1.y).id,
				       currLevel.getTile(p2.x,p2.y).id,
				       currLevel.getTile(p3.x,p3.y).id,
				       currLevel.getTile(p4.x,p4.y).id,};
			
		//System.out.print("Colliding!\n");
		return tiles;
	}
	
	protected boolean checkCollision(int x, int y) {
		Tile tile = currLevel.getTile(x, y);
		if(tile.collide)return true;
		return false;
	}
	
	public void proccesCollidingTiles(int[] tiles){
	}
	
	public boolean checkForPlayer(){
		if(collideRect != null && Game.player.pRect != null){
			if(collideRect.intersects(Game.player.pRect)){
				return true;
			}
		}
		
		return false;
	}
	
	public void attack(int damage, int knockback){
	}
	
	public void hurt(int damage, int knockback){
		for(int i = 0; i < damage; i++){
		Game.particles.add(new BloodParticle(x+(width/2), y+(height/2), 1, 1, dirFacing, -65536));
		}
		hurt = true;
		health -= damage;
		if(health <= 0){
			health = 0;
		}
		
		if(dirFacing == 0){
			y += knockback;
		}
		if(dirFacing == 1){
			x -= knockback;
		}
		if(dirFacing == 2){
			y -= knockback;
		}
		if(dirFacing == 3){
			x += knockback;
		}
		
	}
	
	public void hurt(int damage, int knockback, Bullet bullet){
		hurt = true;
		health -= damage;
		if(health <= 0){
			health = 0;
		}
		int bloodDir = 0;
		if(bullet.dir == 0){
			y -= knockback;
			bloodDir = 2;
		}
		if(bullet.dir == 1){
			x += knockback;
			bloodDir = 3;
		}
		if(bullet.dir == 2){
			y += knockback;
			bloodDir = 0;
		}
		if(bullet.dir == 3){
			x -= knockback;
			bloodDir = 1;
		}	
		for(int i = 0; i < damage; i++){
			Game.particles.add(new BloodParticle(x+(width/2), y+(height/2), 1, 1, bloodDir, -65536));
		}
		
	}
	
	public void heal(int healing){
		health += healing;
		if(health >= maxHealth){
			health = maxHealth;
		}
	}
	
	public void die(){
		try {for(int i = 0; i < 100; i++)Game.particles.add(new Particle(x+(width/2), y+(height/2), 1, 1, -65536));}
		catch (Exception e){ e.printStackTrace(); System.out.println("Particle render error;");}
		dead = true;
		collideRect = null;
		Game.totalKills ++;
		Rank.addExp(killExp);
		System.out.println("Gained Exp: "+killExp);
	}
	
	public void ambientSound(){
	}
	
	public void render(int xOffs, int yOffs, Screen screen) {
		if(dead)return;
		screen.setOffs(xOffs, yOffs);
		
		if(hurt){
			screen.renderSprite(x, y, walkAnim.getCurrSprite(), 0, 16); 
			hurtTick++;
			if(hurtTick > 15){
				hurt = false;
				hurtTick = 0;
			}
		}else{
			screen.renderSprite(x, y, walkAnim.getCurrSprite());
		}
		
		screen.setOffs(0, 0);
		if(Moving){
			if(!walkAnim.isRunning()){
				walkAnim.start();
			}
		}else{
			if(walkAnim.isRunning()){
				walkAnim.stop();
			}
		}
		Moving = false;
	}
	
	
	//EXTERNAL METHODS
	public static void spawnMob(Mob mob, int amount){	
		int spawned = 0;
		if(mob == ZOMBIE){
			if(zNum >= zombies.length)return;
			
			for(int i = 0; i < zombies.length; i++){
				if(zombies[i] != null)continue;
				
				zombies[i] = new Zombie(i, mob.x,mob.y,mob.width,mob.height,mob.health,mob.maxHealth,mob.speed,mob.killExp,mob.dead);
				zombies[i].changeLevel(Game.currLevel);
				
				spawned ++;
				if(spawned + zNum > zombies.length){zNum = zombies.length; updateMobNum(); return;}
				if(spawned >= amount)break;
			}
			zNum += amount;
			if(zNum >= zombies.length)zNum = zombies.length;
		}
		if(mob == TROLL){
			if(tNum >= trolls.length)return;
			
			for(int i = 0; i < trolls.length; i++){
				if(trolls[i] != null)continue;
				
				trolls[i] = new Troll(i, mob.x,mob.y,mob.width,mob.height,mob.health,mob.maxHealth,mob.speed,mob.killExp,mob.dead);
				trolls[i].changeLevel(Game.currLevel);
				
				spawned++;
				if(spawned + tNum > trolls.length){tNum = trolls.length; updateMobNum(); return;}
				if(spawned >= amount)break;
			}
			tNum += amount;
			if(tNum >= trolls.length)tNum = trolls.length;
		}
		
		updateMobNum();	
	}

	public static void removeMob(Mob mob, int amount){	
		if(mob == ZOMBIE){
			if(zNum - amount < 0){
				for(int i = 0; i < zNum; i++){
					zombies[i] = null;
				}
			}else{
				for(int i = zNum - amount; i < zNum; i++){
					zombies[i] = null;
				}
			}
			zNum -= amount;
			if(zNum <= 0)zNum = 0;
		}
		if(mob == TROLL){
			if(tNum - amount < 0){
				for(int i = 0; i < tNum; i++){
					trolls[i] = null;
				}
			}else{
				for(int i = tNum - amount; i < tNum; i++){
					trolls[i] = null;
				}
			}
			tNum -= amount;
			if(tNum <= 0)tNum = 0;
		}
		
		updateMobNum();
	}
	
	private static int updateMobNum(){
		if(zNum > tNum)mobNum = zNum;
		else mobNum = tNum;
		
		if(mobNum >= 100)mobNum = 100;
		if(mobNum <= 0)mobNum = 0;
		
		return mobNum;
	}
	
	public void changeLevel(Level level) {	
		currLevel = level;
	}
}

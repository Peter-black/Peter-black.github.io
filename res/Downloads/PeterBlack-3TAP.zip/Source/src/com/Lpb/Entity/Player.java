package com.Lpb.Entity;

import java.util.ArrayList;
import java.util.Random;

import com.Lpb.Game;
import com.Lpb.InputHandler;
import com.Lpb.Geom.Point;
import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.BloodParticle;
import com.Lpb.Graphics.HealParticle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Graphics.SprintParticle;
import com.Lpb.Graphics.TextParticle;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Level.Level;
import com.Lpb.Menu.Menu;
import com.Lpb.Sounds.Sound;
import com.Lpb.Sprites.Sprites;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Tiles.Tile;

/*dirFacing
 * 1 = right
 * 3 = left
 * 2 = down
 * 0 = up
 */

public class Player {
	public static final int TILE_SIZE = 32;
	public static final int HEIGHT = 32;
	public static final int WIDTH = 32;
	private Game game = new Game();
	private Level currLevel;
	
	public int pX = 300;
	public int pY = 300;
	public double dX = 0;
	public double dY = 0;
	public int pW = 32;
	public int pH = 36;
	public int pR = 100;
	private int xOffset = 0;
	private int yOffset = 8;
	public Rectangle pRect;
	public Rectangle pRadius = new Rectangle(pX-(pR/2), pY-(pR/2), pR, pR);
	
	public int dirFacing = 0;
	public int lastFacing = 0;
	public boolean Moving = false;
	public SpriteAnimator walkAnim;
	
	public int maxHealth = 100;
	public int health = maxHealth;
	public Object lastHitBy;
	private boolean hurt = false;
	private boolean healed = false;
	public boolean dead = false;
	private int hurtTick = 0;
	private int healedTick = 0;
	private Random hurtSound;	
	private ArrayList<TextParticle> particles = new ArrayList<TextParticle>();
	
	public Player(){
		pRect = new Rectangle(pX, pY, pW, pH);
		pRadius = new Rectangle(pX-(pR/2), pY-(pR/2), pR, pR);
		walkAnim = new SpriteAnimator(Sprites.player,15);
		walkAnim.start();
	}
	
	public void render(int xOffs,int yOffs,Screen screen){
		screen.setOffs(xOffs, yOffs);

		if(healed){
			screen.renderSprite(pX,pY, walkAnim.getCurrSprite(), 0, 8); 
			healedTick++;
			if(healedTick > 15){
				healed = false;
				healedTick = 0;
			}
		}else if(hurt){
			screen.renderSprite(pX,pY, walkAnim.getCurrSprite(), 0, 16); 
			hurtTick++;
			if(hurtTick > 15){
				hurt = false;
				hurtTick = 0;
			}
		}else{
			screen.renderSprite(pX,pY, walkAnim.getCurrSprite());
		}

		screen.setOffs(0, 0);
		if(Moving){
			if(!walkAnim.isRunning()){
				walkAnim.start();
			}
		}else{
			if(walkAnim.isRunning()){
				walkAnim.stop();
			}
		}
		Moving = false;
	}
	
	public void setDX(double dx){
		if(dx != 0)Moving = true;
		if(dx < -0.50)if(Game.tick%2 == 0)Game.particles.add(new SprintParticle(pX+(pW/2), pY+pH, 1, 1, dirFacing, currLevel.getTile((pX+(pW/2))/16, (pY+pH)/16).color));
		if(dx > 1.00)if(Game.tick%2 == 0)Game.particles.add(new SprintParticle(pX+(pW/2), pY+pH, 1, 1, dirFacing, currLevel.getTile((pX+(pW/2))/16, (pY+pH)/16).color));
		
		dX = dx;
	}
	
	public void setDY(double dy){
		if(dy != 0)Moving = true;
		if(dy < -0.50)if(Game.tick%2 == 0)Game.particles.add(new SprintParticle(pX+(pW/2), pY+pH, 1, 1, dirFacing, currLevel.getTile((pX+(pW/2))/16, (pY+pH)/16).color));
		if(dy > 1.00)if(Game.tick%2 == 0)Game.particles.add(new SprintParticle(pX+(pW/2), pY+pH, 1, 1, dirFacing, currLevel.getTile((pX+(pW/2))/16, (pY+pH)/16).color));
		
		dY = dy;
	}
	
	public double getDX(){
		return dX;
	}
	
	public double getDY(){
		return dY;
	}
	
	public void tick(){
		if(dead)try {game.respawn();} catch (Exception e) {}
		
		pRect.x = pX;
		pRect.y = pY;
		pRect.w = pW;
		pRect.h = pH;
		
		pRadius.x = pX-(pR/2);
		pRadius.y = pY-(pR/2);
		
		int x = (int) InputHandler.mX + Game.xScroll;
		int y = (int) InputHandler.mY + Game.yScroll;

		int deltX = Math.abs(x - pX);
		int deltY = Math.abs(y - pY);
		
		if(deltY > deltX && y < pY)dirFacing = 0;
		if(deltY > deltX && y > pY)dirFacing = 2;
		if(deltY < deltX && x < pX)dirFacing = 3;
		if(deltY < deltX && x > pX)dirFacing = 1;

		for(int i = 0; i < particles.size(); i++){
			particles.get(i).tick();
			if(particles.get(i).remove)particles.remove(i);
		}
		
		//If moving in a direction, check the collision infront of you, if you aren't colliding, move.
		int[] tiles = new int[0];
		if(dX > 0.00){tiles = checkCollision(pX + xOffset + (int)dX ,pY + yOffset ,WIDTH,HEIGHT);if(tiles.length<3)pX += 15 * dX * 0.1;}
		if(dX < 0.00){tiles = checkCollision(pX + xOffset + (int)(dX*2),pY + yOffset,WIDTH,HEIGHT);if(tiles.length<3)pX += 15 * dX * 0.1;}
		if(dY < 0.00){tiles = checkCollision(pX + xOffset ,pY + yOffset + (int)(dY*2),WIDTH,HEIGHT);if(tiles.length<3)pY += 15 * dY * 0.1;}
		if(dY > 0.00){tiles = checkCollision(pX + xOffset ,pY + yOffset + (int)dY,WIDTH,HEIGHT);if(tiles.length<3)pY += 15 * dY * 0.1;}
		//If you are colliding, do collide.
		if(tiles.length > 3)processCollidingTiles(tiles);
		processNonCollidingTiles();
		
		if(lastFacing != dirFacing){
			walkAnim.setCurrentSet(dirFacing);
			lastFacing = dirFacing;
		}
	}
	
	public void changeLevel(Level level){
		currLevel = level;
	}
	
	private int[] checkCollision(int pX, int pY, int sizeX, int sizeY) {

		Point p1 = new Point(pX/TILE_SIZE,pY/TILE_SIZE);
		Point p2 = new Point((pX+sizeX-1)/TILE_SIZE,pY/TILE_SIZE);
		Point p3 = new Point((pX+sizeX-1)/TILE_SIZE,(pY+sizeY-1)/TILE_SIZE);
		Point p4 = new Point(pX/TILE_SIZE,(pY+sizeY-1)/TILE_SIZE);
			
		//checks the collision
		if(!checkCollision(p1.x,p1.y)){
			if(!checkCollision(p2.x,p2.y)){
				if(!checkCollision(p3.x,p3.y)){
					if(!checkCollision(p4.x,p4.y)){
						//System.out.print("Not colliding!\n");
						return new int[0];
					}
				}
			}
		}
			
		int[] tiles = {currLevel.getTile(p1.x,p1.y).id,
				       currLevel.getTile(p2.x,p2.y).id,
				       currLevel.getTile(p3.x,p3.y).id,
				       currLevel.getTile(p4.x,p4.y).id,};

		//System.out.print("Colliding!\n");
		return tiles;
		
	}
	
	private boolean checkCollision(int pX, int pY) {
		Tile tile = currLevel.getTile(pX, pY);
		//System.out.print("CurrTile: "+tile.toString()+"\n");
		if(tile.collide)return true;
		return false;
	}
	
	public void processCollidingTiles(int[] tiles){
		for(int i = 0; i < 4;i++){
			if(tiles[i] == Tile.rockTile.id){	
				Game.changeLevel(Game.LEVEL_ONE);
				
				//pX = 115;
				//pY = 230;
			}
		}
	}
	
	public void processNonCollidingTiles(){
		Point p1 = new Point(pX/TILE_SIZE,pY/TILE_SIZE);
		Point p2 = new Point((pX+pW-1)/TILE_SIZE,pY/TILE_SIZE);
		Point p3 = new Point((pX+pW-1)/TILE_SIZE,(pY+pH-1)/TILE_SIZE);
		Point p4 = new Point(pX/TILE_SIZE,(pY+pH-1)/TILE_SIZE);
			
		int[] tiles = {currLevel.getTile(p1.x,p1.y).id,
				       currLevel.getTile(p2.x,p2.y).id,
				       currLevel.getTile(p3.x,p3.y).id,
				       currLevel.getTile(p4.x,p4.y).id,};
		
		for(int i = 0; i < 4;i++){
			if(tiles[i] == Tile.fireTile.id){	
				if(Game.tick%2 == 0)hurt(1, 0, Tile.fireTile);
			}
		}
	}
	
	public boolean checkForBuilding(){
		for(int i = 0; i < checkCollision(pX-TILE_SIZE, pY-TILE_SIZE, 48, 48).length; i++){
			if(checkCollision(pX-TILE_SIZE, pY-TILE_SIZE, 48, 48).length == 0)return false;
			else if(checkCollision(pX-TILE_SIZE, pY-TILE_SIZE, 48, 48)[i] == Tile.building.id){
				return true;
			}
		}
		return false;
	}
	
	public boolean checkForItem(){
		if(Game.currItemMap.getItem((pX+16)/32, (pY+16)/32) != null){
			return true;
		}
		return false;
	}
	
	public void hurt(int damage, int knockback, Object obj){
		lastHitBy = obj;
		
		hurtSound = new Random();
		if(Sound.PLAYER_HURT_ONE.isRunning() || 
		   Sound.PLAYER_HURT_TWO.isRunning() || 
		   Sound.PLAYER_HURT_THREE.isRunning()){
		}else{
			switch(hurtSound.nextInt(3)){
			case 0:Sound.PLAYER_HURT_ONE.play();break;
			case 1:Sound.PLAYER_HURT_TWO.play();break;
			case 2:Sound.PLAYER_HURT_THREE.play();break;
			}
		}	
		for(int i = 0; i < damage; i++){
		Game.particles.add(new BloodParticle(pX+(pW/2), pY+(pH/2), 1, 1, dirFacing, -65536));
		}
		hurt = true;
		health -= damage;
		if(health <= 0){
			health = 0;
			die();
		}
		if(dirFacing == 0){
			pY += knockback;
		}
		if(dirFacing == 1){
			pX -= knockback;
		}
		if(dirFacing == 2){
			pY -= knockback;
		}
		if(dirFacing == 3){
			pX += knockback;
		}
	}
	
	public void heal(int amount){
		Sound.PLAYER_HEAL.play();
		for(int i = 0; i < amount/2; i++){
			Game.particles.add(new HealParticle(pX+(pW/2), pY+(pH/2), 1, 1, -16711936));
		}
		healed = true;
		health += amount;
		if(health >= maxHealth){
			health = maxHealth;
		}
	}
	
	public void die() {
		Game.setPaused(true);
		Menu.setMenu(Menu.DEAD_MENU);
		for(int i = 0; i < Inventory.inventory.length; i++){Inventory.removeItem(Inventory.inventory[i]);}
		dead = true;
		Game.totalDeaths++;
	}

}

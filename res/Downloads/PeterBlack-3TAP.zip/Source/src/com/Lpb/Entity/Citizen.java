package com.Lpb.Entity;

import com.Lpb.Events.Event;
import com.Lpb.Events.EventHandler;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Sprites.Sprites;
import com.Lpb.Tiles.Tile;

public class Citizen extends Npc{
	
	public Citizen(int id,int x,int y,int w,int h,int hl,int mh,double s,int ke,boolean d){
		super(id, x, y, w, h, hl, mh, s, ke, d);
		
		walkAnim = new SpriteAnimator(Sprites.citizen,15);
		walkAnim.start();
	}

	public void proccesCollidingTiles(int[] tiles){
		for(int i = 0; i < 4;i++){
			if(tiles[i] == Tile.rockTile.id){
				//hurt(2, 2);
			}
		}
	}
	
	public void speak(){
		EventHandler.speechBoxBoolean.set("Do you want to go on a Quest?", Event.QUEST);
		if(Event.QUEST.isStarted())EventHandler.speechBox.set("Try running right!");
		else if(Event.QUEST.isComplete()) EventHandler.speechBox.set("Well done completing that Quest!");
	}
	
	public void attack(int damage, int knockback){
	}
	
	public void ambientSound(){
	}
	
	public void die(){
		super.die();
		cNum --;
		npcs[0][id] = null;
	}
}

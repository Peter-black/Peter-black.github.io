package com.Lpb.Entity;

import com.Lpb.Game;
import com.Lpb.Geom.Point;
import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.Particle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Tiles.Tile;

public class Bullet implements Runnable {
	
	public static final int NORMAL = 0,
							SHOTGUN = 1;
	
	private int tick;
	
    public int x,y,w,h;
    public int tX, tY; //target x,y
    public double dX, dY;
    public int[] area;
    
    public boolean started = false;
    public boolean running;
    public int dir;
    
    public int distance;
    public int speed;
    public int damage;
    
    public int travDist = 0;
    public int trueDamage;
    public int number;
    
    public Bullet(int w, int h, int distance, int speed, int damage){
        this.w = w;
        this.h = h;
        this.distance = distance;
		this.speed = speed;
		this.damage = damage;
		this.trueDamage = damage;
		number = 1; //straight firing
		travDist = 0;
		
        area = new int[w*h];
    }
    
    /**
     * This is the shotgun bullet class
     * @param number This is which number in the series of 3 bullets for a shotgun is being fired. START FROM NUMBER 1.
     */
    public Bullet(int w, int h, int distance, int speed, int damage, int number){
        this.w = w;
        this.h = h;
        this.distance = distance;
		this.speed = speed;
		this.damage = damage;
		this.trueDamage = damage;
		this.number = number;
		travDist = 0;
		
        area = new int[w*h];
    }

    public void shoot(int GoToX, int GoToY){
    	this.tX = GoToX;
    	this.tY = GoToY;
    	running = true;
		new Thread(this).start();
    }
    public void setDX(double dx){
		dX = dx;
	}
	
	public void setDY(double dy){
		dY = dy;
	}
	
	public double getDX(){
		return dX;
	}
	
	public double getDY(){
		return dY;
	}
	
	public void tick() {
		travDist++;
		if(tick%6 == 0){
			if(dX > 0.00)x += 30 * dX;
			if(dX < 0.00)x += 30 * dX;
			if(dY < 0.00)y += 30 * dY;
			if(dY > 0.00)y += 30 * dY;
		}
		//Lowers damage as bullet travels (finish with half damage).
    	double perCentTrav = (double)(travDist)/(double)(distance);
    	int removeDamage = (int) ((double)(trueDamage/2)*perCentTrav);
    	damage = trueDamage - removeDamage;
	}

    public boolean intersects(Rectangle rect){
    	for(int i = x; i < x+w; i ++){
    	for(int j = rect.x; j< rect.x+rect.w; j++){
    	for(int k = y; k < y+h; k ++){
    	for(int l = rect.y; l< rect.y+rect.h; l++){
    		if(i == j && k == l){
    			return true;
    		}
    	}
    	}
    	}
    	}
    	return false;
    }
    
    public void checkCollision(){
    	for(int i = 0; i < Mob.mobs.length; i++){
    	for(int j = 0; j < Mob.mobNum; j++){
    		if(Mob.mobs[i][j] != null){
    		if(Mob.mobs[i][j].collideRect != null){
    			if(this.intersects(Mob.mobs[i][j].collideRect)){
    				System.out.println("HIT" + ": "+damage);
    				Mob.mobs[i][j].hurt(damage, 2, this);	
    				running = false;
    			}
    		}
    		}
    	}
    	}

    	Tile tile = Game.currLevel.getTile(x/32,y/32);

		if(tile.id == Tile.rockTile.id){
			for(int i = 0; i<3; i++){
			Game.particles.add(new Particle(x, y, 1, 1, tile.color));
			}
			running = false;
		}
		if(tile.id == Tile.building.id){
			for(int i = 0; i<3; i++){
			Game.particles.add(new Particle(x, y, 1, 1, tile.color));
			}
			running = false;
		}
    }
    
    private void calcDir(){
    	Point bulletPoint = new Point(x, y);
    	Point destPoint = new Point(tX, tY);
    	double angle = bulletPoint.getAngle(destPoint);
    	double xSpeed;
    	double ySpeed;
    	
    	if(number == 0){
    		xSpeed = Math.sin(angle+0.25);
        	ySpeed = Math.cos(angle+0.25);
    	}else if(number == 2){
    		xSpeed = Math.sin(angle-0.25);
        	ySpeed = Math.cos(angle-0.25);
    	}else{
    		xSpeed = Math.sin(angle);
    		ySpeed = Math.cos(angle);
    	}

	    setDX(xSpeed);
	    setDY(ySpeed);		
    }

	@Override
	public void run() {
		tick = 0;
		started = true;
		dir = Game.player.dirFacing;
    	if(dir == 0 || dir == 2){//orientation
    		int temp = w;
    		w = h;
    		h = temp;
    	}
		x = Game.player.pX + 16;
		y = Game.player.pY + 16;
		calcDir();
		while (running) {
			checkCollision();
			if(tick > distance){
				running = false; 
				setDX(0);
				setDY(0);
				tick=0;
			}		
			tick();
			tick++;
			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
    
	public void render(Screen screen){
		if(running)screen.renderRect(x - Game.xScroll, y - Game.yScroll, w, h, -256);
	}
	

}

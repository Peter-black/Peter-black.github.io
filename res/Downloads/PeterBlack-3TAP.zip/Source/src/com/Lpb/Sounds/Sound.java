package com.Lpb.Sounds;

import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import com.Lpb.Game;

public enum Sound {
	PLAYER_HURT_ONE("/sounds/playerHurt1.wav"),
	PLAYER_HURT_TWO("/sounds/playerHurt2.wav"),
	PLAYER_HURT_THREE("/sounds/playerHurt3.wav"),
	PLAYER_HEAL("/sounds/playerHeal.wav"),
	
	ZOMBIE_CASUAL_ONE("/sounds/zombieCasual1.wav"),
	ZOMBIE_CASUAL_TWO("/sounds/zombieCasual2.wav"),
	ZOMBIE_ATTACK_ONE("/sounds/zombieAttack1.wav"),
	ZOMBIE_DEATH("/sounds/zombieDeath.wav"),
	
	EMPTY_MAG("/sounds/emptyMag.wav"),
	
	SMG_SHOOT("/sounds/smgShoot.wav"),
	SMG_RELOAD("/sounds/smgReload.wav"),
	
	JAWK_SHOOT("/sounds/jawkShoot.wav"),
	JAWK_RELOAD("/sounds/jawkReload.wav"),
	
	KNIFE_ONE("/sounds/knife1.wav"),
	KNIFE_TWO("/sounds/knife2.wav"),
	KNIFE_THREE("/sounds/knife2.wav"),
	
	GAIN_MONEY("/sounds/moneyGained.wav"),
	LOSE_MONEY("/sounds/moneyLost.wav"),
	
	ADD_ITEM("/sounds/itemAdd.wav"),
	REMOVE_ITEM("/sounds/itemRemove.wav"),
	UPGRADE_ITEM("/sounds/itemUpgrade.wav");

	public static enum Volume {
		MUTE, LOW, MEDIUM, HIGH;
	}

	public static Volume volume = Volume.MEDIUM;
	
	public FloatControl gainControl;

	private Clip clip;

	Sound(String soundFileName) {
		try {	
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(Game.class.getResource(soundFileName));
			clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			
			gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
			
		} catch (UnsupportedAudioFileException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	public void play() {
		if (volume == Volume.MUTE) return;
		if (volume == Volume.LOW) gainControl.setValue(-30.0f); 
		if (volume == Volume.MEDIUM) gainControl.setValue(-15.0f); 
		if (volume == Volume.HIGH) gainControl.setValue(+06.0f); 
		
			if (clip.isRunning()) clip.stop();  
				clip.setFramePosition(0); 
				clip.start();   
		
	}
	
	public void stop() {
		clip.stop();
	}

	public static void init() {
		values();
	}
	
	public boolean isRunning(){
		return clip.isRunning();
	}
}

package com.Lpb;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import com.Lpb.Events.Rank;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Inventory.Item;
import com.Lpb.Sounds.Sound;

public class Write {

	public static void save() throws Exception{	
		//SAVE
		PrintWriter save = new PrintWriter("save/Player.sav");

	    save.println("\n");
	    save.println(Game.currLevel.id + "\n");
	    save.println(Game.player.pX + "\n");
	    save.println(Game.player.pY + "\n");
	    save.println(Game.xScroll + "\n");
	    save.println(Game.yScroll + "\n");
	    save.println(Game.player.health + "\n");
	    save.println(Rank.exp + "\n");
	    save.println(Rank.rank + "\n");
	    for(int i=0;i<Inventory.maxItems;i++){
	    	if(Inventory.inventory[i] == null)save.println("666" + "\n");//666 represents no item.=}
	    	else save.println(Inventory.inventory[i].id + "\n");
	    }
	    save.println("\n");
	    
	    save.close(); 
	}
	
	public static void saveStats() throws Exception{	
	    //STATS
	    PrintWriter stats = new PrintWriter("save/stats.sav");
	    
	    stats.println("\n");
	    stats.println(Game.totalKills + "\n");
	    stats.println(Game.totalDeaths + "\n");
	    stats.println(Game.totalMoneyGained + "\n");
	    stats.println(Game.totalMoneySpent + "\n");
	    stats.println("\n");
	    
	    stats.close(); 
	    
	    return;
	}
	
	public static void savePrefs() throws Exception {		
		PrintWriter prefs = new PrintWriter("save/prefs.sav");
		
		prefs.println("\n");
		prefs.println(Game.fullscreen + "\n");
		prefs.println(Game.Vsync + "\n");
		prefs.println(Sound.volume + "\n");
		prefs.println("\n");
		
		prefs.close();
	}
	
	public static void load() throws Exception, IOException{
		BufferedReader saveFile = new BufferedReader(new FileReader("save/Player.sav"));
		
		    saveFile.readLine(); 
		    
		    saveFile.readLine();
		    Game.changeLevel(Game.levels[Integer.parseInt(saveFile.readLine())]);
		    
		    saveFile.readLine();
		    Game.player.pX = Integer.parseInt(saveFile.readLine()); 
		    
		    saveFile.readLine();
		    Game.player.pY = Integer.parseInt(saveFile.readLine());
		    
		    saveFile.readLine();
		    Game.xScroll = Integer.parseInt(saveFile.readLine());
		    
		    saveFile.readLine();
		    Game.yScroll = Integer.parseInt(saveFile.readLine());

		    saveFile.readLine();
		    Game.player.health = Integer.parseInt(saveFile.readLine());
		    
		    saveFile.readLine();
		    Rank.exp = Integer.parseInt(saveFile.readLine());
		    
		    saveFile.readLine();
		    Rank.rank = Integer.parseInt(saveFile.readLine());
		    
		    for(int i=0;i<Inventory.maxItems;i++){
		    	saveFile.readLine();
		    	int itemID = Integer.parseInt(saveFile.readLine());
		    	if(itemID == 666){
		    		if(Inventory.inventory[i] != null){
		    			Inventory.removeItem(Inventory.inventory[i]);
		    		}else continue;					 
		    	}else{
		    		Inventory.addItem(Item.items[itemID]);
		    	}
		    }
		    
		    saveFile.close();

		    return;
	}
	
	public static void loadStats() throws Exception, IOException{
		BufferedReader saveFile = new BufferedReader(new FileReader("save/stats.sav"));
		
		    saveFile.readLine(); 
		    
		    saveFile.readLine();
		    Game.totalKills = Integer.parseInt(saveFile.readLine()); 
		    
		    saveFile.readLine();
		    Game.totalDeaths = Integer.parseInt(saveFile.readLine());

		    saveFile.readLine();
		    Game.totalMoneyGained = Integer.parseInt(saveFile.readLine());
		    
		    saveFile.readLine();
		    Game.totalMoneySpent = Integer.parseInt(saveFile.readLine());
		    
		    saveFile.close();

		    return;
	}
	
	public static void loadPrefs() throws Exception, IOException{
		BufferedReader saveFile = new BufferedReader(new FileReader("save/prefs.sav"));
				    
			saveFile.readLine(); 
		
		    saveFile.readLine();
		    if(Boolean.parseBoolean(saveFile.readLine()))Game.toggleFullscreen();
		    
		    saveFile.readLine();
		    Game.Vsync = Boolean.parseBoolean(saveFile.readLine());
	
		    saveFile.readLine();
		    String volume = String.valueOf(saveFile.readLine());
		    if(volume.equals("MUTE")){Sound.volume = Sound.Volume.MUTE;}
		    if(volume.equals("LOW")){Sound.volume = Sound.Volume.LOW;}
		    if(volume.equals("MEDIUM")){Sound.volume = Sound.Volume.MEDIUM;}
		    if(volume.equals("HIGH")){Sound.volume = Sound.Volume.HIGH;}
		    
		    saveFile.close();

		    return;
	}
}

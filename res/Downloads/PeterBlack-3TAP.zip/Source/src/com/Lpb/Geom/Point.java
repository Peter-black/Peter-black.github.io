package com.Lpb.Geom;

public class Point {
	
    public int x,y;
    
    public Point(int x , int y){
        this.x = x;
        this.y = y;
    }
    
    public double getAngle(Point target) {
        double angle = Math.atan2(target.x - x, target.y - y);
        return angle;
    }
}
package com.Lpb.Inventory;

import com.Lpb.Game;
import com.Lpb.Timer;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sounds.Sound;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Sprites.Sprites;

public class SG019 extends Item{
	
	private SpriteAnimator SG019Model;
	
	private Timer recharge = new Timer();
	
	public SG019(int id, Ammo aT, int b, int ms, int am, long rT, boolean a, int u, int mu, int v, int p, boolean has) {
		super(id, aT, b, ms, am, rT, a, u, mu, v, p, has);

		SG019Model = new SpriteAnimator(Sprites.SG019Model,15);
		SG019Model.start();
		SG019Model.stop();
		
		ammoType.firstReload(this);
	}
	
	public void tick(){
		ammoType.tick(this);
		
		SG019Model.setCurrentSet(Game.player.walkAnim.getCurrentSet());
		SG019Model.setCurrentFrame(Game.player.walkAnim.getCurrentFrame());
	}
	
	public void use(){
		shoot();
	}
	
	public void shoot(){
		if(recharge.checkTime()){
		ammoType.shoot(this, Sound.JAWK_SHOOT, Sound.EMPTY_MAG);
		recharge.start(750);
		}
	}
	
	public void reload(){			
		ammoType.reload(this, Sound.JAWK_RELOAD);
	}
	
	public void addAmmo(int amount){
		ammo += amount;
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, sprite, 0, upgrade);	

		for(int i = 0; i < Inventory.maxItems; i ++){
		if(Inventory.inventory[i] == this){
			Font.drawString(""+bullets, screen.w - 55, (screen.h-31) - i*24, -16777216, screen);
			Font.drawString("__", screen.w - 55, (screen.h-27) - i*24, -16777216, screen);
			Font.drawString(""+ammo, screen.w - 55, (screen.h-18) - i*24, -16777216, screen);
		}
		}
		
		if(Inventory.inventory[Inventory.selectedItem] == this){
		screen.renderSprite(Game.player.pX - Game.xScroll,Game.player.pY - Game.yScroll, SG019Model.getCurrSprite(), 0, upgrade);
		}
	}
	
	public void renderDropped(int x, int y, Screen screen) {
		screen.renderSprite(x, y, dropped, 0, upgrade);
	}

}

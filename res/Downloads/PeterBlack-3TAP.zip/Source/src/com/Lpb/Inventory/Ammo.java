package com.Lpb.Inventory;

import com.Lpb.Game;
import com.Lpb.InputHandler;
import com.Lpb.Timer;
import com.Lpb.Entity.Bullet;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sounds.Sound;

public class Ammo {
	
	public static final Ammo 
	PISTOL = new Ammo(2,1, 85, 5, 25, Bullet.NORMAL),
	ASSAULT = new Ammo(3,2, 200, 5, 40, Bullet.NORMAL),
	SMG = new Ammo(2,2, 150, 2, 25, Bullet.NORMAL),
	SHOTGUN = new Ammo(2,2, 40, 3, 50, Bullet.SHOTGUN);
	
	int w, h, distance, speed, damage, type;
	Bullet bullet;
	Bullet[] pellets = new Bullet[3];
	
	Timer reload = new Timer();

	public Ammo(int w, int h, int distance, int speed, int damage, int type) {
		this.w = w;
		this.h = h;
		this.distance = distance;
		this.speed = speed;
		this.damage = damage;
		this.type = type;
		
		if(type == Bullet.SHOTGUN){
			for(int i = 0; i<3; i++){
				pellets[i] = new Bullet(w, h, distance, speed, damage, i);
			}
			return;
		}
		bullet = new Bullet(w, h, distance, speed, damage);
	}

	public void tick(Item item){
		if(item.bullets <= 0)item.bullets = 0;
		if(item.ammo <= 0)item.ammo = 0;
		if(item.bullets >= item.magsize)item.bullets = item.magsize;
		for(int i = 0; i < item.magsize; i++){
			if(item.magazine.get(i) != null){
				if(item.magazine.get(i).isStarted() && !item.magazine.get(i).isRunning())item.magazine.set(i, null);
			}
		}
	}
	
	public void shoot(Item item, Sound shoot, Sound empty) {
		if(reload.checkTime()){
			if(item.bullets != 0)item.bullets--;
			else item.bullets = 0;
	
			if(item.magazine.get(item.bullets) == null){empty.play();System.out.println("RELOAD");return;}
			if(item.magazine.get(item.bullets).isStarted()){empty.play();System.out.println("RELOAD");return;}
			if(item.magazine.get(0).isRunning() == true){return;}
			
			shoot.play();
			item.magazine.get(item.bullets).shoot();
		}
	}
	
	public void shoot() {
		if(type == Bullet.SHOTGUN){
			for(int i = 0; i<3; i++){
				pellets[i].shoot((int)InputHandler.mX+Game.xScroll, (int)InputHandler.mY+Game.yScroll);
			}
			return;
		}
		
		bullet.shoot((int)InputHandler.mX+Game.xScroll, (int)InputHandler.mY+Game.yScroll);
	}
	
	public void firstReload(Item item){
		for(int i=0; i < item.magsize; i++){
			item.magazine.add(i, null);
		}
		for(int i=0; i < item.bullets; i++){
			item.magazine.add(i, new Ammo(item.ammoType.w, item.ammoType.h, item.ammoType.distance, item.ammoType.speed, item.ammoType.damage, item.ammoType.type));
			item.ammo --;
		}
	}
	
	public void reload(Item item, Sound reload){
		if(item.ammo == 0 || item.bullets == item.magsize)return;
		
		this.reload.start(item.reloadTime);

		reload.play();
		
		if(item.ammo + item.bullets >= item.magsize){
			while(item.bullets < item.magsize){
				item.ammo --;
				item.bullets ++;
				item.magazine.set(item.bullets-1, new Ammo(item.ammoType.w, item.ammoType.h, item.ammoType.distance, item.ammoType.speed, item.ammoType.damage, item.ammoType.type));
			}
		}else{
			while(item.bullets < item.bullets + item.ammo){
				item.ammo --;
				item.bullets ++;
				item.magazine.set(item.bullets-1, new Ammo(item.ammoType.w, item.ammoType.h, item.ammoType.distance, item.ammoType.speed, item.ammoType.damage, item.ammoType.type));
			}
		}
	}
	
	public void render(Screen screen){
		if(type == Bullet.SHOTGUN){
			for(int i = 0; i<3; i++){
				pellets[i].render(screen);
			}
			return;
		}
		
		bullet.render(screen);
	}
	
	public boolean isStarted() {
		if(type == Bullet.SHOTGUN){
			boolean anyStarted = false;
			for(int i = 0; i<3; i++){
				if(pellets[i].started)anyStarted = true;
			}
			return anyStarted;
		}
		
		return bullet.started;
	}

	public boolean isRunning() {
		if(type == Bullet.SHOTGUN){
			boolean anyRunning = false;
			for(int i = 0; i<3; i++){
				if(pellets[i].running)anyRunning = true;
			}
			return anyRunning;
		}
		return bullet.running;
	}
	
}

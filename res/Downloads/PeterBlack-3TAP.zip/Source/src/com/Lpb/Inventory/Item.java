package com.Lpb.Inventory;

import java.util.ArrayList;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Item {
	public int id;
	public int damage;
	public int range;
	public Ammo ammoType;
	public int bullets;
	public int magsize;
	public int ammo;
	public long reloadTime;
	public boolean automatic;
	public int upgrade;
	public int maxupgrade;
	public int value;
	public int price;
	public boolean hasItem;
	
	public int heal;
	public int hurt;
	
	public static ArrayList<AmmoBox> ammoBoxes = new ArrayList<AmmoBox>();
	public ArrayList<Ammo> magazine = new ArrayList<Ammo>();
	
	Sprite sprite;
	Sprite dropped;
	
	public static Item[] items = new Item[13];
	
	public static Item none = new Item(0,null,0,0,0,0,false,0,0,0,0,false);
	//GUNS
	public static Item Smg = new Smg(1,Ammo.SMG,25,25,120,1200,true,0,10,300,300,false);
	public static Item jawk = new Jawk(2,Ammo.PISTOL,7,7,40,800,false,0,5,250,250,false);
	public static Item SG019 = new SG019(7,Ammo.SHOTGUN,8,8,32,1200,false,0,5,250,250,false);
	public static Item KA32 = new KA32(4,Ammo.ASSAULT,45,45,100,1600,true,0,5,500,500,false);
	public static Item G46 = new G46(5,Ammo.ASSAULT,40,40,100,1400,false,0,5,700,700,false);
	public static Item MA19 = new MA19(6,Ammo.PISTOL,12,12,50,500,false,0,5,150,150,false);
	//MELEE
	public static Item knife = new Knife(3,75,10,0,2,75,75,false);
	//FOOD
	public static Item healthpack = new Healthpack(8,50,0,100,100,false);	
	
	// 9-10-11-12 = ammo 1, 2, 3, 4
	
	//GUNS
	public Item(int id, Ammo aT, int b,int ms, int am, long rT, boolean a, int u,int mu,int v,int p, boolean has){
		this.id = id;
		this.ammoType = aT;
		this.bullets = b;
		this.magsize = ms;
		this.ammo = am;
		this.reloadTime = rT;
		this.automatic = a;
		this.upgrade = u;
		this.maxupgrade = mu;
		this.value = v;
		this.price = p;
		this.hasItem = has;
		
		int x = id%8;
		int y = (id-x)/4;
		sprite = Sprites.items[x][y];
		dropped = Sprites.droppedItems[x*2][y+1];
		items[id] = this;
	}
	
	//MELEE
	public Item(int id,int d, int r, int u,int mu,int v,int p, boolean has){
		this.id = id;
		this.damage = d;
		this.range = r;
		this.upgrade = u;
		this.maxupgrade = mu;
		this.value = v;
		this.price = p;
		this.hasItem = has;
		
		int x = id%8;
		int y = (id-x)/4;
		sprite = Sprites.items[x][y];
		dropped = Sprites.droppedItems[x*2][y+1];
		items[id] = this;
	}
	
	//FOOD
	public Item(int id, int h, int d, int v,int p, boolean has){
		this.id = id;
		this.heal = h;
		this.hurt = d;
		this.value = v;
		this.price = p;
		this.hasItem = has;
		
		int x = id%8;
		int y = (id-x)/4;
		sprite = Sprites.items[x][y];
		dropped = Sprites.droppedItems[x*2][y+1];
		items[id] = this;
	}
	
	//SUPPLIES
	//AmmoBox
	public Item(Ammo aT, int amount){
	}
	
	public void tick(){
	}
	
	public void use(){
	}
	
	public void attack(){
	}
	
	public void shoot(){
	}
	
	public void reload(){
	}
	
	public void specialPower(){
	}
	
	public void addAmmo(int amount){
	}
	
	public void render(int x, int y, Screen screen) {
	}
	
	public void renderDropped(int x, int y, Screen screen) {
	}
	
}

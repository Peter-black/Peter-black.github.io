package com.Lpb.Inventory;

import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Timer;
import com.Lpb.Entity.Mob;
import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sounds.Sound;
import com.Lpb.Sprites.SpriteAnimator;
import com.Lpb.Sprites.Sprites;

public class Knife extends Item{
	
	public Rectangle attackRadius;
	private boolean attacked;
	private int attackDir;
	private int attackTick;
	private Random knifeSound;
	private SpriteAnimator knifeModel; 
	
	private Timer recharge = new Timer();
	
	public Knife(int id, int d, int r, int u, int mu, int v, int p, boolean has) {
		super(id, d, r, u, mu, v, p, has);

		knifeModel = new SpriteAnimator(Sprites.knifeModel,15);
		knifeModel.start();
		knifeModel.stop();
		
		switch(Game.player.dirFacing){
			case 0://up
				attackRadius = new Rectangle(Game.player.pX, Game.player.pY - range, 16, 16 + range);			
			break;
			
			case 1://right
				attackRadius = new Rectangle(Game.player.pX, Game.player.pY, 16 + range, 16);	
			break;
			
			case 2://down
				attackRadius = new Rectangle(Game.player.pX, Game.player.pY, 16, 16 + range);
			break;
			
			case 3://left
				attackRadius = new Rectangle(Game.player.pX - range, Game.player.pY, 16 + range, 16);
			break;
		}
		
	}
	
	public void tick(){
		if(attacked)attackTick++;
		if(attackTick >= 15){ attacked = false; attackTick = 0;}
		knifeModel.setCurrentSet(Game.player.walkAnim.getCurrentSet());
		knifeModel.setCurrentFrame(Game.player.walkAnim.getCurrentFrame());
	}
	
	public void use(){
		attack();
	}
	
	public void attack(){
		if(recharge.checkTime()){
			recharge.start(300);
			
			attacked = true;
			attackDir = Game.player.dirFacing;
			attackTick = 0;
			
			knifeSound = new Random();
			switch(knifeSound.nextInt(3)){
			case 0:Sound.KNIFE_ONE.play();break;
			case 1:Sound.KNIFE_TWO.play();break;
			case 2:Sound.KNIFE_THREE.play();break;
			}
			
			switch(Game.player.dirFacing){
			case 0://up
				attackRadius = new Rectangle(Game.player.pX, Game.player.pY - range, 16, 16 + range);			
			break;
			
			case 1://right
				attackRadius = new Rectangle(Game.player.pX, Game.player.pY, 16 + range, 16);	
			break;
			
			case 2://down
				attackRadius = new Rectangle(Game.player.pX, Game.player.pY, 16, 16 + range);
			break;
			
			case 3://left
				attackRadius = new Rectangle(Game.player.pX - range, Game.player.pY, 16 + range, 16);
			break;
			}
			
			for(int i = 0; i < Mob.mobs.length; i++){
	    		for(int j = 0; j < Mob.mobNum; j++){
	    			if(Mob.mobs[i][j] != null){
	    				if(attackRadius.intersects(Mob.mobs[i][j].collideRect)){
	    					System.out.println("HIT" + ": "+damage);
	    					Mob.mobs[i][j].hurt(damage, 2);
	    				}
	    			}
	    		}
	    	}
		}
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, sprite, 0, upgrade);
		
		for(int i = 0; i < Inventory.maxItems; i ++){
		if(Inventory.inventory[i] == this){
			Font.drawString("��", screen.w - 55, (screen.h-25) - i*24, -16777216, screen);//�� makes the infinity symbol
		}
		}
		
		if(Inventory.inventory[Inventory.selectedItem] == this){
			screen.renderSprite(Game.player.pX - Game.xScroll,Game.player.pY - Game.yScroll, knifeModel.getCurrSprite(), 0, upgrade);
		}
		
		if(Inventory.inventory[Inventory.selectedItem] != this){ attacked = false; attackTick = 0;}
		if(attacked){
			switch(attackDir){
			case 0://up
				screen.renderSprite(Game.player.pX - Game.xScroll + 2, Game.player.pY - Game.yScroll - 8, Sprites.knifeSwing[attackDir][0]);
				break;
			case 1://right
				screen.renderSprite(Game.player.pX - Game.xScroll + 14, Game.player.pY - Game.yScroll + 7, Sprites.knifeSwing[attackDir][0]);
				break;
			case 2://down
				screen.renderSprite(Game.player.pX - Game.xScroll + 2, Game.player.pY - Game.yScroll + 17, Sprites.knifeSwing[attackDir][0]);
				break;
			case 3://left
				screen.renderSprite(Game.player.pX - Game.xScroll - 8, Game.player.pY - Game.yScroll + 7, Sprites.knifeSwing[attackDir][0]);
				break;
			}
		}
		
	}
	
	public void renderDropped(int x, int y, Screen screen) {
		screen.renderSprite(x, y, dropped, 0, upgrade);
	}

}

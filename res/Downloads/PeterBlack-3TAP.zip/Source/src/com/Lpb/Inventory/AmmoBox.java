package com.Lpb.Inventory;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class AmmoBox extends Item{
	int amount;
	
	public AmmoBox(Ammo aT, int amount) {
		super(aT, amount);
		
		this.ammoType = aT;
		this.amount = amount;
		
		if(aT == Ammo.PISTOL)dropped = Sprites.droppedItems[2][3];
		if(aT == Ammo.SMG)dropped = Sprites.droppedItems[4][3];
		if(aT == Ammo.ASSAULT)dropped = Sprites.droppedItems[6][3];
		if(aT == Ammo.SHOTGUN)dropped = Sprites.droppedItems[8][3];
		
		ammoBoxes.add(this);
	}
	
	public void renderDropped(int x, int y, Screen screen) {
		screen.renderSprite(x, y, dropped);
	}

}

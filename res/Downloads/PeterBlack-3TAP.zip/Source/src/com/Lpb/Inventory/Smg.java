package com.Lpb.Inventory;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sounds.Sound;

public class Smg extends Item{
	
	public Smg(int id, Ammo aT, int b, int ms, int am, long rT, boolean a, int u, int mu, int v, int p, boolean has) {
		super(id, aT, b, ms, am, rT, a, u, mu, v, p, has);

		ammoType.firstReload(this);
	}
	
	public void tick(){
		ammoType.tick(this);
	}
	
	public void use(){
		shoot();
	}
	
	public void shoot(){
		ammoType.shoot(this, Sound.SMG_SHOOT, Sound.EMPTY_MAG);
	}
	
	public void reload(){
		ammoType.reload(this, Sound.SMG_RELOAD);
	}
	
	public void addAmmo(int amount){
		ammo += amount;
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, sprite, 0, upgrade);
		
		for(int i = 0; i < Inventory.maxItems; i ++){
		if(Inventory.inventory[i] == this){
			Font.drawString(""+bullets, screen.w - 55, (screen.h-31) - i*24, -16777216, screen);
			Font.drawString("__", screen.w - 55, (screen.h-27) - i*24, -16777216, screen);
			Font.drawString(""+ammo, screen.w - 55, (screen.h-18) - i*24, -16777216, screen);
		}
		}
	}
	
	public void renderDropped(int x, int y, Screen screen) {
		screen.renderSprite(x, y, dropped, 0, upgrade);
	}

}

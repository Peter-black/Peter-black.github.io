package com.Lpb.Inventory;

import com.Lpb.Game;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sounds.Sound;

public class Inventory {

	public static int money = 1500;
	
	public static int itemCount = 0;
	public static int maxItems = 3;
	public static int selectedItem = 0;
	public static Item[] inventory = new Item[maxItems];

	public Inventory(){		
	}
	
	public void tick(){
		if(money < 0)money = 0;
		if(money > 1500000000)money = 1500000000;
		if(selectedItem < 0) selectedItem = maxItems-1;
		if(selectedItem > maxItems-1) selectedItem = 0;
		if(inventory[selectedItem] != null)inventory[selectedItem].tick();
		if(itemCount < 0)itemCount = 0;
		if(itemCount > maxItems)itemCount = maxItems;
	}
	
	public void render(int xPos, int yPos, Screen screen) {
		Font.drawString("�"+money, screen.w - 59, screen.h - 28 - 63, -16777216, screen);
		for(int i = 0; i < maxItems; i++){
			if(inventory[i] != null){
				inventory[i].render(screen.w - 35, (screen.h-28) -i*24, screen);
			}
		}
	}
	
	public static void addMoney(int amount){
		Sound.GAIN_MONEY.play();
		Game.totalMoneyGained += amount;
		money += amount;
	}
	
	public static void removeMoney(int amount){
		if(money - amount >= 0){
			Sound.LOSE_MONEY.play();
			Game.totalMoneySpent += amount;
			money -= amount;
		}else{System.out.println("You cannot afford this"); return;}
	}
	
	public static boolean addItem(Item item){
		if(item.hasItem == true){System.out.println("HASITEM"); return false;
		}else{			
			for(int i = 0; i < maxItems; i++){
				if(inventory[i] == null){
					Sound.ADD_ITEM.play();
					itemCount ++;
					inventory[i] = item;
					item.hasItem = true; 
					return true;}
			}
			
			System.out.println("Inventory Full");
			return false;
		}
	}
	
	public static boolean removeItem(Item item){
		if(item == null)return false;
		for(int i = 0; i < maxItems; i++){
			if(inventory[i] == item){
				Sound.REMOVE_ITEM.play();
				itemCount --;
				inventory[i] = null;
				item.hasItem = false; 
				item.upgrade = 0;
				item.price = item.value;
				return true;
			}
		}
		return false;
		
	}
	
	public static boolean addAmmo(int amount, Ammo type){
		if(inventory[selectedItem] == null)return false;
		if(type == inventory[selectedItem].ammoType){
			inventory[selectedItem].ammo += amount;
			return true;
		}else{ System.out.println("Wrong ammo type!"); return false;}
	}
	
	public static boolean removeAmmo(int amount, Ammo type){
		if(inventory[selectedItem] == null)return false;
		if(type == inventory[selectedItem].ammoType){
			inventory[selectedItem].ammo += amount;
			return true;
		}else{ System.out.println("Wrong ammo type!"); return false;}
	}
	
	public static boolean addAmmo(AmmoBox ammoBox){
		if(inventory[selectedItem] == null)return false;
		if(ammoBox.ammoType == inventory[selectedItem].ammoType){
			inventory[selectedItem].ammo += ammoBox.amount;
			return true;
		}else{ System.out.println("Wrong ammo type!"); return false;}
	}
	
	public static boolean removeAmmo(AmmoBox ammoBox){
		if(inventory[selectedItem] == null)return false;
		if(ammoBox.ammoType == inventory[selectedItem].ammoType){
			inventory[selectedItem].ammo -= ammoBox.amount;
			return true;
		}else{ System.out.println("Wrong ammo type!"); return false;}
	}
	
	public static void upgradeItem(Item item){
		if(item != null){
			if(item.hasItem){
				if(item.upgrade+1 <= item.maxupgrade){	
					if(money >= item.price){		
						Sound.UPGRADE_ITEM.play();
						item.upgrade ++;			
						removeMoney(item.price);
						Sound.LOSE_MONEY.stop();
						item.price = item.price * (item.upgrade+1);
						item.damage = item.damage * (item.upgrade);
					}else{System.out.println("You cannot afford this");}
				}else{System.out.println("This item has been upgraded fully");}		
			}	
		}
	}
	
	public static void buyItem(Item item){
		if(item !=null){
			if(!item.hasItem){
				if(money >= item.price){	
					
					if(addItem(item))removeMoney(item.price);//If adding succeeds remove money else don't.
					
				}else{ System.out.println("Cannot afford item");}
			}else{System.out.println("You already own this item");}
		}else{return;}
	}
	
	public static void sellItem(Item item){
		if(item != null){
			if(item.hasItem){
				removeItem(item);
				addMoney(item.price/(item.upgrade+1));			
			}else{System.out.println("You can't sell something you don't own");}
		}else{return;}
	}
	
	public int getMoney(){
		return money;
	}
	
}

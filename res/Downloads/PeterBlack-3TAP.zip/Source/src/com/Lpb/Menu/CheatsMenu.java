package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Entity.Mob;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Sprites.Sprites;

public class CheatsMenu extends Menu {

	public CheatsMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: System.out.println("Giving player �69696969");
				Inventory.addMoney(69696969);
				break;		
				
		case 1: Game.changeLevel(Game.levels[1]);
				break;
				
		case 2: Mob.spawnMob(Mob.ZOMBIE, 1);
				break;
		
		case 3: Mob.spawnMob(Mob.TROLL, 1);
				break;
						
		case 4: setMenu(OPTIONS_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Add Money";
		options[1] = "Change Level";
		options[2] = "Spawn 1 Zombie";
		options[3] = "Spawn 1 Troll";
		options[4] = "Return";
	}
}
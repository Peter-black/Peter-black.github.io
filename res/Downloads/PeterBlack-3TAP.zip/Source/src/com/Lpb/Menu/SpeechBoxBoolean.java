package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Events.Event;
import com.Lpb.Graphics.Font;

public class SpeechBoxBoolean {

	private static int x,y,w,h;
	private static boolean selected = true;
	private static boolean active = false;
	private static boolean choice;
	private static Event event;
	private static int checkpoint;
	private static String message;
	
	public SpeechBoxBoolean(){
	}

	public void render(){
		if(active){
			Game.screen.renderRect(x, y, w, h, -16777216);
			Game.screen.renderRect(x + w - 12, y-20, 30, 30, -13421773);
			
			Font.drawString(""+message, x+6, y+5, -16738125, Game.screen);
			
			if(selected){
				Font.drawString("YES", x+w-6, y-15, -1, Game.screen);
				Font.drawString("NO", x+w-3, y-3, -16738125, Game.screen);
			}else{
				Font.drawString("YES", x+w-6, y-15, -16738125, Game.screen);
				Font.drawString("NO", x+w-3, y-3, -1, Game.screen);
			}
		}
	}
	
	public void set(String Message){
		message = Message;
		w = 300;
		h = 60;
		x = Game.WIDTH/2 - 140;
		y = Game.HEIGHT - 88;

		active = true;
	}
	
	/**
	 * This method will start the selected Event if YES is selected.
	 * @param Message This is the message you want to appear when asked.
	 * @param Event This is the Event you want to start.
	 */
	public void set(String Message, Event Event){
		message = Message;
		event = Event;
		w = 300;
		h = 60;
		x = Game.WIDTH/2 - 140;
		y = Game.HEIGHT - 88;

		if(event != null && !event.isStarted() && !event.isComplete())active = true;
		else stop();
	}
	
	/**
	 * This method will add the number of checkpoints to the selected event if YES is selected.
	 * @param Message This is the message you want to appear when asked.
	 * @param Event This is the Event you want to add checkpoints to.
	 * @param Checkpoint This is the number of checkpoints you want to add.
	 */
	public void set(String Message, Event Event, int Checkpoint){
		message = Message;
		event = Event;
		checkpoint = Checkpoint;
		w = 300;
		h = 60;
		x = Game.WIDTH/2 - 140;
		y = Game.HEIGHT - 88;

		if(event != null && !event.isStarted() && !event.isComplete())active = true;
		else stop();
	}
	
	public void choose(){
		if(selected){
			choice = true;
			event.start();
			if(checkpoint > 0)event.checkpoint(checkpoint);
			stop();
		}else if(!selected){
			choice = false;
			stop();
		}
		else return;	
	}
	
	public void select(){
		if(selected){
			selected = false;
		}else selected = true;
	}
	
	public boolean getChoice(){
		return choice;
	}

	public void stop(){
		Game.setPaused(false);
		event = null;
		checkpoint = 0;
		active = false;
	}
	
	public boolean isRunning(){
		return active;
	}
	
}

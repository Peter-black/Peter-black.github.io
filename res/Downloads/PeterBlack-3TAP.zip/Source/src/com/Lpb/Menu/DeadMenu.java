package com.Lpb.Menu;

import java.io.IOException;

import com.Lpb.Game;
import com.Lpb.Write;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class DeadMenu extends Menu {

	public DeadMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}
	
	public void render(int x, int y, Screen screen) {	
		
		Game.screen.darken(2);
		
		Font.drawString(Game.getDeathString(Game.player.lastHitBy), (Game.WIDTH - (Game.getDeathString(Game.player.lastHitBy).length()*12))/2, 50, -16738125, Font.MENU_FONT, screen);
		
		for(int i = 0; i < maxItems; i++){
			if(selectedItem == i)Font.drawString(options[i] , x + (Game.WIDTH - options[i].length()*6)/2, y + Game.HEIGHT/2 - (maxItems*15) + i * 15, -8073241, screen);
			else Font.drawString(options[i] , x + (Game.WIDTH - options[i].length()*6)/2, y + Game.HEIGHT/2 - (maxItems*15) + i * 15, -16738125, screen);
		}	
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: try {Write.load();} 
				catch (IOException e){
				try {Write.save();} catch (Exception e1) {e1.printStackTrace();}
				System.out.println("No save game found, creating new one...");
				e.printStackTrace();}
				catch (Exception e){
				e.printStackTrace();}
		
				Game.setPaused(false);
				setMenu(NO_MENU);
				break;
				
		case 1: setMenu(TITLE_MENU);
				break;		
		}
	}
	
	protected void setOptions(){
		options[0] = "Restart Checkpoint";
		options[1] = "Exit to Menu";
	}
}
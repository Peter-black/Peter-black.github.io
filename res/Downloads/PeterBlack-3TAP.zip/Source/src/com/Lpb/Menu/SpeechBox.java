package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Graphics.Font;

public class SpeechBox {

	private static int x,y,w,h;
	
	private static boolean active = false;
	private static String message;
	
	public SpeechBox(){
	}
	
	public void render(){
		if(active){
			Game.screen.renderRect(x, y, w, h, -16777216);
			Font.drawString(""+message, x+6, y+5, -16738125, Game.screen);
		}
	}
	
	public void set(String Message){
		message = Message;
		w = 300;
		h = 60;
		x = Game.WIDTH/2 - 140;
		y = Game.HEIGHT - 88;

		active = true;
	}

	public void stop(){
		Game.setPaused(false);
		active = false;
	}
	
	public boolean isRunning(){
		return active;
	}
}

package com.Lpb.Menu;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Sprites.Sprites;

public class SellMenu extends Menu {

	public SellMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 
		
		
		background = Sprites.menuBg[0][0];
	}

	public void render(int x, int y, Screen screen) {
		super.render(x, y, screen);
		
		try{
			if(Inventory.inventory[Inventory.selectedItem] != null){
				Font.drawString("�"+(int)(Inventory.inventory[Inventory.selectedItem].price/(Inventory.inventory[Inventory.selectedItem].upgrade+1)), x + 153 + 150, y + 60 + 7, -16777216, screen);
			}
		}catch(Exception e){};
		
		Font.drawString(TITLE, x + 153 + 30, y + 5, -1, Font.MENU_FONT, screen);
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: Inventory.sellItem(Inventory.inventory[Inventory.selectedItem]);
				break;
				
		case 1: setMenu(SHOP_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Sell Selected Item";
		options[1] = "Close";
	}
}
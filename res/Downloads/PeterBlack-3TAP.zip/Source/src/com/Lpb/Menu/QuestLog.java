package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Events.Event;
import com.Lpb.Events.EventHandler;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class QuestLog extends Menu {
	
	static final int ACTIVE = 0, COMPLETE = 1;
	int currTab = ACTIVE;
	
	String[] quests;
	Event[] activeQuests;
	Event[] completedQuests;

	public QuestLog(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}
	
	public void tick(){
		super.tick();
		if(currTab == ACTIVE && scroll >= (activeQuests.length*40)-200){scrollLockDown = true; scroll = (activeQuests.length*40)-200;}
		else scrollLockDown = false;
		
		if(currTab == COMPLETE && scroll >= (completedQuests.length*40)-200){scrollLockDown = true; scroll = (completedQuests.length*40)-200;}
		else scrollLockDown = false;
		
		if(scroll <= 0){scrollLockUp = true; scroll = 0;}
		else scrollLockUp = false;
	}

	public void render(int x, int y, Screen screen){
		super.render(x, y, screen);
		
		if(currTab == ACTIVE){
			Font.drawString("ACTIVE", 153+87-18, y+60+7+10-35, -1, screen);
			for(int i = 0; i < activeQuests.length; i++){	
				if(y+60+7-5+i*40-scroll > y+60+7-5-40){
				if(y+60+7-5+i*40-scroll < y+60+7-5+200){
					screen.renderRect(x+153+87-75, y+60+7-5+i*40-scroll, 150, 30, -13421773);
					int barWidth = (int) (((double)(activeQuests[i].getCheckpoint()) / (double)(activeQuests[i].getMaxCheckpoint()))*100);
					screen.renderRect(x+153+87-50, y+60+7+10+i*40-scroll, 100, 10, -16738125);
					screen.renderRect(x+153+87-50, y+60+7+10+i*40-scroll,barWidth, 10, -8073241);
					Font.drawString(activeQuests[i].getCheckpoint() + " / " + activeQuests[i].getMaxCheckpoint() , x+153+87-15, y+60+7+10+i*40-scroll, -13421773,screen);
					Font.drawString(quests[i] , x + 153 + 87 - quests[i].length()*3, y+60+5+i*40-scroll, -1,screen);
				}else Font.drawString("v", 153+87-3, y+60+7+10+175, -1, screen);
				}else Font.drawString("^", 153+87-3, y+60+7+10-23, -1, screen);
			}
		}
		
		if(currTab == COMPLETE){
			Font.drawString("COMPLETED", 153+87-27, y+60+7+10-35, -1, screen);
			for(int i = 0; i < completedQuests.length; i++){	
				if(y+60+7-5+i*40-scroll > y+60+7-5-40){
				if(y+60+7-5+i*40-scroll < y+60+7-5+200){
					screen.renderRect(x+153+87-75, y+60+7-5+i*40-scroll, 150, 30, -13421773);
					screen.renderRect(x+153+87-50, y+60+7+10+i*40-scroll,100, 10, -8073241);
					Font.drawString("COMPLETE" , x+153+87-24, y+60+7+10+i*40-scroll, -13421773,screen);
					Font.drawString(quests[i] , x + 153 + 87 - quests[i].length()*3, y+60+5+i*40-scroll, -1,screen);
				}else Font.drawString("v", 153+87-3, y+60+7+10+175, -1, screen);
				}else Font.drawString("^", 153+87-3, y+60+7+10-23, -1, screen);
			}
		}
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: if(currTab == ACTIVE){
					currTab = COMPLETE;
					setOptions(currTab);
				}
				else if(currTab == COMPLETE){
					currTab = ACTIVE;
					setOptions(currTab);
				}	
				break;
		
		case 1: Game.setPaused(false);
				setMenu(NO_MENU);
				break;	
		}	
	}
	
	protected void setOptions(){
		setOptions(currTab);
	}
	
	protected void setOptions(int tab){
		if(tab == ACTIVE){
			activeQuests = EventHandler.getActiveQuests();
			quests = new String[activeQuests.length];
			for(int i = 0; i < activeQuests.length; i++){
				quests[i] = activeQuests[i].toString();
			}
			
			options[0] = "Completed";
			options[1] = "Return";
		}
		
		if(tab == COMPLETE){
			completedQuests = EventHandler.getCompletedQuests();
			quests = new String[completedQuests.length];
			for(int i = 0; i < completedQuests.length; i++){
				quests[i] = completedQuests[i].toString();
			}
			
			options[0] = "Active";
			options[1] = "Return";
		}
	}
}
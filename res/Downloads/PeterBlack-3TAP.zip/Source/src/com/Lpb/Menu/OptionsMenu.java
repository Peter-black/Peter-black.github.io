package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Write;
import com.Lpb.Sounds.Sound;
import com.Lpb.Sprites.Sprites;

public class OptionsMenu extends Menu {

	public OptionsMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}

	public void chooseOption(int option){
		switch(option){
		case 0: Game.toggleFullscreen();
		
				try {Write.savePrefs();} 
				catch (Exception e2) {
				e2.printStackTrace();}
				
				setOptions();
				break;		
				
		case 1: if(!Game.Vsync)Game.Vsync = true;
				else Game.Vsync = false;
		
				try {Write.savePrefs();} 
				catch (Exception e2) {
				e2.printStackTrace();}
		
				setOptions();
				break;
				
		case 2: if(Sound.volume == Sound.Volume.MUTE)Sound.volume = Sound.Volume.LOW;
				else if(Sound.volume == Sound.Volume.LOW)Sound.volume = Sound.Volume.MEDIUM;
				else if(Sound.volume == Sound.Volume.MEDIUM)Sound.volume = Sound.Volume.HIGH;
				else if(Sound.volume == Sound.Volume.HIGH)Sound.volume = Sound.Volume.MUTE;
		
				try {Write.savePrefs();} 
				catch (Exception e2) {
				e2.printStackTrace();}

				setOptions();
				break;
				
		case 3: setMenu(CHEATS_MENU);
				break;
						
		case 4: setMenu(parentMenu);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Fullscreen: " + Game.fullscreen;
		options[1] = "VSync: " + Game.Vsync;
		options[2] = "Sound:" + Sound.volume;
		options[3] = "Cheats";
		options[4] = "Return";
	}
}
package com.Lpb.Menu;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class AboutMenu extends Menu {
	
	String about;
	
	public AboutMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
		
		about = "           3TAP "+'\n'+
				"(The Tower That Ate People)"+'\n'+
				'\n'+
				'\n'+	
				"        Programming"+'\n'+
				"   Peter Black"+'\n'+
				'\n'+	
				"           Design "+'\n'+
				"Szymon Libudzki"+'\n'+
				'\n'+	
				"        Sound Design"+'\n'+
				"Aidan Caulfield";
	}
	
	public void tick(){
		super.tick();
		selectedItem = 0;
	}

	public void render(int x, int y, Screen screen) {
		super.render(x, y, screen);
		Font.drawString(about, x + 153 + 6, y + 60, -1, screen);
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0:	setMenu(TITLE_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Return";
	}
}
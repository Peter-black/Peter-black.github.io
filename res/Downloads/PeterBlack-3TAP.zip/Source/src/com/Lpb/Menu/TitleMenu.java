package com.Lpb.Menu;

import java.io.IOException;

import com.Lpb.Game;
import com.Lpb.Write;
import com.Lpb.Sprites.Sprites;

public class TitleMenu extends Menu {
	
	public TitleMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title);

		background = Sprites.menuBg[0][0];
	}

	public void chooseOption(int option){		
		switch(option){
		case 0:	try {Game.resetGame();} 
				catch (Exception e2) {
				e2.printStackTrace();}

				Game.setPaused(false);
				setMenu(NO_MENU);
				break;
		
		case 1:	try {Write.load();} 
				catch (IOException e){
				try {Write.save();} catch (Exception e1) {e1.printStackTrace();}
				System.out.println("No save game found, creating new one...");
				e.printStackTrace();}
				catch (Exception e){
				e.printStackTrace();}

				Game.setPaused(false);
				setMenu(NO_MENU);
				break;
		
		case 2: setMenu(OPTIONS_MENU);
				break;
		
		case 3:	setMenu(STATS_MENU);
				break;
				
		case 4: setMenu(ACHIEVEMENT_MENU);
				break;
		
		case 5:	setMenu(ABOUT_MENU);
				break;
		
		case 6: System.exit(0);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "New Game";
		options[1] = "Continue Game";
		options[2] = "Options";
		options[3] = "Stats";
		options[4] = "Achievements";
		options[5] = "About";
		options[6] = "Exit";
	}
}
package com.Lpb.Menu;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Inventory.Item;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class BuyMenu extends Menu {

	Sprite smg = Sprites.items[0][0];
	Sprite jawk = Sprites.items[1][0];
	Sprite knife = Sprites.items[2][0];
	Sprite sg019 = Sprites.items[6][0];
	Sprite healthpack = Sprites.items[0][30];
	
	public BuyMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];		
	}

	public void render(int x, int y, Screen screen) {
		super.render(x, y, screen);
		
		screen.renderSprite(x + 153, y + 64, knife);
		Font.drawString("�"+Item.knife.value, x + 153 + 140, y + 67, -16777216, screen);
		screen.renderSprite(x + 153, y + 64 + 35, jawk);
		Font.drawString("�"+Item.jawk.value, x + 153 + 140, y + 67 + 35, -16777216, screen);
		screen.renderSprite(x + 153, y + 64 + 70, smg);
		Font.drawString("�"+Item.Smg.value, x + 153 + 140, y + 67 + 70, -16777216, screen);
		screen.renderSprite(x + 153, y + 64 + 105, sg019);
		Font.drawString("�"+Item.SG019.value, x + 153 + 140, y + 67 + 105, -16777216, screen);
		screen.renderSprite(x + 153, y + 64 + 140, healthpack);
		Font.drawString("�"+Item.healthpack.value, x + 153 + 140, y + 67 + 140, -16777216, screen);
		
		Font.drawString(TITLE, x + 153 + 45, y + 5, -1, Font.MENU_FONT, screen);
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: Inventory.buyItem(Item.knife);
				break;
						
		case 1: Inventory.buyItem(Item.jawk);
				break;
						
		case 2: Inventory.buyItem(Item.Smg);
				break;
				
		case 3: Inventory.buyItem(Item.SG019);
				break;
				
		case 4: Inventory.buyItem(Item.healthpack);
				break;
				
		case 5: setMenu(SHOP_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Knife";
		options[1] = "Jawk";
		options[2] = "SMG";
		options[3] = "SG019";
		options[4] = "Healthpack";
		options[5] = "Return";
	}
}
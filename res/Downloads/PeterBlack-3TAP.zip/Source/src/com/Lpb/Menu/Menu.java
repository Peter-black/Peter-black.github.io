package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;

public class Menu {	
	public final int id;
	public boolean state;
	public int selectedItem;
	public final int maxItems;
	public final String TITLE;
	
	public static Menu currMenu;
	public static Menu parentMenu;

	public static String[] options = new String[10];
	
	public static int scroll = 0;
	public static boolean scrollLockUp, scrollLockDown;
	
	private static boolean initLoad = true;
	private static boolean animate = false, animDir;
	private static int animX;
	private static boolean menuDue = false;
	private static Menu setMenu;
	
	Sprite background;
	
	public static Menu[] menus = new Menu[15];
	
	public final static Menu
	NO_MENU = new Menu(0,false,0,0,""),
	TITLE_MENU = new TitleMenu(1 , false, 0, 7, "3TAP"),
	OPTIONS_MENU = new OptionsMenu(2 , false, 0, 5, "OPTIONS"),
	CHEATS_MENU = new CheatsMenu(3 , false, 0, 5, "CHEATS"),
	STATS_MENU = new StatsMenu(4 , false, 0, 1, "STATS"),
	ABOUT_MENU = new AboutMenu(5 , false, 0, 1, "ABOUT"),
	PAUSE_MENU = new PauseMenu(6 , false, 0, 7, "PAUSED"),
	SHOP_MENU = new ShopMenu(7 , false, 0, 4, "SHOP"),
	BUY_MENU = new BuyMenu(8 , false, 0, 6, "BUY"),
	SELL_MENU = new SellMenu(9 , false, 0, 2, "SELL"),
	UPGRADE_MENU = new UpgradeMenu(10 , false, 0, 2, "UPGRADE"),
	ACHIEVEMENT_MENU = new AchievementMenu(11, false, 1, 2, "ACHIEVEMENTS"),
	QUEST_LOG = new QuestLog(12, false, 1, 2, "QUEST LOG"),
	SPLASH_SCREEN = new SplashScreen(13 , false, 0, 0, ""),
	DEAD_MENU = new DeadMenu(14, false, 0, 2, "");

	public Menu(int id, boolean state, int selectedItem, int maxItems, String title){
		this.id = id;
		this.state = state;
		this.selectedItem = selectedItem;
		this.maxItems = maxItems;	
		this.TITLE = title;
		
		menus[id] = this;
	}
	
	public void tick(){
		if(selectedItem > maxItems-1)selectedItem = 0;
		if(selectedItem < 0) selectedItem = maxItems-1;
		
		if(animate)animate(animDir);
		
		if(!animate && menuDue){
			changeMenu(setMenu);
			if(setMenu == NO_MENU){
				setMenu = null;
				menuDue = false;
				return;
			}
			setMenu = null;
			menuDue = false;
			animate = true;
			animDir = true;
		}
	}
	
	private void animate(boolean dir){
		if(dir){
			animX -= 15;
			if(animX <= 0){
				animate = false;
			}
		}
		if(!dir){
			animX += 15;
			if(animX >= 110){
				animate = false;
			}
		}
	}
	
	public void render(int x, int y, Screen screen) {			
		screen.renderSprite(x, y, background);
		
		Font.drawString(TITLE, Game.WIDTH - (TITLE.length()*12) - 12, 10, -16738125, Font.MENU_FONT, screen);
		
		for(int i = 0; i < maxItems; i++){
			if(selectedItem == i)Font.drawString(options[i] , x + 105 - options[i].length()*6 - animX, y + Game.HEIGHT - (maxItems*15) + i * 15, -8073241, screen);
			else Font.drawString(options[i] , x + 110 - options[i].length()*6 - animX, y + Game.HEIGHT - (maxItems*15) + i * 15, -16738125, screen);
		}	
	}
	
	public void chooseOption(int option){
	}
	
	protected void setOptions(){
	}
	
	public static void setMenu(Menu menu){
		if(initLoad){ changeMenu(menu); initLoad = false;}
		
		if(menu == PAUSE_MENU || menu == SHOP_MENU || menu == QUEST_LOG || menu == DEAD_MENU)changeMenu(menu);
		
		animate = true;
		animDir = false;
		menuDue = true;
		setMenu = menu;
	}
	
	protected static void changeMenu(Menu menu){	
		if(menu == TITLE_MENU || menu == PAUSE_MENU || menu == SHOP_MENU){
			parentMenu = menu;
		}
		currMenu = menu;
		
		closeAll(); 
		
		scroll = 0;
		
		if(menu == NO_MENU)return;
		
		for(int i = 0; i < menus.length; i++){
			if(menus[i] == menu){
				menus[i].state = true;
				menus[i].setOptions();
			}
		}
	}
	
	public static Menu getMenu(){
		return currMenu;
	}
	
	public static void closeAll(){
		for(int i = 0; i < menus.length; i++){
			menus[i].state = false;
		}
	}
}
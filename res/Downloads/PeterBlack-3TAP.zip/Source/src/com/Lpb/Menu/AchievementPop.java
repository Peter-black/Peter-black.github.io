package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Graphics.Font;

public class AchievementPop {

	private static int x,y,w,h;
	
	private static boolean active = false;
	private long currTime = 0;
	private long finTime;
	private static String message;
	
	public AchievementPop(){
	}
	
	public void tick(){
		if(active){
			currTime = System.currentTimeMillis();
			if(y < 0)y += 15 * 0.1;
			if(y >= 0 && finTime - currTime <= 0)stop();
		}
	}
	
	public void render(){
		if(active){
			Game.screen.renderRect(x, y, w, h, -13421773);
			Font.drawString(""+message, x+6, y+(h/2)-5, -16738125, Game.screen);
		}
	}
	
	public void pop(String Message, int duration){
		message = Message;
		w = (Message.length()*6)+12;
		h = 30;
		x = (Game.WIDTH-(Message.length()*6))-12;
		y = -30;
		
		currTime = System.currentTimeMillis();
		finTime = System.currentTimeMillis() + duration;
		active = true;
	}

	public void stop(){
		active = false;
	}
	
	public boolean isRunning(){
		return active;
	}
}

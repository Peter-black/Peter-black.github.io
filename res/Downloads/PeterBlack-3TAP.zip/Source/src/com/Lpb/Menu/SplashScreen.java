package com.Lpb.Menu;

import com.Lpb.Timer;
import com.Lpb.Sprites.Sprites;

public class SplashScreen extends Menu {
	Timer timer = new Timer();
	
	public SplashScreen(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title);

		background = Sprites.splash[0][0];
		timer.start(1300);
	}
	
	public void tick(){
		if(timer.checkTime()){
			changeMenu(TITLE_MENU);
		}
	}
}
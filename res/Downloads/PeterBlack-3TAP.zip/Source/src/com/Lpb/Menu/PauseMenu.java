package com.Lpb.Menu;

import java.io.IOException;

import com.Lpb.Game;
import com.Lpb.Write;
import com.Lpb.Sprites.Sprites;

public class PauseMenu extends Menu {

	public PauseMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: Game.setPaused(false);
				setMenu(NO_MENU);
				break;
				
		case 1: try {Write.save();} 
				catch (Exception e2) {
				e2.printStackTrace();}
		
				try {Write.saveStats();} 
				catch (Exception e2) {
				e2.printStackTrace();}
		
				Game.setPaused(false);
				setMenu(NO_MENU);
				break;		
		
		case 2: try {Write.load();} 
				catch (IOException e){
				try {Write.save();} catch (Exception e1) {e1.printStackTrace();}
				System.out.println("No save game found, creating new one...");
				e.printStackTrace();}
				catch (Exception e){
				e.printStackTrace();}
		
				Game.setPaused(false);
				setMenu(NO_MENU);
				break;
				
		case 3: setMenu(OPTIONS_MENU);
				break;
				
		case 4: setMenu(STATS_MENU);
				break;
				
		case 5: setMenu(ACHIEVEMENT_MENU);
				break;
				
		case 6: try {Write.save();} 
				catch (Exception e) {
				e.printStackTrace();
				}
		
				try {Write.saveStats();} 
				catch (Exception e2) {
				e2.printStackTrace();}
				
				setMenu(TITLE_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Continue";
		options[1] = "Save";
		options[2] = "Restart Checkpoint";
		options[3] = "Options";
		options[4] = "Stats";
		options[5] = "Achievements";
		options[6] = "Exit to menu";
	}
}
package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Sprites.Sprites;

public class ShopMenu extends Menu {

	public ShopMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: setMenu(BUY_MENU);
				break;
				
		case 1: Menu.setMenu(SELL_MENU);
				break;
				
		case 2: setMenu(UPGRADE_MENU);
				break;
				
		case 3: Game.setPaused(false);
				setMenu(NO_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Buy";
		options[1] = "Sell";
		options[2] = "Upgrade";
		options[3] = "Close";
	}
}
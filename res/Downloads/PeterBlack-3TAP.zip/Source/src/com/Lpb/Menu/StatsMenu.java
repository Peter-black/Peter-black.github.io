package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Events.Rank;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class StatsMenu extends Menu {
	
	String[] stats = new String[5];

	public StatsMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 
		
		background = Sprites.menuBg[0][0];
	}
	
	public void tick(){
		super.tick();
		selectedItem = 0;
	}

	public void render(int x, int y, Screen screen) {
		super.render(x, y, screen);

		for(int i = 0; i < stats.length; i++){
			Font.drawString(stats[i] , x + 153 + 87 - stats[i].length()*3, y + 60 + 7 + i * 35, -1,screen);
		}
	}
	
	public void chooseOption(int option){
		switch(option){		
		case 0: setMenu(parentMenu);
				break;	
		}
	}
	
	protected void setOptions(){
		stats[0] = "Kills: " + Game.totalKills;
		stats[1] = "Deaths: " + Game.totalDeaths;
		stats[2] = "Money Gained: " + Game.totalMoneyGained;
		stats[3] = "Money Lost: " + Game.totalMoneySpent;
		stats[4] = "Rank: " + Rank.rank;
		
		options[0] = "Return";
	}
}
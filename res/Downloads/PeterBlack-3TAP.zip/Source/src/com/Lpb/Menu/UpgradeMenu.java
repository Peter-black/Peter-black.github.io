package com.Lpb.Menu;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.Inventory;
import com.Lpb.Sprites.Sprites;

public class UpgradeMenu extends Menu {

	public UpgradeMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}

	public void render(int x, int y, Screen screen) {
		super.render(x, y, screen);
		
		try{
		if(Inventory.inventory[Inventory.selectedItem] != null){
			if(Inventory.inventory[Inventory.selectedItem].upgrade >= Inventory.inventory[Inventory.selectedItem].maxupgrade){
				if(selectedItem == 0);
			}
		}
		}catch(Exception e){}
		
		try{
			if(Inventory.inventory[Inventory.selectedItem] != null){
				if(Inventory.inventory[Inventory.selectedItem].upgrade >= Inventory.inventory[Inventory.selectedItem].maxupgrade){
					Font.drawString("MAX", x + 153 + 150, y + 60 + 7, -16777216, screen);
				}else{
					Font.drawString("�"+Inventory.inventory[Inventory.selectedItem].price, x + 153 + 150, y + 60 + 7, -16777216, screen);
				}
			}
		}catch(Exception e){};
		
		Font.drawString(TITLE, x + 138, y + 5, -1, Font.MENU_FONT, screen);
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: Inventory.upgradeItem(Inventory.inventory[Inventory.selectedItem]);
				break;
				
		case 1: setMenu(SHOP_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Upgrade Selected Item";
		options[1] = "Close";
	}
}
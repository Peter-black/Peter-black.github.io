package com.Lpb;

public class Timer {

	long currTime, endTime;
	
	public Timer(){
	}
	
	public void start(int duration){
		endTime = System.currentTimeMillis() + duration;
	}
	
	public void start(long duration){
		endTime = System.currentTimeMillis() + duration;
	}
	
	public boolean checkTime(){
		currTime = System.currentTimeMillis();
		if(currTime >= endTime)return true;
		else return false;
	}
}

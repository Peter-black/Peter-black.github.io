package com.Lpb.Events;

import java.util.ArrayList;

import com.Lpb.Game;
import com.Lpb.Menu.AchievementPop;
import com.Lpb.Menu.SpeechBox;
import com.Lpb.Menu.SpeechBoxBoolean;

public class EventHandler {
	
	public static AchievementPop achievement = new AchievementPop();
	public static SpeechBox speechBox = new SpeechBox();
	public static SpeechBoxBoolean speechBoxBoolean = new SpeechBoxBoolean();
	public static Event[] achievements = new Event[]{Event.SLAYER, Event.TEST, Event.TESTTWO};
	public static Event[] quests = new Event[]{Event.TUTORIAL, Event.QUEST};

	public EventHandler() {
		
	}
	
	public static void tick() {
		
		//**ACHIEVEMENTS**\\
		
		//SLAYER
		if(Event.SLAYER.isStarted()){
			if(Event.SLAYER.getCheckpoint() == 0){
				if(Game.totalKills >= 10){Event.SLAYER.checkpoint(1);achievement.pop("YOU COMPLETED SLAYER "+ Event.SLAYER.getCheckpoint(), 3000);}
			}
			if(Event.SLAYER.getCheckpoint() == 1){
				if(Game.totalKills >= 20){Event.SLAYER.checkpoint(1);achievement.pop("YOU COMPLETED SLAYER "+ Event.SLAYER.getCheckpoint(), 3000);}
			}
			if(Event.SLAYER.getCheckpoint() == 2){
				if(Game.totalKills >= 50){Event.SLAYER.checkpoint(1);achievement.pop("YOU COMPLETED SLAYER "+ Event.SLAYER.getCheckpoint(), 3000);}
			}
			if(Event.SLAYER.getCheckpoint() == 3){
				if(Game.totalKills >= 100){Event.SLAYER.checkpoint(1);achievement.pop("YOU COMPLETED SLAYER "+ Event.SLAYER.getCheckpoint(), 3000);}
			}
			if(Event.SLAYER.getCheckpoint() == 4){
				if(Game.totalKills >= 200){Event.SLAYER.checkpoint(1);achievement.pop("YOU COMPLETED SLAYER "+ Event.SLAYER.getCheckpoint(), 3000);}
			}
		}
		
		if(achievement.isRunning()) achievement.tick(); 
		
		//**STORYLINE**\\
		
		//TUTORIAL
		if(Event.TUTORIAL.isStarted()){
			if(Game.player.pX >= 300)Event.TUTORIAL.complete();
		}
		
		
		//QUEST
		if(Event.QUEST.isStarted()){
			if(Event.QUEST.getCheckpoint() == 0){
				if(Game.player.pX >= 300){Event.QUEST.checkpoint(1);achievement.pop("QUEST PART "+Event.QUEST.getCheckpoint()+" Completed", 3000);}
			}
			if(Event.QUEST.getCheckpoint() == 1){
				if(Game.player.pX >= 600){Event.QUEST.checkpoint(1);achievement.pop("QUEST PART "+Event.QUEST.getCheckpoint()+" Completed", 3000);}
			}
			if(Event.QUEST.getCheckpoint() == 2){
				if(Game.player.pX >= 1200){Event.QUEST.checkpoint(1);achievement.pop("QUEST PART "+Event.QUEST.getCheckpoint()+" Completed", 3000);}
			}
			if(Event.QUEST.getCheckpoint() >= 3){
				if(Game.player.pX >= 2000){Event.QUEST.checkpoint(1);achievement.pop("QUEST Completed", 3000);}
			}
		}
	}
	
	public static Event[] getActiveAchievements(){
		ArrayList<Event> achieveStore = new ArrayList<Event>();
		for(int i = 0; i < achievements.length; i++){
			if(achievements[i].isStarted()){
				achieveStore.add(achievements[i]);
			}
		}
		
		Event[] activeAchievements = new Event[achieveStore.size()];
		for(int i = 0; i < achieveStore.size(); i++){
			activeAchievements[i] = achieveStore.get(i);
		}
		return activeAchievements;
	}
	
	public static Event[] getActiveQuests(){
		ArrayList<Event> questStore = new ArrayList<Event>();
		for(int i = 0; i < quests.length; i++){
			if(quests[i].isStarted()){
				questStore.add(quests[i]);
			}
		}
		
		Event[] activeQuests = new Event[questStore.size()];
		for(int i = 0; i < questStore.size(); i++){
			activeQuests[i] = questStore.get(i);
		}
		return activeQuests;
	}
	
	public static Event[] getCompletedAchievements(){
		ArrayList<Event> achieveStore = new ArrayList<Event>();
		for(int i = 0; i < achievements.length; i++){
			if(achievements[i].isComplete()){
				achieveStore.add(achievements[i]);
			}
		}
		
		Event[] completedAchievements = new Event[achieveStore.size()];
		for(int i = 0; i < achieveStore.size(); i++){
			completedAchievements[i] = achieveStore.get(i);
		}
		return completedAchievements;
	}
	
	public static Event[] getCompletedQuests(){
		ArrayList<Event> questStore = new ArrayList<Event>();
		for(int i = 0; i < quests.length; i++){
			if(quests[i].isComplete()){
				questStore.add(quests[i]);
			}
		}
		
		Event[] completedQuests = new Event[questStore.size()];
		for(int i = 0; i < questStore.size(); i++){
			completedQuests[i] = questStore.get(i);
		}
		return completedQuests;
	}
	
	public static void render(){
		if(achievement.isRunning())achievement.render();
		speechBox.render();
		speechBoxBoolean.render();
	}
}

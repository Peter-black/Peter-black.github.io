package com.Lpb.Events;

import com.Lpb.Game;
import com.Lpb.Graphics.TextParticle;

public class Rank {

	public static int rank = 1;
	public static final int MAXRANK = 100;
	
	public static int exp = 0;
	
	public Rank(){
	}
	
	public static void tick(){
		if(rank == MAXRANK){rank = MAXRANK; exp = getLevelUpExp(MAXRANK);}
		if(exp > getLevelUpExp(rank)){
			Game.particles.add(new TextParticle("RANK UP!", Game.player.pX+(Game.player.pW/2), Game.player.pY+(Game.player.pH/2)+5, -256));
			rank++;
		}
	}
	
	public static void addExp(int amount){
		Game.particles.add(new TextParticle("+"+amount+"xp", Game.player.pX+(Game.player.pW/2), Game.player.pY+(Game.player.pH/2)+5, -16711936));
		exp += amount;
	}
	
	public static void removeExp(int amount){
		exp -= amount;
	}
	
	public static int getLevelUpExp(int rank){	
		return (int) Math.pow((rank + 2) * 3, 2);
	}
	
	public static int getRemainingExp(){
		return (int) getLevelUpExp(rank) - exp;
	}
	
	public static double getPercentageComplete(){
		if(rank == 1){
			int size = getLevelUpExp(rank);
			int xp = exp;
		
			return (double)xp/(double)size * 100;
		}else{
			int size = getLevelUpExp(rank) - getLevelUpExp(rank-1);
			int xp = exp - getLevelUpExp(rank-1);
			
			return (double)xp/(double)size * 100;
		}
	}
}

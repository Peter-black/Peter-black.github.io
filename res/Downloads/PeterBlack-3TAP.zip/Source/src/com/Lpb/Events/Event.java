package com.Lpb.Events;

public enum Event {
	//Achievements
	SLAYER(true,5,false),
	TEST(true, 6, false),
	TESTTWO(false, 100, true),
	//Storyline
	TUTORIAL(false,1,false),
	QUEST(false,4,false);

	private boolean started;
	private int checkpoint = 0;
	private int maxCheckpoint;
	private boolean complete;

	Event(boolean started, int maxCheckpoint, boolean complete) {
		this.started = started;
		this.maxCheckpoint = maxCheckpoint;
		this.complete = complete;
	}

	public void start() {
		if(!complete)started = true;
	}
	
	public void checkpoint(int amount){
		if(!complete){
		if((checkpoint + amount) >= maxCheckpoint)complete();
		else checkpoint += amount;
		}
	}
		
	public void complete() {
		started = false;
		checkpoint = maxCheckpoint;
		complete = true;
	}
	
	public boolean isStarted(){
		return started;
	}
	
	public int getCheckpoint(){
		return checkpoint;
	}
	
	public int getMaxCheckpoint(){
		return maxCheckpoint;
	}
	
	public boolean isComplete(){
		return complete;
	}
}

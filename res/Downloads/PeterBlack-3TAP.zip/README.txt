This was the first game I ever made, and I used it to learn programming through the help
of youtube tutorials and the internet. It has a lot of working and a lot of broken features
and is kind of a mash of many different programming challenges.

Interesting features:

>Tilemaps
>Basic AI Mobs
>Inventory System
>Level System
>Particle System
>Shop
>Shooting (w/ many guns + melee)
>Level loading (and editor)
>Quest System
>Item dropping and Retrieval
>Full Menu & Options System
>Saving and loading.
>Minimap (UI)


Controls:

WASD: 	Walk around
Q:	Drop Weapon
E:	Pickup underneath you
E:	Use/Talk to people
Scroll:	Swap Weapon
1-3:	Swap Weapon
Mouse: 	Aim
Click: 	Fire weapon
ESC:	Menu
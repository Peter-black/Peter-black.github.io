The Original game concept and assets are from Super Crate Box (supercratebox.com) by Vlambeer (vlambeer.com)

A GameBoy Advance emulator is required to run this game

I recommend Visual Boy Advance which can be found at http://www.emulator-zone.com/doc.php/gba/vboyadvance.HTML

The default controls on the emulator map the DPAD to the Arrow Keys, A Button to Z and B Button to X.



~Peter Black 2014
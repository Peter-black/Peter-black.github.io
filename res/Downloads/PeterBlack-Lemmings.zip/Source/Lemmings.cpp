#include <stdint.h>
#include "gba.h"
#include "font.h"
#include "sprite.h"

//Computer and Graphics Architectures
//Peter Black
//1300507

//Defines
//Menus
#define TITLE_MENU 		0
#define GAMEOVER_MENU 	1
//Lemming attributes
#define X       	0
#define Y       	1
#define DIR     	2
#define JOB     	3  
#define FALL		4
#define DEAD		5  
//Lemming Jobs
#define WALKER 		0
#define BLOCKER		1

//Function Prototypes
//**MENU**
void enterMenu(int type);																//Puts the game into a specific menu
//**LOGIC**
void resetGame();																		//Returns game variables to default values
//**LOGICAL DRAWING**
void MakeBox(int x, int y, int w);														//Draws a fancy rectangle and adds it to collision array.
//**DRAWING**
void DrawString(int x, int y, char str[], unsigned int strlen, bool bold, int col);		//Draws a string of sprites from the font.cpp arrays
void DrawScaleString(int x, int y, char str[], unsigned int strlen, int scale, int col);//Draws a string with a scaled size.
void DrawRect(int x, int y, int w, int h, int col);										
void DrawSpawn(int x, int y);															
void DrawFinish(int x, int y);															
void DrawLemming(int x, int y, int dir, int job, int fallstate, int dead, int frame);	
void DrawCursor(int x, int y, bool selected);											

//Variables
bool keyPressed = false;

int spawnNumber = 0;									//Chooses which lemming to spawn
int spawnCounter = 20;									//Allows the lemmings to fall in with intervals
int lemmings[20][6]; 
int lemmingsBlockered = 0;								//Number of lemmings made into blockers
int lemmingsDied = 0;
int lemmingsSaved = 0;

int frame = 0; 	
	
int boxnum = 0;											//Semi-temp variable for storing box values
int boxes[5][3];										//Box co-ords for collision

bool cursorHover = false;								
int cursorX = 50, cursorY = 35;							


//Colour Palette indexes
//Core
int black = 0; 			
int white = 1;			
//Lemming
int green = 2;			
int skin  = 3;			
int blue = 4;			
//Platform
int red = 5;			
int darkRed = 6;		
int lightRed = 7;		
//Cursor
int yellow = 8;			
//Spawn
int brown = 9;			
int lightBrown = 10;	
int grey = 11;			
int darkGreen = 12;		
int skyBlue = 13;		
//Finish
int deepRed = 14;		
int orange = 15;		
int darkerRed = 16;		
int darkBlueGrey = 17;	
int darkGrey = 18;		
int darkBlue = 19;		
int darkerGreen = 20;	

int main()
{
    // Put the display into bitmap mode 3, and enable background 2.
	REG_DISPCNT = MODE4 | BG2_ENABLE;

	//Palette set-up
	SetPaletteBG(black, RGB(0,0,0));		
	SetPaletteBG(white, RGB(31,31,31));		
	SetPaletteBG(green, RGB(0,25,0));		
	SetPaletteBG(skin, RGB(29,26,26));	
	SetPaletteBG(blue, RGB(12,12,31));	
	SetPaletteBG(red, RGB(30,5,2));	
	SetPaletteBG(darkRed, RGB(22,3,1));	
	SetPaletteBG(lightRed, RGB(31,14,12));	
	SetPaletteBG(yellow, RGB(31,31,0)); 	
	SetPaletteBG(brown, RGB(18,9,0));	
	SetPaletteBG(lightBrown, RGB(22,11,0));	
	SetPaletteBG(grey, RGB(22,22,22));
	SetPaletteBG(darkGreen, RGB(5,20,5));	
	SetPaletteBG(skyBlue, RGB(10,20,31));	
	SetPaletteBG(deepRed, RGB(25,7,4));	
	SetPaletteBG(orange, RGB(27,16,4));	
	SetPaletteBG(darkerRed, RGB(12,0,2));	
	SetPaletteBG(darkBlueGrey, RGB(8,8,10));	
	SetPaletteBG(darkGrey, RGB(14,14,16));
	SetPaletteBG(darkBlue, RGB(8,8,27));	
	SetPaletteBG(darkerGreen, RGB(0,12,0));	
	
	enterMenu(TITLE_MENU);
	
	resetGame();

	//Game Loop
	while (true)
	{
		//INPUT
		//Cursor Movement
		if((REG_KEYINPUT & KEY_LEFT) == 0)cursorX-=4;
		if((REG_KEYINPUT & KEY_RIGHT) == 0)cursorX+=4;
		if((REG_KEYINPUT & KEY_UP) == 0)cursorY-=4;
		if((REG_KEYINPUT & KEY_DOWN) == 0)cursorY+=4;
		//Makes a lemming a blocker if selected
		if((REG_KEYINPUT & KEY_A) == 0){
			if(cursorHover){
				for(int i = 0; i < 20; i++){
					if(cursorX >= lemmings[i][X] && cursorX <= lemmings[i][X] + 10){
					if(cursorY >= lemmings[i][Y] && cursorY <= lemmings[i][Y] + 10){
						lemmings[i][JOB] = BLOCKER;
						lemmingsBlockered++;
						break;
					}
					}
				}
			}
		}

		//LOGIC
		//Spawns in lemmings with an interval
		if(spawnCounter == 20 && spawnNumber != 20){
			lemmings[spawnNumber][DEAD] = false;
			spawnNumber++;
			spawnCounter = 0;
		}spawnCounter++;
		
		//Mass loop to save repeating code
		for(int i = 0; i < 20; i++){
			if(!lemmings[i][DEAD]){
				
				//If lemming is a blocker check for collision with other lemmings
				//if colliding, reverse other lemmings direction.
				if(lemmings[i][JOB] == BLOCKER){
					for(int j = 0; j < 20; j++){
						if(i!=j){//if it is not itself
							if(lemmings[j][Y] != lemmings[i][Y])continue;//If not on the same platform level ignore
							
							if(lemmings[j][X] >= lemmings[i][X] && lemmings[j][X] <= lemmings[i][X]+10 ||
							lemmings[j][X]+10 >= lemmings[i][X] && lemmings[j][X]+10 <= lemmings[i][X]+10){
								if(lemmings[j][DIR])lemmings[j][DIR] = 0;
								else lemmings[j][DIR] = 1;
							}
						}
					}
				}
				
				//Check for collision with boxes
				for(int j = 0; j < 5; j++){
					if(lemmings[i][X] + 10 >= boxes[j][0] && lemmings[i][X] <= boxes[j][0]+boxes[j][2]){
					if(lemmings[i][Y] + 10 >= boxes[j][1] && lemmings[i][Y] <= boxes [j][1]){
						lemmings[i][FALL] = false;
						lemmings[i][Y] = boxes[j][1]-10;
						break;
					}
					}else{
						lemmings[i][FALL] = true;
					}
				}
				
				//Move lemmings
				if(lemmings[i][FALL])lemmings[i][Y]++;
				else if(lemmings[i][JOB] == BLOCKER);
				else if(lemmings[i][DIR] == 0)lemmings[i][X]++;
				else if(lemmings[i][DIR] == 1)lemmings[i][X]--;
				
				//Kill lemming if he falls of the bottom of the screen
				if(lemmings[i][Y] > SCREEN_HEIGHT){lemmings[i][DEAD] = true;lemmingsDied++;}
				//Save lemmings when they reach the finish
				if(lemmings[i][X] == 160 && lemmings[i][Y] > 100){lemmings[i][DEAD] = true;lemmingsSaved++;}
			}

		}
		
		//Keep cursor inside the screen
		if(cursorX >= SCREEN_WIDTH)cursorX = SCREEN_WIDTH;
		if(cursorX <= 0)cursorX = 0;
		if(cursorY >= SCREEN_HEIGHT)cursorY = SCREEN_HEIGHT;
		if(cursorY <= 0)cursorY = 0;
		
		//Checks if the cursor is hovered over a lemming
		for(int i = 0; i < 20; i++){//Separate for loop due to the break statement
			cursorHover = false;
			if(cursorX >= lemmings[i][X] && cursorX <= lemmings[i][X] + 10){
			if(cursorY >= lemmings[i][Y] && cursorY <= lemmings[i][Y] + 10){
				if(lemmings[i][JOB] != BLOCKER && !lemmings[i][DEAD])cursorHover = true;
				break;
			}
			}
		}
		
		//Checks if game has ended by counting total dead and blockers
		int counter = 0;
		if(spawnNumber == 20){
			for(int i = 0; i < 20; i++){
				if(lemmings[i][DEAD] || lemmings[i][JOB] == BLOCKER)counter++;
			}
			if(counter == 20)enterMenu(GAMEOVER_MENU);
		}
		
		//ANIMATION

		//sets the current frame for sprites to show
		frame++;
		if(frame > 7)frame=0;
		
		//RENDER
		FlipBuffers();
		ClearScreen8(0);

		MakeBox(20, 40, 120);
		MakeBox(50, 80, 30);
		MakeBox(120, 80, 80);
		MakeBox(70, 115, 60);
		MakeBox(40, 150, 150);
	
		DrawSpawn(11, 10);
		DrawFinish(150, 126);
	
		DrawString(SCREEN_WIDTH/2 - 32,10,"LEMMINGS",8,true,green);
		
		for(int i = 0; i < 20; i++){
			DrawLemming(lemmings[i][X],lemmings[i][Y],lemmings[i][DIR],lemmings[i][JOB],lemmings[i][FALL],lemmings[i][DEAD], frame);
		}
		
		DrawCursor(cursorX, cursorY, cursorHover);
		
		//SYNC
		WaitVSync();
	}

	return 0;
}


//****FUNCTIONS****

//**MENUS**
void enterMenu(int type){

	bool inMenu = true;	
	uint16_t oldReg = REG_KEYINPUT;
	int timer = 0;
	
	while(inMenu){
		//Press any button to continue!
		if(REG_KEYINPUT != oldReg ){
			if(type == TITLE_MENU)inMenu = false;
			if(type == GAMEOVER_MENU){resetGame();inMenu = false;}
		}
		oldReg = REG_KEYINPUT;

		FlipBuffers();
		ClearScreen8(0);
		
		if(type == TITLE_MENU){
			DrawScaleString(20,20,"LEMMINGS",8,3,green);
			DrawString(42,49,"Made by Peter Black",19,false,green);
			
			if(timer > 40)DrawString(17,75,"Press any button to play!",25,true,white);
			else DrawString(17,75,"Press any button to play!",25,true,darkGrey);
			
			DrawString(10,100,"Use the arrow keys to move",26,false,white);
			
			DrawString(35,120,"Press  to set a job",19,false,white);
			DrawRect(79, 120, 10, 9, grey);
			DrawString(80,121,"Z",1,true,black);
		}
		if(type == GAMEOVER_MENU){
		
			char digit1;
			char digit2;
			DrawScaleString(10,20,"GAME OVER",9,3,red);
	
			DrawString(15, 110, "Saved:",6,false,green);
			digit1 = '0' + lemmingsSaved/10 %10;
			digit2 = '0' + lemmingsSaved%10;
			DrawString(100, 110, &digit1,6,false,white);
			DrawString(108, 110, &digit2,6,false,white);
			
			DrawString(15, 125, "Died:",5,false,green);
			digit1 = '0' + lemmingsDied/10 %10;
			digit2 = '0' + lemmingsDied%10;
			DrawString(100, 125, &digit1,6,false,white);
			DrawString(108, 125, &digit2,6,false,white);
			
			DrawString(15, 140, "Blockers:",9,false,green);
			digit1 = '0' + lemmingsBlockered/10 %10;
			digit2 = '0' + lemmingsBlockered%10;
			DrawString(100, 140, &digit1,6,false,white);
			DrawString(108, 140, &digit2,6,false,white);
			
			if(timer > 40)DrawString(17,75,"Press any button to retry!",26,true,white);
			else DrawString(17,75,"Press any button to retry!",26,true,darkGrey);
		}
		//Used for animation
		timer++;
		if(timer > 80)timer = 0;
	}
}

//**LOGIC**

void resetGame(){
	keyPressed = false;
	spawnNumber = 0;			
	spawnCounter = 20;										
	cursorX = 50, cursorY = 35;	
	
	lemmingsBlockered = 0;
	lemmingsDied = 0;
	lemmingsSaved = 0;
	
	for(int i = 0; i < 20; i++){
		lemmings[i][X] = 20;
		lemmings[i][Y] = 10;
		lemmings[i][DIR] = 0;
		lemmings[i][JOB] = WALKER;
		lemmings[i][FALL] = false;
		lemmings[i][DEAD] = true;
	}
}

//**LOGICAL DRAWING**
void MakeBox(int x, int y, int w){
	//set up collision array
	boxes[boxnum][0] = x;
	boxes[boxnum][1] = y;
	boxes[boxnum][2] = w;
	boxnum++;
	if(boxnum == 5) boxnum = 0;

	int h = 10; //consistent height for all boxes
	
	//Makes the box look like a girder
	DrawRect(x, y, w, h, red);
	DrawRect(x, y, w, 1, lightRed);
	DrawRect(x, y+2, w, 1, darkRed);
	DrawRect(x, y+h-2, w, 1, lightRed);
	DrawRect(x, y+h, w, 1, darkRed);
	for(int i = x; i < x+w; i++){
		if(i%6 == 0){
			DrawRect(i, y+4, 2, 2, darkRed);
			DrawRect(i, y+4, 1, 1, lightRed);
		}
	}
}
		
//**DRAWING**
void DrawString(int x, int y, char str[], unsigned int strlen, bool bold, int col){
	if(bold){
		for(unsigned int i = 0; i < strlen; i++){
			for(int j = 0; j < 64; j++){
				if(font_bold[str[i]][j] == 1)PlotPixel8(x+(j%8)+(8*i), y+(j/8), col);
			}
		}
	}else{
		for(unsigned int i = 0; i < strlen; i++){
			for(int j = 0; j < 64; j++){
				if(font_medium[str[i]][j] == 1)PlotPixel8(x+(j%8)+(8*i), y+(j/8), col);
			}
		}
	}
}
void DrawScaleString(int x, int y, char str[], unsigned int strlen, int scale, int col){
	for(unsigned int i = 0; i < strlen; i++){
		for(int j = 0; j < 64; j++){
			if(font_bold[str[i]][j] == 1){
				for(int s = 0; s < scale; s++){
				for(int c = 0; c < scale; c++){
					PlotPixel8(x+(j%8)*scale+(8*i*scale)+s, y+(j/8)*scale+c, col);
				}
				}
			}
		}
	}
}

void DrawRect(int x, int y, int w, int h, int col){
	for(int i = x; i < x+w; i++){
	for(int j = y; j < y+h; j++){
		PlotPixel8(i, j, col);
	}
	}
}

void DrawSpawn(int x, int y){
	int w = 30, h = 7;

	DrawRect(x-2, y-3, w+4, 2, brown);		//Door Top
	DrawRect(x-2, y-1, w+4, 1, lightBrown);	//Door Top Highlight
	DrawRect(x,y,w,h,skyBlue);				//Sky
	DrawRect(x,y+h,w,1,grey);				//Door Bottom
	for(int i = 0; i < 7; i++){
		int col = brown;
		if(i%2==0)col = lightBrown;
		DrawRect(x-1+i, y+i, 1, 14-i, col);	//Left panel
		DrawRect(x+w-i, y+i, 1, 14-i, col);	//Right panel
		
		PlotPixel8(x+i,y+i,grey);			//Metal panel bit left
		PlotPixel8(x+w-7+i,y+h-i-1,grey);	//Metal panel bit right
	}
	//TREES
	//Array maps the pixels for the trees
	int trees[112] = {	12,12,00,12,00,00,00,00,00,00,00,00,00,00,00,00,
						00,12,12,12,00,12,00,00,00,00,00,00,00,00,00,00,
						00,00,12,10,12,12,00,00,12,00,00,00,00,00,00,00,
						00,00,00,10,12,10,00,12,12,00,00,12,00,00,00,00,
						00,00,00,00,10,10,12,12,12,12,00,12,00,00,00,00,
						00,00,00,00,00,10,12,10,12,12,12,12,12,00,00,00,
						00,00,00,00,00,00,10,10,10,12,10,12,12,12,00,12};
						
	for(int i = 0; i < 112; i++){
		if(trees[i] != 0)PlotPixel8(x+(i%16)+1, y+(i/16), trees[i]);
	}
}

void DrawFinish(int x, int y){
	for(int j = 0; j < 825; j++){
		if(exit_portal[j] != 0)PlotPixel8(x+(j%33), y+(j/33), exit_portal[j]);
	}
}

void DrawLemming(int x, int y, int dir, int job, int fallstate, int dead, int frame){
	if(!dead){
		if(fallstate == false){
			switch(job){
				case WALKER:for(int j = 0; j < 100; j++){
								if(dir == 0)if(walk_right[frame][j] != 0)PlotPixel8(x+(j%10), y+(j/10), walk_right[frame][j]);
								if(dir == 1)if(walk_left[7-frame][j] != 0)PlotPixel8(x+(j%10), y+(j/10), walk_left[7-frame][j]);
							}
					break;
				
				case BLOCKER:for(int j = 0; j < 100; j++){
								if(blocking[frame][j] != 0)PlotPixel8(x+(j%10), y+(j/10), blocking[frame][j]);
							}
					break;
				
				default:;
			}
		}else{
			for(int j = 0; j < 100; j++){
				if(dir == 0)if(fall_right[frame][j] != 0)PlotPixel8(x+(j%10), y+(j/10), fall_right[frame][j]);
				if(dir == 1)if(fall_left[7-frame][j] != 0)PlotPixel8(x+(j%10), y+(j/10), fall_left[7-frame][j]);
			}
		}
	}
}

void DrawCursor(int x, int y, bool selected){
	int colour = white;
	if(selected)colour = yellow;
	//Top
	PlotPixel8(x, y-3, colour);
	PlotPixel8(x, y-2, colour);
	//Left
	PlotPixel8(x-3, y, colour);
	PlotPixel8(x-2, y, colour);
	//Bottom
	PlotPixel8(x, y+3, colour);
	PlotPixel8(x, y+2, colour);
	//Right
	PlotPixel8(x+3, y, colour);
	PlotPixel8(x+2, y, colour);
}
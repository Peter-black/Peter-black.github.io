
#ifndef SPRITE_H
#define SPRITE_H

#include <stdint.h>

extern const uint8_t walk_right[8][100];
extern const uint8_t walk_left[8][100];
extern const uint8_t fall_right[8][100];
extern const uint8_t fall_left[8][100];
extern const uint8_t blocking[8][100];
extern const uint8_t exit_portal[825];

#endif

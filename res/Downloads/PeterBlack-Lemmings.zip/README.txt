This is an extremely simplified clone of the lemmings for the GBA this version only
has one level and one job which you can apply, but was made as an early learning 
project for the GBA.
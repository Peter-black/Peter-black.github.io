###Usage

When the program opens you begin by setting the internal variables.

Firstly set the barrier size using the number keys 1-5. A barrier size of 1 means that an activated philosopher will go to eat immediately. A barrier size of 5 means that all philosophers must stop studying before any eat.

The barrier must be set after every eating session. If the barrier has been set again another eating session can occur.

Once the barrier has been set you can choose philosophers to stop studying using the keys q, w, e, r, t. Once enough philosophers have been activated to satisfy the barrier they will eat.
Animations can be turned on or off using the A key; this should be done before activating the philosophers.

Global Order Solution mode can be activated using the S key; this should be done before activating the philosophers.

If the program is in Deadlock through using a barrier of size 5 in the default mode then it can be reset by pressing the Z key twice.

Defaults are:
> Animation: ON
> Global Order Solution: OFF
> Barrier Size: 5
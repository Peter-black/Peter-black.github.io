The aim of the game is to throw grenades and explode all of the enemies.

Game concept and assets based on Fragger which can be found at http://www.miniclip.com/games/fragger/en/.


A controller is needed to control this game.

Plug a game controller in before running the program.

Controls (XBox Controller):

MENU UP - DPAD UP
MENU DOWN - DPAD DOWN
MENU SELECT - B

AIM - LEFT ANALOG
POWER - Hold B
THROW - Release B



~Peter Black 2015
I made this game as a quick test in my spare time to see how much fun the concept would be.

The aim of the game is to shoot the falling bombs into the opponents area using your cannon.
The game can be played solo against a bot or with 2 players on the same keyboard.

Controls:

Player 1:

A:	Raise Cannon
D:	Lower Cannon
SPACE:	Shoot
R:	Reload

Player 2:

RIGHT:	Raise Cannon
LEFT:	Lower Cannon
ENTER: 	Shoot
SHIFT:	Reload

Game:

ESC:	Pause
F11:	Fullscreen
F12: 	Screenshot
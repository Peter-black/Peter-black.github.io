package com.Lpb;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.Lpb.Entity.Cannon;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Level.AI;
import com.Lpb.Level.Level;
import com.Lpb.Menu.Menu;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.SpriteSheetLoader;
import com.Lpb.Sprites.Sprites;

/*
 * @author Randor
 * @version 0
 */

public class Game extends Canvas implements Runnable {
	private static final long serialVersionUID = 1L;

	public static JFrame frame;
	public static int WIDTH = 960;
	public static int HEIGHT = 540;
	public static Dimension GAME_DIM = new Dimension(WIDTH, HEIGHT);
	public static String NAME = "Bomb Bucket";
	public static Icon icon = new ImageIcon("res/icon.png");
	public static boolean fullscreen = false;
	public static boolean Vsync = true;
	public static BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
	public int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();

	long last_time = System.nanoTime();//delta timer
	
	public static SpriteSheetLoader loader;
	public static Screen screen;

	public InputHandler input = new InputHandler(this);

	public boolean running = false;
	public static boolean inGame = false;
	public static boolean paused = false;
	public static boolean soloPlay = false;
	
	public static Menu menu;
	public static Level level;
	public static AI ai;
	
	Sprite basewall = Sprites.basewall[0][0];
	Sprite basewallright = Sprites.basewall[1][0];
	Sprite basefloor = Sprites.basefloor[0][0];
	Sprite basefloorright = Sprites.basefloor[1][0];
	Sprite tempBallSprite = Sprites.cannonball[0][0];
	
	Sprite ammobox = Sprites.ammobox[0][0];

	public void start() {
		running = true;
		new Thread(this).start();
	}
	
	public void stop() {
		running = false;
	}
	
	public static void setPaused(boolean pause){
		paused = pause;
	}
	
	public static void toggleFullscreen(){
		if(!fullscreen){
			frame.setVisible(false);
			frame.dispose();	
			frame.setExtendedState(Frame.MAXIMIZED_BOTH);
			frame.setUndecorated(true);
			frame.setVisible(true);
			fullscreen = true;}
		else{
			frame.setVisible(false);
			frame.dispose();
			frame.setExtendedState(Frame.NORMAL);
			frame.setUndecorated(false);	
			frame.pack();
			frame.setVisible(true);
			frame.setLocationRelativeTo(null);	
			fullscreen = false;}
	}

	public Game() {
	}
	
	
	public static void init() {
		loader = new SpriteSheetLoader();
		screen = new Screen(WIDTH, HEIGHT);
		
		Menu.setMenu(Menu.TITLE);
	}
	
	public static void gameInit(boolean cpu){
		inGame = true;
		soloPlay = cpu;
		
		level = new Level();
		level.spawnCannon(new Cannon(35, 395, 6, true), true);
		level.spawnCannon(new Cannon(880, 395, 6, false), false);
		
		ai = new AI();
		
		Menu.setMenu(Menu.COUNTDOWN);
	}

	public static void Screenshot(){
		Date date = new Date();
	    SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd-hh-mm-ss");
		File output = new File("screenshots/" + ft.format(date) + ".png");
		
		try {
			ImageIO.write(image, "png", output);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Screenshot: " + ft.format(date) + ".png " + "has been saved.");
	}

	public void run() {
		try {
			init();
		} catch (Exception e1) {System.out.println("Failed to Initilize");}

		while (running) {
			long time = System.nanoTime();
		    int delta_time = (int) ((time - last_time) / 1000000);
		    last_time = time;
		    
			input.tick(delta_time);
			if(soloPlay && ai != null)ai.tick(delta_time);
			tick(delta_time);
			
			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			render();
		}
	}

	public void tick(double dt) {	
		if(!paused){
			level.tick(dt);
		}
			menu.tick();
	}

	public void render() {
		BufferStrategy bs = getBufferStrategy();
		if (bs == null) {
			createBufferStrategy(3);
			requestFocus();
			return;
		}

		if(inGame){
			screen.renderRect(0, 0, screen.w, screen.h, -1);
			screen.renderSprite(0, 440, basewall);
			screen.renderSprite(761, 440, basewallright);
			screen.renderSprite(182, 515, basefloor);
			screen.renderSprite(480, 515, basefloorright);
			Font.drawString("Bomb Bucket", 350, 20, -123456, Font.BIG_FONT, screen);
			Font.drawString(level.p1Score + " - " + level.p2Score, 450, 60, -123456, Font.MENU_FONT, screen);
			
			level.render(screen);
			if(level.getCannon(true).getCapacity() == 0)Font.drawString("RELOAD!", 60, 300, -65536, Font.MENU_FONT, screen);
			if(!soloPlay){
				if(level.getCannon(false).getCapacity() == 0)Font.drawString("RELOAD!", 820, 300, -65536, Font.MENU_FONT, screen);
			}
			
			//Move to GUI 
			screen.renderSprite(5, 50, ammobox);
			screen.renderSprite(886, 50, ammobox);
			
			for(int i = 0; i < level.getCannon(true).getCapacity() ; i++){
				screen.renderSprite(20, 239 - i*30, tempBallSprite);
			}
			
			for(int i = 0; i < level.getCannon(false).getCapacity() ; i++){
				screen.renderSprite(901, 239 - i*30, tempBallSprite);
			}
		}
		
		menu.render(screen);
		
		for (int y = 0; y < screen.h; y++) {
			for (int x = 0; x < screen.w; x++) {
				pixels[x + y * WIDTH] = screen.pixels[x + y * screen.w];
			}
		}
		
		//Drawing buffered image to screen.
		Graphics g = bs.getDrawGraphics();
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		g.dispose();
		bs.show();
		
	}
	

	public static void main(String[] args) {	
		Game game = new Game();
		
		game.setPreferredSize(GAME_DIM);
		game.setMaximumSize(GAME_DIM);
		game.setMinimumSize(GAME_DIM);

		frame = new JFrame(NAME);
		frame.setIconImage(((ImageIcon) icon).getImage());
		frame.setLayout(new BorderLayout());
		frame.add(game, BorderLayout.CENTER);
		frame.pack();	
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		game.start();
	}
}
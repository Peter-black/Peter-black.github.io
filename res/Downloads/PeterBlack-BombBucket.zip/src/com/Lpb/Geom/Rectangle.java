package com.Lpb.Geom;

import com.Lpb.Graphics.Screen;

public class Rectangle {
	public int x, y, w, h;
	int[] area;
	
	public Rectangle(int x, int y, int w, int h){
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		area = new int[w * h];
	}
	
	public boolean intersects(Rectangle rect){
    	for(int i = x; i < x+w; i ++){
    	for(int j = rect.x; j< rect.x+rect.w; j++){
    	for(int k = y; k < y+h; k ++){
    	for(int l = rect.y; l< rect.y+rect.h; l++){
    		if(i == j && k == l){
    			return true;
    		}
    	}}
    	}}
    	
    	return false;
    }

	public void render(Screen screen){
		screen.renderRect(x, y, w, h, -16545);
	}
}

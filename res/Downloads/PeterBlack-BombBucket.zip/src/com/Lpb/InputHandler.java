package com.Lpb;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import com.Lpb.Menu.Menu;

public class InputHandler implements KeyListener, MouseWheelListener, MouseListener, MouseMotionListener{
	
	public class Key{	
		public boolean state;
		public boolean clicked;
		
		public Key(boolean state, boolean clicked){
			this.state = state;
			this.clicked = clicked;
		}
	}
	//P1
	public Key a = new Key(false, false);
	public Key d = new Key(false, false);
	public Key space = new Key(false, false);
	public Key r = new Key(false, false);
	//P2
	public Key left = new Key(false, false);
	public Key right = new Key(false, false);
	public Key enter = new Key(false, false);
	public Key shift = new Key(false, false);
	

	public Key one = new Key(false, false);
	public Key two = new Key(false, false);
	public Key three = new Key(false, false);
	
	public Key back = new Key(false, false);
	
	public Key drop = new Key(false, false);
	
	
	
	public Key log = new Key(false, false);
	
	public Key esc = new Key(false, false);
	public Key fullscreen = new Key(false, false);
	public Key screenshot = new Key(false, false);
	
	public boolean 
	inButton = false,
	mouseClicked = false;
	
	public static double mX, mY;
	public int notches;
	
	public InputHandler(Game game){
		game.addKeyListener(this);
		game.addMouseWheelListener(this);
		game.addMouseListener(this);
		game.addMouseMotionListener(this);
	}
	
	public void tick(double dt){
		if(!Game.paused){
			//P1
			if(a.state && !a.clicked){
				Game.level.getCannon(true).angle -= 0.5 *dt;
			}
			if(d.state && !d.clicked){
				Game.level.getCannon(true).angle += 0.5*dt;
			}
			if(space.state && !space.clicked){
				Game.level.getCannon(true).shoot(dt);
				space.clicked = true;
			}
			if(r.state && !r.clicked){
				Game.level.getCannon(true).reload();
				r.clicked = true;
			}
			
			if(!Game.soloPlay){
				//P2
				if(left.state && !left.clicked){
					Game.level.getCannon(false).angle += 0.5*dt;
				}
				if(right.state && !right.clicked){
					Game.level.getCannon(false).angle -= 0.5*dt;
				}
				if(enter.state && !enter.clicked){
					Game.level.getCannon(false).shoot(dt);
					enter.clicked = true;
				}
				if(shift.state && !shift.clicked){
					Game.level.getCannon(false).reload();
					shift.clicked = true;
				}
			}
		}
		
		if(esc.state && !esc.clicked){
			Menu.setMenu(Menu.PAUSE);
			esc.clicked = true;
		}
		
		//EXTRA INPUT
		if(fullscreen.state && !fullscreen.clicked){
			/*Game.toggleFullscreen();	*/
			Menu.setMenu(Menu.NONE);
			fullscreen.clicked = true;
		}
		
		if(screenshot.state && !screenshot.clicked){Game.Screenshot();screenshot.clicked = true;}
		
	}
	
	public void toggle(KeyEvent ke,boolean pressed){
		int keyCode = ke.getKeyCode();
		//P1
		if(keyCode == KeyEvent.VK_A) a.state = pressed;
		if(keyCode == KeyEvent.VK_D) d.state = pressed;
		if(keyCode == KeyEvent.VK_SPACE) space.state = pressed;
		if(keyCode == KeyEvent.VK_R) r.state = pressed;
		//P2
		if(keyCode == KeyEvent.VK_LEFT) left.state = pressed;
		if(keyCode == KeyEvent.VK_RIGHT) right.state = pressed;
		if(keyCode == KeyEvent.VK_ENTER) enter.state = pressed;
		if(keyCode == KeyEvent.VK_SHIFT) shift.state = pressed;
		
		if(keyCode == KeyEvent.VK_1) one.state = pressed;
		if(keyCode == KeyEvent.VK_2) two.state = pressed;
		if(keyCode == KeyEvent.VK_3) three.state = pressed;

		if(keyCode == KeyEvent.VK_BACK_SPACE) back.state = pressed;
		
		if(keyCode == KeyEvent.VK_Q) drop.state = pressed;
		
		
		if(keyCode == KeyEvent.VK_L) log.state = pressed; 
		
		if(keyCode == KeyEvent.VK_ESCAPE) esc.state = pressed;
		if(keyCode == KeyEvent.VK_F11) fullscreen.state = pressed;
		if(keyCode == KeyEvent.VK_F12) screenshot.state = pressed; 
	}
	
	public void keyTyped(KeyEvent ke) {

	}

	public void keyPressed(KeyEvent ke) {
		toggle(ke,true);
	}
	
	public void keyReleased(KeyEvent e) {
		toggle(e,false);
		//P1
		if(e.getKeyCode() == KeyEvent.VK_A) a.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_D) d.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_SPACE) space.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_R) r.clicked = false;
		//P2
		if(e.getKeyCode() == KeyEvent.VK_LEFT) left.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) right.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_ENTER) enter.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_SHIFT) shift.clicked = false;
		
		if(e.getKeyCode() == KeyEvent.VK_L) log.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE) esc.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_F11) fullscreen.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_F12) screenshot.clicked = false;
	}

	public void mouseWheelMoved(MouseWheelEvent e) {
		notches = e.getWheelRotation();
	}

	@Override
	public void mouseClicked(MouseEvent me) {
		
	}

	@Override
	public void mouseEntered(MouseEvent me) {
		
	}

	@Override
	public void mouseExited(MouseEvent me) {
		
	}

	@Override
	public void mousePressed(MouseEvent me) {
		setMouseGameCoords(me.getX(), me.getY());
		
		if(Menu.getMenu() != Menu.NONE){
			for(int i=0;i<Menu.getMenu().buttons.length;i++){
				if(Menu.getMenu().buttons[i].intersects(mX, mY)&& !mouseClicked){
					Menu.getMenu().buttonAction(i);
					break;
				}
			}
			mouseClicked = true;
		}
		
	}

	@Override
	public void mouseReleased(MouseEvent me) {
		mouseClicked = false;
	}

	@Override
	public void mouseDragged(MouseEvent me) {
		setMouseGameCoords(me.getX(), me.getY());
	}

	@Override
	public void mouseMoved(MouseEvent me) {
		setMouseGameCoords(me.getX(), me.getY());
		
		inButton = false;
	}
	
	public void setMouseGameCoords(int rawX, int rawY){
		if(Game.fullscreen){		
			mX = rawX/(double)(Game.frame.getWidth())*(double)(Game.screen.w);
			mY = rawY/(double)(Game.frame.getHeight())*(double)(Game.screen.h);
		}else{
			mX = rawX/(double)(Game.frame.getWidth()/Game.screen.w);
			mY = rawY/(double)(Game.frame.getHeight()/Game.screen.h);
		}
	}
}
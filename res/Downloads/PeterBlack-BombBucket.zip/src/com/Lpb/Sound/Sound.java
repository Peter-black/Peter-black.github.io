package com.Lpb.Sound;

import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import com.Lpb.Game;

public enum Sound {
	CANNON_SHOOT("/sounds/cannonshoot.wav"),
	BALL_HIT("/sounds/ballhit.wav");

	public static enum Volume {
		MUTE, LOW, MEDIUM, HIGH;
	}

	public static Volume volume = Volume.MEDIUM;
	
	public FloatControl gainControl;

	private Clip clip;

	Sound(String soundFileName) {
		try {
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(Game.class.getResource(soundFileName));
			clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			
			gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
			
		} catch (UnsupportedAudioFileException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	public void play() {
		if (volume == Volume.MUTE) return;
		if (volume == Volume.LOW) gainControl.setValue(-30.0f); 
		if (volume == Volume.MEDIUM) gainControl.setValue(-15.0f); 
		if (volume == Volume.HIGH) gainControl.setValue(+06.0f); 
		
			if (clip.isRunning()) clip.stop();  
				clip.setFramePosition(0); 
				clip.start();   
		
	}
	
	public void stop() {
		clip.stop();
	}

	public static void init() {
		values();
	}
	
	public boolean isRunning(){
		return clip.isRunning();
	}
}

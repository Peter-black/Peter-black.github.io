package com.Lpb.Sprites;

public class SpriteAnimator implements Runnable{
		
	Sprite[][] spriteSheet;
	Sprite currSprite;
	public int delay;
	private boolean running;
	public int animateTick = 0;
	public int currentFrame = 1;
	public int currentSet = 0;
	
	public SpriteAnimator(Sprite[][] sprites,int delay){
		spriteSheet = sprites;
		this.delay = delay;
	}
	
	public void start(){
		setRunning(true);
		new Thread(this).start();
	}
	
	public void run(){
		while (isRunning()) {
			animate();
			try {
				Thread.sleep(60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void animate(){		
		if(animateTick == 0)currentFrame =1;
		if(animateTick == delay)currentFrame =2;
		if(animateTick == delay*2)currentFrame = 1;
		if(animateTick == delay*3)currentFrame = 0;
		currSprite = spriteSheet[currentFrame][currentSet];
		animateTick++;
		if(animateTick >= delay*4)animateTick = 0;
	}
	
	public Sprite getCurrSprite(){
		return currSprite;
	}

	public void stop(){
		setRunning(false);
		currSprite = spriteSheet[currentFrame][currentSet];
	}
	
	public void setCurrentSet(int dir){
		currentSet = dir;
		currSprite = spriteSheet[currentFrame][currentSet];
	}
	
	public void setCurrentFrame(int frame){
		currentFrame = frame;
		currSprite = spriteSheet[currentFrame][currentSet];
	}
	
	public int getCurrentSet(){
		return currentSet;
	}
	
	public int getCurrentFrame(){
		return currentFrame;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}
}
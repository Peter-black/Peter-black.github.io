package com.Lpb.Sprites;


public class Animator implements Runnable{
		
	Sprite[][] spriteSheet;
	Sprite currPic;
	public int frames;
	public int delay;
	public boolean loop;
	private boolean running;
	public int animateTick = 0;
	public int currentFrame = 0;
	
	public Animator(Sprite[][] sprites, int frames, int delay, boolean loop){
		this.spriteSheet = sprites;
		this.frames = frames;
		this.delay = delay;
		this.loop = loop;
		currPic = spriteSheet[0][0];
	}
	
	public void start(){
		setRunning(true);
		new Thread(this).start();
	}
	
	public void run(){
		while (isRunning()) {
			animate();
			try {
				Thread.sleep(60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void animate(){				
		if(animateTick == delay){
			if(currentFrame < frames-1){
				currentFrame++;
			}else if(loop){ currentFrame = 0; }//animateTick = 0;}
			else if(!loop){stop();}
		}
		currPic = spriteSheet[currentFrame][0];
		animateTick++;
		if(animateTick > delay) animateTick = 0;
	}
	
	public Sprite getCurrPicture(){
		return currPic;
	}

	public void stop(){
		setRunning(false);
		currPic = spriteSheet[currentFrame][0];
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}
}
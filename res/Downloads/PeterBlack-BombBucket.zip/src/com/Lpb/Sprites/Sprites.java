package com.Lpb.Sprites;

public class Sprites {
	
	public static Sprite[][] cannonhead = SpriteSheetLoader.cutTiles("/cannonhead.png", 100, 100);
	public static Sprite[][] cannonbase = SpriteSheetLoader.cutTiles("/cannonbase.png", 51, 45);
	public static Sprite[][] cannonball = SpriteSheetLoader.cutTiles("/cannonball.png", 40, 40);
	public static Sprite[][] ammobox = SpriteSheetLoader.cutTiles("/ammobox.png", 69, 270);
	public static Sprite[][] bomb = SpriteSheetLoader.cutTiles("/bomb.png", 46, 60);
	public static Sprite[][] basewall = SpriteSheetLoader.cutTiles("/basewall.png", 199, 105);
	public static Sprite[][] basefloor = SpriteSheetLoader.cutTiles("/basefloor.png", 298, 30);
	public static Sprite[][] countdown = SpriteSheetLoader.cutTiles("/321go.png", 400, 180);

	//FONT
	public static Sprite[][] font = SpriteSheetLoader.cutTiles("/fonts/font.png", 6, 10);
	public static Sprite[][] menuFont = SpriteSheetLoader.cutTiles("/fonts/menuFont.png", 12, 20);
	public static Sprite[][] bigFont = SpriteSheetLoader.cutTiles("/fonts/bigFont.png", 24, 40);
}
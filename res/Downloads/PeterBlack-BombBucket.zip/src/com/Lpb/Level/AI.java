package com.Lpb.Level;

import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Timer;
import com.Lpb.Entity.Entity;

public class AI {

	Timer shootTimer;
	Random random;
	double angle = 0;
	
	public AI(){
		shootTimer = new Timer();
		random = new Random();
		
		shootTimer.start(random.nextInt(1201)+600);
	}
	
	public void tick(double dt){
		if(!Game.paused){
			angle = calculateAngle(Game.level.getBomb(0));
			
			if(Game.level.getCannon(false).angle  > angle)moveAngle(-1*dt);
			if(Game.level.getCannon(false).angle  < angle)moveAngle(1*dt);

			if(shootTimer.checkTime()){
				angle += random.nextGaussian()*10;//random miss chance
				if(Game.level.getCannon(false).angle  > angle)moveAngle(-5*dt);
				if(Game.level.getCannon(false).angle  < angle)moveAngle(5*dt);
				
				shoot(dt);
				reload();
				shootTimer.start(random.nextInt(1201)+600*dt);
			}
		}
	}
	
	private void moveAngle(double angle){
		Game.level.getCannon(false).angle += angle;
	}
	
	private double calculateAngle(Entity bomb){
		if(bomb == null)return 120;
		int x = Game.level.getCannon(false).getX();
		int y = Game.level.getCannon(false).getY();
		int bombX = bomb.getX();
		int bombY = bomb.getY();
		
		return Math.toDegrees(Math.atan2(bombX-x, bombY-y))+250;
		
	}
	
	private void shoot(double dt){
		Game.level.getCannon(false).shoot(dt);
	}
	
	private void reload(){
		Game.level.getCannon(false).reload();
	}
}

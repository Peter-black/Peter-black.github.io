package com.Lpb.Level;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import com.Lpb.Game;
import com.Lpb.Timer;
import com.Lpb.Entity.Bomb;
import com.Lpb.Entity.Entity;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sound.Sound;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Level {
	
	private ArrayList<Entity> balls = new ArrayList<Entity>();
	private ArrayList<Entity> bombs = new ArrayList<Entity>();
	private ArrayList<Point> ghostBombs = new ArrayList<Point>();
	private Entity[] cannons = new Entity[2];
	private Timer bombDropTimer = new Timer();
	private Random bombWait = new Random();
	
	private Sprite ghostBombSprite = Sprites.bomb[0][0];
	public int p1Score, p2Score;

	public Level(){
		bombDropTimer.start(0);//Gets the ball rolling
	}
	
	public void spawnBall(Entity entity, int amount){
		for(int i=0;i<amount;i++){
			balls.add(entity);
		}
	}
	
	public void spawnBomb(Entity entity, int amount){
		for(int i=0;i<amount;i++){
			bombs.add(entity);
		}
	}
	
	public void spawnCannon(Entity cannon, boolean player){
		if(player)cannons[0] = cannon;
		else cannons[1] = cannon;
	}
	
	public void ghostBomb(Entity bomb){
		ghostBombs.add(new Point(bomb.getX(), bomb.getY()));
		bombs.remove(bomb);
	}
	
	public void tick(double dt){
		for(int i = 0; i < balls.size(); i++){
			if(balls.get(i).getX() > Game.screen.w || balls.get(i).getX() < 0){balls.remove(i);break;}
			if(balls.get(i).getY() > Game.screen.h || balls.get(i).getY() < 0){balls.remove(i);break;}
		}
		
		for(int i = 0; i < bombs.size(); i++){
			if(bombs.get(i).getX() >= 715){bombs.get(i).setPos(715, bombs.get(i).getY());}
			if(bombs.get(i).getX() <= 199){bombs.get(i).setPos(199, bombs.get(i).getY());}
			
			if(bombs.get(i).getY() >= 455){
				bombs.get(i).setVel(0, 0);
				if(bombs.get(i).getX() > 457){p1Score += 1;ghostBomb(bombs.get(i));break;}
				if(bombs.get(i).getX() < 457){p2Score += 1;ghostBomb(bombs.get(i));break;}
			}
		}
		
		for(int i = 0; i < balls.size(); i++){
		for(int j = 0; j < bombs.size(); j++){
			if(balls.get(i).getCollRect().intersects(bombs.get(j).getCollRect())){	
				if(balls.get(i).getXVel() > 0){
					bombs.get(j).bump(12-balls.get(i).getXVel()*dt, balls.get(i).getYVel()*dt);//the 12 balances it so that hitting it higher up is more poweful.
				}else if(balls.get(i).getXVel() < 0){
					bombs.get(j).bump(-12-balls.get(i).getXVel()*dt, balls.get(i).getYVel()*dt);
				}

				balls.remove(i);
				Sound.BALL_HIT.play();
				break;
			}
		}
		}
		
		if(bombDropTimer.isStarted() && bombDropTimer.checkTime()){
			spawnBomb(new Bomb(457, 10, 0, 0.7), 1);
			bombDropTimer.start((bombWait.nextInt(5)+2)*1000);
		}
		
		
		if(balls != null){
			for(int i = 0; i < balls.size(); i++){
				balls.get(i).tick();
			}
		}
		if(bombs != null){
			for(int i = 0; i < bombs.size(); i++){
				bombs.get(i).tick();
			}
		}
		for(int i = 0; i < cannons.length; i++){
			if(cannons[i] != null)cannons[i].tick();
		}
	}
	
	public void render(Screen screen){
		if(balls != null){
			for(int i = 0; i < balls.size(); i++){
				balls.get(i).render(screen);
			}
		}
		
		if(bombs != null){
			for(int i = 0; i < bombs.size(); i++){
				bombs.get(i).render(screen);
			}
		}
		
		if(ghostBombs != null){
			for(int i = 0; i < ghostBombs.size(); i++){
				screen.renderSprite(ghostBombs.get(i).x, ghostBombs.get(i).y, ghostBombSprite);
			}
		}
		
		for(int i = 0; i < cannons.length; i++){
			if(cannons[i] != null)cannons[i].render(screen);
		}
	}
	
	public Entity getCannon(boolean player){
		if(player)return cannons[0];
		return cannons[1];
	}
	
	public Entity getBomb(int bomb){
		if(bombs.size() != 0)return bombs.get(bomb);
		
		return null;
	}
}

package com.Lpb.Entity;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Ball extends Entity{

	int spinSpeed = 2;
	
	public Ball(int x, int y, double xVel, double yVel) {
		super(x, y, xVel, yVel);
		w = 33;
		h = 33;
		refSprite = Sprites.cannonball[0][0];
		sprite = new Sprite(refSprite.w, refSprite.h);
		
	}
	
	public void tick(){
		super.tick();
		angle += spinSpeed;
	}

	public void render(Screen screen){
		screen.rotateSprite(refSprite, sprite, angle);
		screen.renderSprite(x, y, sprite);
		//collRect.render(screen);
	}
}

package com.Lpb.Entity;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class Bomb extends Entity{
	
	public Bomb(int x, int y, double xVel, double yVel) {
		super(x, y, xVel, yVel);
		w = 46;
		h = 60;
		sprite = Sprites.bomb[0][0];
	}

	public void render(Screen screen){
		screen.renderSprite(x, y, sprite);
		//collRect.render(screen);
	}
	
}

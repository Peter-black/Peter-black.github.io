package com.Lpb.Entity;

import com.Lpb.Game;
import com.Lpb.Timer;
import com.Lpb.Geom.Rectangle;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sound.Sound;
import com.Lpb.Sprites.Sprite;

public class Entity {

	int x,y,w,h;
	double xVel,yVel;
	double xBumpVel = 0, yBumpVel = 0;
	double tX,tY;
	int capacity, maxCapacity;
	public double angle;
	boolean orient;
	Rectangle collRect;
	Timer reloadTimer;
	int reloadTime = 800;
	Sprite refSprite;
	Sprite sprite;
	
	//Cannon
	public Entity (int x, int y, int capacity, boolean orientation){
		this.x = x;
		this.y = y;
		this.maxCapacity = capacity;
		this.capacity = maxCapacity;
		angle = 0;
		orient = orientation;
		collRect = new Rectangle(x, y, w, h);
		reloadTimer = new Timer();
	}
	
	//Moveables
	public Entity (int x, int y, double xVel, double yVel){
		this.x = x;
		this.y = y;
		this.xVel = xVel;
		this.yVel = yVel;
		angle = 0;
		collRect = new Rectangle(x, y, w, h);
		reloadTimer = new Timer();
	}
	
	private void move(){		
		if(xVel > 0){
			if(xVel - (int)xVel != 0){
				tX += (xVel-(int)xVel);
				if(tX >= 1){
					x += (int)tX + (int)xVel + (int)xBumpVel;
					tX -= (int)tX;
				}else{
					x+=(int)xVel + (int)xBumpVel;
				}
			}else{
				x += xVel + (int)xBumpVel;
			}
		}else{
			if(xVel - (int)xVel != 0){
				tX += (xVel-(int)xVel);
				if(tX <= 1){
					x += (int)tX + (int)xVel + (int)xBumpVel;
					tX -= (int)tX;
				}else{
					x+=(int)xVel + (int)xBumpVel;
				}
			}else{
				x += xVel + (int)xBumpVel;
			}
		}
		
		if(yVel > 0){
			if(yVel - (int)yVel != 0){
				tY += (yVel-(int)yVel);
				if(tY >= 1){
					y += (int)tY + (int)yVel + (int)yBumpVel;
					tY -= (int)tY;
				}else{
					y+=(int)yVel + (int)yBumpVel;
				}
			}else{
				y += yVel + (int)yBumpVel;
			}
		}else{
			if(yVel - (int)yVel != 0){
				tY += (yVel-(int)yVel);
				if(tY <= 1){
					y += (int)tY + (int)yVel + (int)yBumpVel;
					tY -= (int)tY;
				}else{
					y+=(int)yVel + (int)yBumpVel;
				}
			}else{
				y += yVel + (int)yBumpVel;
			}
		}
	}
	
	public void shoot(double dt){
		if(capacity > 0){
			double xSpeed, ySpeed;
			if(orient){
				xSpeed = Math.cos(Math.toRadians(angle-25));
				ySpeed = Math.sin(Math.toRadians(angle-25));
			}else{
				xSpeed = Math.cos(Math.toRadians(-(angle+25)));
				ySpeed = Math.sin(Math.toRadians(-(angle+25)));
			}
			Game.level.spawnBall(new Ball(x+5, y-10, xSpeed*7*dt, ySpeed*7*dt), 1);
			capacity -= 1;
			if(reloadTimer.isStarted())reloadTimer.stop();
			Sound.CANNON_SHOOT.play();
		}
	}
	
	public void reload(){
		if(!reloadTimer.isStarted()){
			reloadTimer.start(reloadTime);
		}
	}
	
	private void doReload(){
		capacity += 1;
	}
	
	public void bump(double xVel, double yVel){
		xBumpVel = xVel;
		yBumpVel = yVel;
	}
	
	public void tick(){
		if(angle > 360) angle = 0;
		if(angle < 0) angle = 360;
		collRect = new Rectangle(x + sprite.w/2 - w/2, y + sprite.h/2 - h/2, w, h);
		if(xBumpVel > 0)xBumpVel -= 0.2;
		if(xBumpVel < 0)xBumpVel += 0.2;
		if(yBumpVel > 0)yBumpVel -= 0.2;
		if(yBumpVel < 0)yBumpVel += 0.2;
		move();
		
		if(reloadTimer.isStarted() && reloadTimer.checkTime()){
			if(capacity < maxCapacity){
				doReload();
				reloadTimer.start(reloadTime);
			}
		}
	}
	
	public void render(Screen screen){
	}
	
	public void setVel(double xVel, double yVel){
		this.xVel = xVel;
		this.yVel = yVel;
	}
	
	public void setPos(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public double getXVel(){
		return xVel;
	}
	
	public double getYVel(){
		return yVel;
	}
	
	public int getCapacity(){
		return capacity;
	}
	
	public Rectangle getCollRect(){
		return collRect;
	}
	
}

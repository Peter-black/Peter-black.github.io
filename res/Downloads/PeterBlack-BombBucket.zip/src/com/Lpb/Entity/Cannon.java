package com.Lpb.Entity;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Cannon extends Entity{

	Sprite baseSprite;

	public Cannon (int x, int y, int capacity, boolean orientation){
		super(x, y, capacity, orientation);
		w = 51;
		h = 45;
		
		if(!orient)angle = 120;
		
		baseSprite = Sprites.cannonbase[0][0];
		refSprite = Sprites.cannonhead[0][0];
		sprite = new Sprite(refSprite.w,refSprite.h);	
	}

	public void render(Screen screen){
		screen.renderSprite(x, y, baseSprite);
		if(orient)screen.rotateSprite(refSprite, sprite, angle);
		else screen.rotateSprite(refSprite, sprite, -angle);
		screen.renderSprite(x-25, y-40, sprite);
		
		//collRect.render(screen);
	}
}

package com.Lpb.Menu;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;

public class Button {
	public int x, y, w, h;
	int[] area;
	private String text;
	private boolean active, clicked;
	
	public Button(int x, int y, int w, int h, String text, boolean active){
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.text = text;
		this.active = active;
		area = new int[w * h];
	}
	public boolean intersects(double mX, double mY){
    	if(mX >= x && mX <= x+w && mY >= y && mY <= y+h)return true;
    	return false;
    }

	public void render(Screen screen){
		screen.renderRect(x, y, w, h, -123456789);
		Font.drawString(text, (x)+(w/2)-((text.length()/2)*12), (y)+(h/2)-(10), -1, Font.MENU_FONT, screen);
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isClicked() {
		return clicked;
	}

	public void setClicked(boolean clicked) {
		this.clicked = clicked;
	}
	
}

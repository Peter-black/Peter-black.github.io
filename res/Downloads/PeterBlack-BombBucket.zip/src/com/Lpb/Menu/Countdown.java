package com.Lpb.Menu;

import com.Lpb.Timer;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Countdown extends Menu{
	
	private Sprite number;
	
	public Countdown(String title, boolean pause, int selItem, int maxItem){
		super(title, pause, selItem, maxItem);
		countdownTimer = new Timer();
		number = Sprites.countdown[0][0];
	}
	
	public void tick(){
		super.tick();
		if(countdownTimer.checkTimeLeft() > 3000){
			number = Sprites.countdown[3][0];
		}else if(countdownTimer.checkTimeLeft() > 2000 && countdownTimer.checkTimeLeft() < 3000){
			number = Sprites.countdown[2][0];
		}else if(countdownTimer.checkTimeLeft() > 1000 && countdownTimer.checkTimeLeft() < 2000){
			number = Sprites.countdown[1][0];
		}else if(countdownTimer.checkTimeLeft() < 1000){
			number = Sprites.countdown[0][0];
		}
		
		if(countdownTimer.checkTime()){
			setMenu(NONE);
		}
	}
	
	public void render(Screen screen){
		screen.renderSprite(screen.w/2 - 200, screen.h/2 - 90, number);
	}

}

package com.Lpb.Menu;

import com.Lpb.Graphics.Screen;

public class OptionsMenu extends Menu{
	
	public OptionsMenu(String title, boolean pause, int selItem, int maxItem){
		super(title, pause, selItem, maxItem);
		
		buttons[0] = new Button(400, 200, 200, 20,"By Peter Black", true);
		buttons[1] = new Button(400, 230, 200, 20,"", true);
		buttons[2] = new Button(400, 260, 200, 20,"", true);
		buttons[3] = new Button(400, 290, 200, 20,"Return", true);
		
	}
	
	public void buttonAction(int button){
		switch(button){
		case 0:	System.out.println("0");
		break;	
				
		case 1:	System.out.println("1");
		break;
		
		case 2:	System.out.println("2");
		break;

		case 3:	setMenu(PREVMENU);
		break;	
		}
	}
	
	public void render(Screen screen){
		super.render(screen);
	}

}

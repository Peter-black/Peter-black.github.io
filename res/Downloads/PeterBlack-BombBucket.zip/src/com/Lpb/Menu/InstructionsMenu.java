package com.Lpb.Menu;

import com.Lpb.Graphics.Screen;

public class InstructionsMenu extends Menu{
	
	public InstructionsMenu(String title, boolean pause, int selItem, int maxItem){
		super(title, pause, selItem, maxItem);
		
		buttons[0] = new Button(400, 100, 200, 70,"Instructions in README", true);
		buttons[1] = new Button(400, 200, 200, 20,"Return", true);
		
	}
	
	public void buttonAction(int button){
		switch(button){
		case 1: Menu.setMenu(PREVMENU);
		break;	
		
		}
	}
	
	public void render(Screen screen){
		super.render(screen);
	}

}

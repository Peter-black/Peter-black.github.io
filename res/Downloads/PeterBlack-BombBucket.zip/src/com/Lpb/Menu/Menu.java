package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Timer;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;

public class Menu {
	
	public static final Menu 
	NONE = new Menu("", false, 0, 0),
	TITLE = new TitleMenu("Bomb Bucket", true, 1, 5),
	PAUSE = new PauseMenu("Paused", true, 1, 4),
	OPTIONS = new OptionsMenu("Options", true, 1, 4),
	INSTRUCTIONS = new InstructionsMenu("Instructions", true, 1, 2),
	SOLOPLAY = new SoloMenu("Singleplauer", true, 1, 8),
	COUNTDOWN = new Countdown("", true, 0, 0);
	
	public static Menu PREVMENU;
	
	protected String title;
	protected boolean pause;
	protected int selItem, maxItem;
	public Button[] buttons;
	
	protected static Timer countdownTimer;
	
	public Menu(String title, boolean pause, int selItem, int maxItem){
		this.title = title;
		this.pause = pause;
		this.selItem = selItem;
		this.maxItem = maxItem;
		buttons = new Button[maxItem];
	}
	
	public void tick(){
		
	}
	
	public void render(Screen screen){
		if(getMenu() != NONE){
			screen.renderRect(0, 0, screen.w, screen.h, -16777216);
			Font.drawString(title+"", (screen.w/2) - ((title.length()*24)/2), 50, -1, Font.BIG_FONT, screen);
			for(int i=0;i<maxItem;i++){
				if(buttons != null)buttons[i].render(screen);
			}
		}
	}
	
	public void buttonAction(int button){
	}

	public static Menu getMenu() {
		return Game.menu;
	}

	public static void setMenu(Menu menu) {
		if(menu != PREVMENU)PREVMENU = Game.menu;
		Game.setPaused(menu.pause);
		Game.menu = menu;
		if(menu == COUNTDOWN)countdownTimer.start(4000);
	}
}

package com.Lpb.Menu;

import com.Lpb.Game;
import com.Lpb.Graphics.Screen;

public class TitleMenu extends Menu{
	
	public TitleMenu(String title, boolean pause, int selItem, int maxItem){
		super(title, pause, selItem, maxItem);
		
		buttons[0] = new Button(350, 150, 200, 40,"Singleplayer", true);
		buttons[1] = new Button(350, 200, 200, 40,"Multiplayer", true);
		buttons[2] = new Button(350, 250, 200, 40,"Instructions", true);
		buttons[3] = new Button(350, 300, 200, 40,"Options", true);
		buttons[4] = new Button(350, 350, 200, 40,"Exit", true);
	}
	
	public void buttonAction(int button){
		switch(button){
		case 0: Game.gameInit(true);
		break;	
				
		case 1:	Game.gameInit(false);
		break;

		case 2:	setMenu(INSTRUCTIONS);
		break;
		
		case 3:	setMenu(OPTIONS);
		break;
		
		case 4:	System.exit(0);
		break;
		
		}
	}
	
	public void render(Screen screen){
		super.render(screen);
		
	}

}

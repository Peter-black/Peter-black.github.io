package com.Lpb;

public class Timer {

	long currTime, endTime;
	boolean started = false;
	
	public Timer(){
	}
	
	public void start(int duration){
		endTime = System.currentTimeMillis() + duration;
		started = true;
	}
	
	public void start(double duration) {
		endTime = (long) (System.currentTimeMillis() + duration);
		started = true;
	}
	
	public void start(long duration){
		endTime = System.currentTimeMillis() + duration;
		started = true;
	}
	
	public void stop(){
		started = false;
	}
	
	public boolean checkTime(){
		currTime = System.currentTimeMillis();
		if(currTime >= endTime){started = false; return true;}
		else return false;
	}
	
	public int checkTimeLeft(){
		currTime = System.currentTimeMillis();
		return (int) (endTime - currTime);
	}
	
	public boolean isStarted(){
		return started;
	}
	
}

Two examples of pathfinding algorithms showing the calculation and final result in a console output.
The applied algorithms are the A* algorithm and the Lee Algorithm.


~Peter Black 2013
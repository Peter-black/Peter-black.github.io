This is a video of my first attempt at animation in Maya. I created all the set pieces and animated the model
running through.
package com.Lpb.Graphics;

import java.awt.Color;

import com.Lpb.Sprites.Sprite;

public class Screen {

	public int w, h;
	int xOffset = 0, yOffset = 0;
	public int[] pixels;

	public Screen(int w, int h) {
		this.w = w;
		this.h = h;

		pixels = new int[w * h];
	}

	public void renderSprite(int xPos, int yPos, Sprite sprite) {
		int height = sprite.h;
		int width = sprite.w;

		xPos -= xOffset;
		yPos -= yOffset;		
		
		for (int y = 0; y < height; y++) {
			if (y + yPos < 0 || y + yPos >= h) continue;
			for (int x = 0; x < width; x++) {
				if (x + xPos < 0 || x + xPos >= w) continue;
				int col = sprite.pixels[x + (y * width)];
				if (col != -65281 && col < 0) pixels[(x + xPos) + (y + yPos) * w] = col;
			}
		}
	}
	
	public void renderSprite(int xPos, int yPos, Sprite sprite, int color, int shift) {
		int height = sprite.h;
		int width = sprite.w;

		xPos -= xOffset;
		yPos -= yOffset;		
		
		for (int y = 0; y < height; y++) {
			if (y + yPos < 0 || y + yPos >= h) continue;
			for (int x = 0; x < width; x++) {
				if (x + xPos < 0 || x + xPos >= w) continue;
				int col = sprite.pixels[x + (y * width)];
				if (col != -65281 && col < 0 && color < 0) pixels[(x + xPos) + (y + yPos) * w] = color << shift;
				else if(col != -65281 && col < 0) pixels[(x + xPos) + (y + yPos) * w] = col << shift;
			}
		}
	}
	
	public void renderSprite(int xPos, int yPos, int minX, int minY, int maxX, int maxY, Sprite sprite) {
		int height = sprite.h;
		int width = sprite.w;

		xPos -= xOffset;
		yPos -= yOffset;		
		
		for (int y = 0; y < height; y++) {
			if (y + yPos < 0 || y + yPos >= h) continue;
			for (int x = 0; x < width; x++) {
				if (x + xPos < 0 || x + xPos >= w) continue;
				if(x+xPos < minX || x+xPos > maxX) continue;
				if(y+yPos < minY || y+yPos > maxY) continue;
					int col = sprite.pixels[x + (y * width)];
				if (col != -65281 && col < 0) pixels[(x + xPos) + (y + yPos) * w] = col;
			}
		}
	}
	
	public void renderRect(int xPos, int yPos, int width, int height, int color){
		xPos -= xOffset;
		yPos -= yOffset;
		
		for (int y = 0; y < height; y++) {
			if (y + yPos < 0 || y + yPos >= h) continue;
			for (int x = 0; x < width; x++) {
				if (x + xPos < 0 || x + xPos >= w) continue;
				if (color < 0) pixels[(x + xPos) + (y + yPos) * w] = color;
			}
		}
	}
	
	public void renderCircle(int x, int y, int r, int color){
		int xPos;
		int yPos;
		
		int perim = (int) (Math.PI * (Math.pow(r, 2)));

		for(int i = 0; i < perim; i++){
			xPos = (int)(r * Math.cos(i*(2*Math.PI/perim)));
			yPos = (int)(r * Math.sin(i*(2*Math.PI/perim)));
		    if (y + yPos < 0 || y + yPos >= h) continue;
		    if (x + xPos < 0 || x + xPos >= w) continue;
		    
		    if (color < 0) pixels[(x + xPos) + (y + yPos) * w] = color;
		}
	}
	
	public void renderFullCircle(int x, int y, int r, int color){
		int Left = x - r;
		int Right = Left + r * 2;
		int Top = y - r;
		int Bottom = Top + r * 2;
		
		for (int j = Top; j <= Bottom; ++j){
		for (int k = Left; k <= Right; ++k){
			
			double dist = Math.pow(x - k, 2) + Math.pow(y - j, 2);
		    if (dist <= Math.pow(r, 2)){
		    	
		        if (k < 0 || j >= h) continue;
				if (j < 0 || k >= w) continue;
				    
				if (color < 0) pixels[k + j * w] = color;
		    }
		}
		}
	}
	
	public void darken(int passes){
		Color pixelCol;
		for(int i = 0; i < pixels.length; i++){
			pixelCol = new Color(pixels[i]);
			for(int p = 0; p < passes; p++){		
				pixelCol = pixelCol.darker();		
			}
			pixels[i] = pixelCol.getRGB();		
		}
	}
	
	public void brighten(int passes){
		Color pixelCol;
		for(int i = 0; i < pixels.length; i++){
			pixelCol = new Color(pixels[i]);
			for(int p = 0; p < passes; p++){
			pixelCol = pixelCol.brighter();
			}
			pixels[i] = pixelCol.getRGB();		
		}
	}

	public void setOffs(int xOffs , int yOffs) {
		xOffset = xOffs;
		yOffset = yOffs;
	}
}
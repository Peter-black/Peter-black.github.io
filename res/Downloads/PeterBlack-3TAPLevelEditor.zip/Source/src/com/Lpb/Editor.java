package com.Lpb;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.Lpb.Entity.Camera;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Gui.Gui;
import com.Lpb.Inventory.ItemInventory;
import com.Lpb.Inventory.TileInventory;
import com.Lpb.Level.ItemMap;
import com.Lpb.Level.Level;
import com.Lpb.Menu.Menu;
import com.Lpb.Sprites.SpriteSheetLoader;

/*
 * @author Peter Black
 * @version 0.7
 */

public class Editor extends Canvas implements Runnable {
	private static final long serialVersionUID = 1L;

	public static JFrame frame;
	public static int WIDTH = 480;
	public static int HEIGHT = 270;
	public static int SCALE = 2;
	public static Dimension GAME_DIM = new Dimension(WIDTH * SCALE, HEIGHT * SCALE);
	public static String NAME = "3TAP Level Editor";
	public static String filename;
	public static Icon icon = new ImageIcon("res/icon.png");
	public static boolean Vsync = true;
	public static BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
	public int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();

	public static SpriteSheetLoader loader;
	public static Screen screen;
	
	//public static final ItemMap ITEMMAP = new ItemMap(0,16,16,Sprites.level[1][0]);
	public static Level currLevel;
	public static ItemMap currItemMap;
	
	public InputHandler input = new InputHandler(this);
	public static Camera camera;
	public static Gui gui;
	public static TileInventory tileInventory;
	public static ItemInventory itemInventory;
	public static boolean currInv = true; //true means tile false means item;
	
	public boolean running = false;
	public static boolean paused = false;
	public static int xScroll = -192;
	public static int yScroll = -142;
	
	public static int tick = 0;

	private static long lastFrame;

	private static long getTime(){
		return System.currentTimeMillis();
	}
	
	public static double getDelta() {
        long currentTime = getTime();
        double delta = (double) (currentTime - lastFrame);
        lastFrame = getTime();
        return delta;
    }
	
	public void start() {
		running = true;
		new Thread(this).start();
	}
	
	public void stop() {
		running = false;
	}
	
	public static void setPaused(boolean pause){
		paused = pause;
	}
	
	public Editor() {
	}

	public static void init() {
		lastFrame = getTime();
		
		loader = new SpriteSheetLoader();
		screen = new Screen(WIDTH, HEIGHT);
		
		try {Write.loadTiles();} 
		catch (IOException e) {e.printStackTrace();}

		setPaused(true);
		
		camera = new Camera();
		tileInventory = new TileInventory();
		itemInventory = new ItemInventory();
		gui = new Gui();
		
		Menu.setMenu(Menu.SPLASH_SCREEN);
	}

	public static void Screenshot(){
		Date date = new Date();
	    SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd-hh-mm-ss");
		File output = new File("screenshots/" + ft.format(date) + ".png");
		
		try {
			ImageIO.write(image, "png", output);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Screenshot: " + ft.format(date) + ".png " + "has been saved.");
	}

	public void run() {
		long lastTime = System.nanoTime();
		double unprocessed = 0;
		double nsPerTick = 1000000000.0 / 60;
		int frames = 0;
		int ticks = 0;
		long lastTimer1 = System.currentTimeMillis();

		try {
			init();
		} catch (Exception e1) {System.out.println("Failed to Initilize");}

		while (running) {
			long now = System.nanoTime();
			unprocessed += (now - lastTime) / nsPerTick;
			lastTime = now;
			boolean shouldRender;
			if(Vsync)shouldRender = false;
			else shouldRender = true;
			
			while (unprocessed >= 1) {
				ticks++;
				tick();
				unprocessed -= 1;
				shouldRender = true;
			}

			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			if (shouldRender) {
				frames++;
				render();
			}

			if (System.currentTimeMillis() - lastTimer1 > 1000) {
				lastTimer1 += 1000;
				System.out.println(ticks + " ticks, " + frames + " fps");
				frames = 0;
				ticks = 0;
			}
		}
	}

	public void tick() {
		if(filename != null)frame.setTitle(NAME+" - "+filename+".png");
		else frame.setTitle(NAME);
		
		double delta = getDelta();
		
		xScroll = camera.cX - screen.w / 2;//some values to keep the camera looking at the player
		yScroll = camera.cY - (screen.h - 8) / 2;

		input.tick();
		
		if(paused == false){		
			camera.tick();
		}
		
		if(currInv)tileInventory.tick();
		else itemInventory.tick();
		
		for(int i = 0; i < Menu.menus.length; i++){
			if(Menu.menus[i].state)Menu.menus[i].tick(delta);
		}
		
		render();
		
		tick++;
		if(tick >= 9999999)tick = 0;
	}

	public void render() {
		BufferStrategy bs = getBufferStrategy();
		if (bs == null) {
			createBufferStrategy(3);
			requestFocus();
			return;
		}

		if(currLevel != null)currLevel.renderBackground(xScroll, yScroll, screen);
		if(currItemMap != null)currItemMap.render(xScroll, yScroll, screen);
		
		gui.render(0, 0, screen);
		if(currInv)tileInventory.render(0, 0, screen);	
		else itemInventory.render(0, 0, screen);
		
		//ABOUT
		Font.drawString("X: "+camera.cX+" , Y: "+camera.cY, 1, 1, -1, screen);

		for(int i = 0; i < Menu.menus.length; i++){
			if(Menu.menus[i].state == true){
				Menu.menus[i].render(0, 0, screen);
			}
		}	
		
		if(!hasFocus()){		
			requestFocusInWindow();
			if(tick/20 % 2 == 0)Font.drawString("CLICK TO FOCUS!", screen.w - 90, 0, -16777216, screen);
			else Font.drawString("CLICK TO FOCUS!", screen.w - 90, 0, -1, screen);
		}

		for (int y = 0; y < screen.h; y++) {
			for (int x = 0; x < screen.w; x++) {
				pixels[x + y * WIDTH] = screen.pixels[x + y * screen.w];
			}
		}
		
		//Drawing buffered image to screen.
		Graphics g = bs.getDrawGraphics();
		g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
		g.dispose();
		bs.show();
		
	}

	public static void main(String[] args) {	
		Editor game = new Editor();
		
		game.setPreferredSize(GAME_DIM);
		game.setMaximumSize(GAME_DIM);
		game.setMinimumSize(GAME_DIM);

		frame = new JFrame(NAME);
		frame.setIconImage(((ImageIcon) icon).getImage());
		frame.setLayout(new BorderLayout());
		frame.add(game, BorderLayout.CENTER);
		frame.pack();	
		frame.setVisible(true);
		frame.setResizable(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		game.start();
	}
}
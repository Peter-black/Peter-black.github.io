package com.Lpb.Level;

import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.Item;
import com.Lpb.Sprites.Sprite;

public class ItemMap {
	public int w;
	public int h;
	public Sprite levelSprite;
	
	public Item[] tiles;
	
	public ItemMap(int w, int h, Sprite levelSprite) {
		this.w = w;
		this.h = h;
		this.levelSprite = levelSprite;
		
		tiles = new Item[w * h];
		loadMap(0, 0, 0, 0, levelSprite);

	}
	
	public void render(int xScroll, int yScroll, Screen screen) {
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;

		int w = (screen.w + 15);
		int h = (screen.h + 15);
		
		screen.setOffs(xScroll, yScroll);

		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				if(getItem(x,y) != null)getItem(x,y).renderDropped(x*16, y*16, screen);
			}
		}
		screen.setOffs(0, 0);
	}
	
	public Item getItem(int x, int y) {
		if (x < 0 || y < 0 || x >= w || y >= h) return null;
		if(tiles[x + y * w] == null) return null;
		return tiles[x + y * w];
	}
	
	public boolean setItem(int x, int y, Item item) {
		if (x < 0 || y < 0 || x >= w || y >= h) return false;
		tiles[x + y * w] = item;
		return true;
	}

	public void loadMap(int x0, int y0, int x1, int y1, Sprite sprite) {
		for (int y = 0; y < sprite.h; y++) {
			for (int x = 0; x < sprite.w; x++) {
				for (int i = 0; i < Item.items.length; i++){
					if (sprite.pixels[x + y * sprite.w] == -i) {
						tiles[x + x1 + (y + y1) * w] = Item.items[i];
						break;
					}else tiles[x + x1 + (y + y1) * w] = null;
				}			
			}
		}
	}
}
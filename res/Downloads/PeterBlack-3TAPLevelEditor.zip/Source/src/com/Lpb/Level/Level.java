package com.Lpb.Level;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Tiles.Building;
import com.Lpb.Tiles.Tile;

public class Level {
	public int w;
	public int h;

	public int[] tiles;
	
	public Level(int w, int h, Sprite levelSprite) {
		this.w = w;
		this.h = h;

		tiles = new int[w * h];
		loadMap(0, 0, 0, 0, levelSprite);
	}
	
	public int[] getTiles(){
		return tiles;
	}

	public void renderBackground(int xScroll, int yScroll, Screen screen) {
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;

		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;
		
		screen.setOffs(xScroll, yScroll);

		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				if(getTile(x, y) == Tile.building)Tile.building.render(Building.xCoord , Building.yCoord, screen);
				else getTile(x,y).render(x, y, screen);
			}
		}
		screen.setOffs(0, 0);
	}

	public Tile getTile(int x, int y) {
		if (x < 0 || y < 0 || x >= w || y >= h) return Tile.noTile;
		if (tiles[x + y * w] >= Tile.tiles.size())return Tile.noTile;
		return Tile.tiles.get(tiles[x + y * w]);
	}
	
	public void setTile(int x, int y, Tile tile) {
		if(tile == null)return;
		if (x < 0 || y < 0 || x >= w || y >= h) return;
		tiles[x + y * w] = tile.id;
	}
	
	public void clearMap(){
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				tiles[x+ (y * w)] = 1;
			}
		}
	}

	public void loadMap(int x0, int y0, int x1, int y1, Sprite sprite) {
		for (int y = 0; y < sprite.h; y++) {
			for (int x = 0; x < sprite.w; x++) {
				for (int i = 0; i < Tile.tiles.size(); i++){
					if (sprite.pixels[x + y * sprite.w] == -i) {
						tiles[x + x1 + (y + y1) * w] = Tile.tiles.get(i).id;
						break;
					}else tiles[x + x1 + (y + y1) * w] = Tile.noTile.id;
				}
			}
		}
	}
}
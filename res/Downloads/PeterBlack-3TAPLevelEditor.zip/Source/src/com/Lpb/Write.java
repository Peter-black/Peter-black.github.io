package com.Lpb;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;

import com.Lpb.Tiles.Building;
import com.Lpb.Tiles.OverlayTile;
import com.Lpb.Tiles.ParticleTile;
import com.Lpb.Tiles.Tile;

public class Write {

	public Write(){
	}
	
	public static void save() throws FileNotFoundException{
		//MAP IMAGE
		File output = new File("save/level/" + Editor.filename + ".png");
		BufferedImage image = new BufferedImage(Editor.currLevel.w*2, Editor.currLevel.h, BufferedImage.TYPE_INT_ARGB);
		
		for (int y = 0; y < Editor.currLevel.h; y++) {
			for (int x = 0; x < Editor.currLevel.w; x++) {
				image.setRGB(x, y, -Editor.currLevel.tiles[x+ (y * Editor.currLevel.w)]);
			}
		}
		for (int y = 0; y < Editor.currItemMap.h; y++) {
			for (int x = Editor.currItemMap.w; x < Editor.currItemMap.w*2; x++) {
				image.setRGB(x, y, -Editor.currItemMap.tiles[(x-Editor.currItemMap.w)+ ((y) * Editor.currItemMap.w)].id);
			}
		}
		
		try {
			ImageIO.write(image, "png", output);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//TILE DETAILS
		PrintWriter save = new PrintWriter("save/tileDetails.txt");

	    save.println("\n");
	    save.println(Tile.tiles.size());
	    for(int i = 0; i < Tile.tiles.size(); i++){
	    	save.print(Tile.tiles.get(i).id +",");
	    	save.print(Tile.tiles.get(i).getClass().getName().substring(14) +",");//Gets the class and cuts off the com.lpb.Tiles.
	    	save.print(Tile.tiles.get(i).collide +",");
	    	save.print(Tile.tiles.get(i).color +",");
	    	save.print(Tile.tiles.get(i).name + "\n");
	    	save.println("\n");
	    }
	    save.println("\n");
	    
	    save.close(); 
	}
	
	public static void loadTiles() throws IOException{
		BufferedReader File = new BufferedReader(new FileReader("save/tileDetails.txt"));

		File.readLine(); 
	    
	    File.readLine();
	    int numTiles = Integer.parseInt(File.readLine());
	    
	    int id;
	    int type;
	    boolean collide;
	    int color;
	    String name;

		for(int i = 0; i < numTiles; i++){
			String dataRow = File.readLine();   
			  
			String[] dataArray = dataRow.split(",");
			id = Integer.parseInt(dataArray[0]);
			if(id < Tile.tiles.size()){dataRow = File.readLine();dataRow = File.readLine();continue;}
			if(dataArray[1].equals("Tile"))type = Tile.NORMAL;
			else if(dataArray[1].equals("OverlayTile"))type = Tile.OVERLAY;
			else if(dataArray[1].equals("ParticleTile"))type = Tile.PARTICLE;
			else if(dataArray[1].equals("Building"))type = Tile.BUILDING;
			else type = Tile.NORMAL;
			if(dataArray[2].equals("true"))collide = true;
			else collide = false;
			color = Integer.parseInt(dataArray[3]);
			name = dataArray[4];	   
			@SuppressWarnings("unused")
			Tile t;
			if(type == Tile.NORMAL)t = new Tile(id, collide, color, name);
			else if(type == Tile.OVERLAY)t = new OverlayTile(id, collide, color, name);
			else if(type == Tile.PARTICLE)t = new ParticleTile(id, collide, color, name);
			else if(type == Tile.BUILDING)t = new Building(id, collide, color, name);
			
			dataRow = File.readLine();
			dataRow = File.readLine();
		}
		
		File.close();
	}
}

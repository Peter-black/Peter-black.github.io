package com.Lpb.Gui;

import com.Lpb.Editor;
import com.Lpb.Graphics.Screen;
import com.Lpb.Inventory.ItemInventory;
import com.Lpb.Inventory.TileInventory;
import com.Lpb.Sprites.Sprite;

public class Gui {
	Sprite look;
	
	public static Gui activeSlot = new ActiveSlot();
	public static Gui slot = new Slot();

	public Gui(){
	}
	
	public void render(int xPos, int yPos, Screen screen) {	
		if(Editor.currInv){
			for(int i = 0; i < TileInventory.maxTiles; i++)slot.render(screen.w - 80, (screen.h-32)-(i*24)-0, screen);
			activeSlot.render(screen.w - 80, (screen.h-32)-(TileInventory.selectedTile*24)-0, screen);		
		}else{
			for(int i = 0; i < ItemInventory.maxItems; i++)slot.render(screen.w - 80, (screen.h-16)-(i*24)-0, screen);
			activeSlot.render(screen.w - 80, (screen.h-16)-(ItemInventory.selectedItem*24)-0, screen);	
		}
	}
}

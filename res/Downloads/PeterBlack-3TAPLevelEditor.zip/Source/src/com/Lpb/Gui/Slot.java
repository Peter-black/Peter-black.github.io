package com.Lpb.Gui;

import com.Lpb.Editor;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class Slot extends Gui{

	public Slot() {
		look = Sprites.guiSlots[1][2];
	}
	
	public void render(int x, int y, Screen screen) {
		if(Editor.currInv)screen.renderSprite(x, y, look);
		else screen.renderSprite(x, y, look, 0, 2);
	}
}

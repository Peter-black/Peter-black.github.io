package com.Lpb;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import com.Lpb.Inventory.Item;
import com.Lpb.Inventory.ItemInventory;
import com.Lpb.Inventory.TileInventory;
import com.Lpb.Menu.Menu;
import com.Lpb.Menu.TileMenu;
import com.Lpb.Tiles.Tile;

public class InputHandler implements KeyListener, MouseWheelListener, MouseListener, MouseMotionListener{
	
	public class Key{	
		public boolean state;
		public boolean clicked;
		
		public Key(boolean state, boolean clicked){
			this.state = state;
			this.clicked = clicked;
		}
	}
	
	public Key up = new Key(false, false);
	public Key down = new Key(false, false);
	public Key left = new Key(false, false);
	public Key right = new Key(false, false);
	public Key shift = new Key(false, false);

	public Key one = new Key(false, false);
	public Key two = new Key(false, false);
	public Key three = new Key(false, false);
	
	public Key back = new Key(false, false);
	public Key use = new Key(false, false);
	
	public Key tiles = new Key(false, false);
	public Key inv = new Key(false, false);
	
	public Key esc = new Key(false, false);
	public Key screenshot = new Key(false, false);
	
	public boolean 
	inButton = false,
	mouseClicked = false;
	
	public int notches;
	public int mouseButton;
	
	public InputHandler(Editor game){
		game.addKeyListener(this);
		game.addMouseWheelListener(this);
		game.addMouseListener(this);
		game.addMouseMotionListener(this);
	}
	
	public void tick(){
		//GENERAL INPUT
		if(!Editor.paused){
			
			Editor.camera.setDX(0);
			Editor.camera.setDY(0);
			
			if(right.state)Editor.camera.setDX(2);
			if(left.state)Editor.camera.setDX(-1.5);
			if(down.state)Editor.camera.setDY(2);	
			if(up.state)Editor.camera.setDY(-1.5);	
			if(shift.state && right.state)Editor.camera.setDX(1);		
			if(shift.state && left.state)Editor.camera.setDX(-0.5);
			if(shift.state && down.state)Editor.camera.setDY(1);
			if(shift.state && up.state)Editor.camera.setDY(-0.5);	
		
			if(one.state)TileInventory.selectedTile = 0;
			if(two.state)TileInventory.selectedTile = 1;
			if(three.state)TileInventory.selectedTile = 2;
			
			if(tiles.state && !tiles.clicked){
				if(Menu.TILE_MENU.state){Editor.setPaused(false);Menu.setMenu(Menu.NO_MENU);}
				else{
					Editor.setPaused(true);
					Menu.setMenu(Menu.TILE_MENU);
				}
				tiles.clicked = true;
			}
			
			if(inv.state && !inv.clicked){
				if(Editor.currInv)Editor.currInv = false;
				else Editor.currInv = true;
				inv.clicked = true;
			}
			
			if(esc.state && !esc.clicked){
					if(Menu.PAUSE_MENU.state){Editor.setPaused(false);Menu.setMenu(Menu.NO_MENU);}
					else{
						Editor.setPaused(true);
						Menu.setMenu(Menu.PAUSE_MENU); 
					}
				esc.clicked = true;
			} 	
		}
	
		//MENU INPUT
		if(Menu.currMenu != Menu.NO_MENU){
			
			if(Menu.currMenu == Menu.PAUSE_MENU || Menu.currMenu == Menu.TILE_MENU){
				if(esc.state && !esc.clicked){
					Editor.setPaused(false);
					Menu.setMenu(Menu.NO_MENU);
					esc.clicked = true;
				} 
			}else if(Menu.currMenu != Menu.TITLE_MENU){
				if(esc.state && !esc.clicked){
					Menu.setMenu(Menu.parentMenu);
					esc.clicked = true;
				} 
			}
			
			if(Menu.currMenu == Menu.PAUSE_MENU){
				if(esc.state && !esc.clicked){
					Editor.setPaused(false);
					Menu.setMenu(Menu.NO_MENU);
					esc.clicked = true;
				} 
			}
			
			if(Menu.currMenu == Menu.TILE_MENU){
				if(tiles.state && !tiles.clicked){
					Editor.setPaused(false);
					Menu.setMenu(Menu.NO_MENU);
					tiles.clicked = true;
				}
			}
				
			if(down.state && !down.clicked){Menu.currMenu.selectedItem++; down.clicked = true;}
			if(up.state && !up.clicked){Menu.currMenu.selectedItem--; up.clicked = true;}
			
			if(use.state && !use.clicked || mouseClicked){
				Menu.currMenu.chooseOption(Menu.currMenu.selectedItem);
				
				use.clicked = true;
				mouseClicked = false;
			}
		}
		
		if(screenshot.state && !screenshot.clicked){Editor.Screenshot();screenshot.clicked = true;}
		
	}
	
	public void toggle(KeyEvent ke,boolean pressed){
		int keyCode = ke.getKeyCode();
		
		if(keyCode == KeyEvent.VK_UP) up.state = pressed;
		if(keyCode == KeyEvent.VK_DOWN) down.state = pressed;
		if(keyCode == KeyEvent.VK_LEFT) left.state = pressed;
		if(keyCode == KeyEvent.VK_RIGHT) right.state = pressed;
		if(keyCode == KeyEvent.VK_W) up.state = pressed;
		if(keyCode == KeyEvent.VK_S) down.state = pressed;
		if(keyCode == KeyEvent.VK_A) left.state = pressed;
		if(keyCode == KeyEvent.VK_D) right.state = pressed;
		if(keyCode == KeyEvent.VK_SHIFT) shift.state = pressed;
		
		if(keyCode == KeyEvent.VK_1) one.state = pressed;
		if(keyCode == KeyEvent.VK_2) two.state = pressed;
		if(keyCode == KeyEvent.VK_3) three.state = pressed;

		if(keyCode == KeyEvent.VK_BACK_SPACE) back.state = pressed;
		if(keyCode == KeyEvent.VK_E) use.state = pressed;
		if(keyCode == KeyEvent.VK_ENTER) use.state = pressed;
		
		if(keyCode == KeyEvent.VK_Q) tiles.state = pressed; 
		if(keyCode == KeyEvent.VK_I) inv.state = pressed; 
		
		if(keyCode == KeyEvent.VK_ESCAPE) esc.state = pressed;
		if(keyCode == KeyEvent.VK_F12) screenshot.state = pressed; 
	}
	
	public void keyTyped(KeyEvent ke) {

	}

	public void keyPressed(KeyEvent ke) {
		toggle(ke,true);
	}
	
	public void keyReleased(KeyEvent e) {
		toggle(e,false);
		if(e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) up.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) down.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_E || e.getKeyCode() == KeyEvent.VK_ENTER) use.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_Q) tiles.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_I) inv.clicked = false; 
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE) esc.clicked = false;
		if(e.getKeyCode() == KeyEvent.VK_F12) screenshot.clicked = false;
	}

	public void mouseWheelMoved(MouseWheelEvent e) {
			notches = e.getWheelRotation();
			
			if(Menu.TITLE_MENU.state || Menu.PAUSE_MENU.state || Menu.TILE_MENU.state){
			      if (notches < 0) {
			    	  if(Menu.currMenu.selectedItem>0)Menu.currMenu.selectedItem--;
			    	  else Menu.currMenu.selectedItem = Menu.currMenu.maxItems-1;
			      } else {
			    	  if(Menu.currMenu.selectedItem<Menu.currMenu.maxItems-1)Menu.currMenu.selectedItem++;
			    	  else Menu.currMenu.selectedItem = 0;
			      }
			}
			if(!Editor.paused){
				if (notches < 0) {
					if(Editor.currInv){
						if(TileInventory.selectedTile<TileInventory.maxTiles-1)TileInventory.selectedTile++;
						else TileInventory.selectedTile = 0;
					}else{
						if(ItemInventory.selectedItem<ItemInventory.maxItems-1)ItemInventory.selectedItem++;
						else ItemInventory.selectedItem = 0;
					}
			      } else {
			    	if(Editor.currInv){
			    		if(TileInventory.selectedTile>0)TileInventory.selectedTile--;
			    		else TileInventory.selectedTile = TileInventory.maxTiles-1;
			    	}else{
			    		if(ItemInventory.selectedItem>0)ItemInventory.selectedItem--;
			    		else ItemInventory.selectedItem = ItemInventory.maxItems-1;
			    	}
			      }
			}
	}

	@Override
	public void mouseClicked(MouseEvent me) {
		
	}

	@Override
	public void mouseEntered(MouseEvent me) {
		
	}

	@Override
	public void mouseExited(MouseEvent me) {
		
	}

	@Override
	public void mousePressed(MouseEvent me) {
		int mouseX = me.getX();
		int mouseY = me.getY();
		
		inButton = false;
		
		for(int i = 0; i < Menu.currMenu.maxItems; i ++){
				if(mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) >= Editor.HEIGHT - (Menu.currMenu.maxItems*15) - 2 + i * 15 &&
				   mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) <= Editor.HEIGHT - (Menu.currMenu.maxItems*15) + 12 + i * 15){
									
				if(mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) >= 0 && 
				   mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) <= 125){
					Menu.currMenu.selectedItem = i;
					inButton = true;
				}
				}
		}
		if(inButton){
			mouseClicked = true;
		}
		
		if(!Editor.paused){
			int x=((mouseX/2)+Editor.xScroll)/16;
			int y=((mouseY/2)+Editor.yScroll)/16;
			if(Editor.currInv)Editor.currLevel.setTile(x, y, TileInventory.inventory[TileInventory.selectedTile]);	
			else{ 
				if(me.getButton() == 1){mouseButton = 1; Editor.currItemMap.setItem(x, y, ItemInventory.inventory[ItemInventory.selectedItem]);}
				if(me.getButton() == 3){mouseButton = 3; Editor.currItemMap.setItem(x, y, Item.none);}
				}
		}
		
		if(Menu.currMenu == Menu.TILE_MENU){
			for(int i = 0; i < Tile.tiles.size(); i++){						
				if(mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) >= 49 + (i/TileMenu.rowSize)*20 &&
				   mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) <= 68 + (i/TileMenu.rowSize)*20){							
				if(mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) >= 159 + (i%TileMenu.rowSize)*20 && 
				   mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) <= 178 + (i%TileMenu.rowSize)*20){
					TileInventory.addTile(Tile.tiles.get(i));
				}
				}
			}	
		}
	}

	@Override
	public void mouseReleased(MouseEvent me) {
		mouseClicked = false;
		use.clicked = false; 
	}

	@Override
	public void mouseDragged(MouseEvent me) {
		int mouseX = me.getX();
		int mouseY = me.getY();
		
		int x=((mouseX/2)+Editor.xScroll)/16;
		int y=((mouseY/2)+Editor.yScroll)/16;
		if(!Editor.paused){
			if(Editor.currInv)Editor.currLevel.setTile(x, y, TileInventory.inventory[TileInventory.selectedTile]);	
			else {
				if(mouseButton == 1) Editor.currItemMap.setItem(x, y, ItemInventory.inventory[ItemInventory.selectedItem]);
				if(mouseButton == 3) Editor.currItemMap.setItem(x, y, Item.none);
			}
		}
	}

	@Override
	public void mouseMoved(MouseEvent me) {
		int mouseX = me.getX();
		int mouseY = me.getY();
		
		inButton = false;
		
		if(Menu.currMenu != null){
			for(int i = 0; i < Menu.currMenu.maxItems; i ++){						
				if(mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) >= Editor.HEIGHT - (Menu.currMenu.maxItems*15) - 2 + i * 15 &&
				   mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) <= Editor.HEIGHT - (Menu.currMenu.maxItems*15) + 12 + i * 15){							
				if(mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) >= 0 && 
				   mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) <= 125){
					Menu.currMenu.selectedItem = i;
					inButton = true;
				}
				}
			}	
		}
		if(Menu.currMenu == Menu.TILE_MENU){
			for(int i = 0; i < Tile.tiles.size(); i++){						
				if(mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) >= 49 + (i/TileMenu.rowSize)*20 &&
				   mouseY/(double)(Editor.frame.getHeight()/Editor.screen.h) <= 68 + (i/TileMenu.rowSize)*20){							
				if(mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) >= 159 + (i%TileMenu.rowSize)*20 && 
				   mouseX/(double)(Editor.frame.getWidth()/Editor.screen.w) <= 178 + (i%TileMenu.rowSize)*20){
					TileMenu.selectedTile = i;
				}
				}
			}	
		}	
	}
}
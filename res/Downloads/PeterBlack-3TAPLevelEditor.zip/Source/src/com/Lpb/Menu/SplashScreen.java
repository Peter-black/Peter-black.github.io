package com.Lpb.Menu;

import com.Lpb.Sprites.Sprites;

public class SplashScreen extends Menu {
	
	private boolean started = false;
	private long startTime;
	
	public SplashScreen(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title);

		background = Sprites.splash[0][0];
	}
	
	public void tick(double delta){
		if(!started){
			startTime = System.currentTimeMillis();
			started = true;
		}
		
		if((startTime + 1500) - System.currentTimeMillis() <= 0){
			changeMenu(TITLE_MENU);
		}
	}
}
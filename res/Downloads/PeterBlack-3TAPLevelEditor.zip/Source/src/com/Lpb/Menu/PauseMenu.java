package com.Lpb.Menu;

import com.Lpb.Editor;
import com.Lpb.Write;
import com.Lpb.Sprites.Sprites;

public class PauseMenu extends Menu {

	public PauseMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: Editor.setPaused(false);
				setMenu(NO_MENU);
				break;
				
		case 1: break;
		
		case 2: try {Write.save();} 
				catch (Exception e2) {
				e2.printStackTrace();}

				Editor.setPaused(false);
				setMenu(NO_MENU);
				break;
				
				
		case 3: try {Write.save();} 
				catch (Exception e) {
				e.printStackTrace();
				}
				
				setMenu(TITLE_MENU);
				break;
				
		case 4: Editor.filename = null;
				setMenu(TITLE_MENU);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "Continue";
		options[1] = "Tools";
		options[2] = "Save";
		options[3] = "Save & Exit";
		options[4] = "Exit to menu";
	}
}
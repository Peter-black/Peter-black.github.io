package com.Lpb.Menu;

import com.Lpb.Editor;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;
import com.Lpb.Tiles.Tile;

public class TileMenu extends Menu {
	
	public static int rowSize = 12;
	public static int selectedTile;
	String[] quests;

	public TileMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title); 

		background = Sprites.menuBg[0][0];
	}

	public void render(int x, int y, Screen screen){
		super.render(x, y, screen);
		
		for(int i = 0; i < Tile.tiles.size(); i++){
			if(selectedTile == i)screen.renderRect(159 + (i%rowSize)*20, 49 + (i/rowSize)*20, 18, 18, -1677306);
			else screen.renderRect(159 + (i%rowSize)*20, 49 + (i/rowSize)*20, 18, 18, -16738125);
			if(Tile.tiles.get(i) == Tile.building)screen.renderSprite(160 + (i%rowSize)*20, 50 + (i/rowSize)*20, 160 + (i%rowSize)*20, 50 + (i/rowSize)*20, 175 + (i%rowSize)*20, 65 + (i/rowSize)*20, Tile.tiles.get(i).tile);
			else screen.renderSprite(160 + (i%rowSize)*20, 50 + (i/rowSize)*20, Tile.tiles.get(i).tile);
		}
	}
	
	public void chooseOption(int option){
		switch(option){
		case 0: AddTileMenu.addTileMenu();
				break;
				
		case 1: Tile.removeTile();
				break;
		
		case 2: Editor.setPaused(false);
				setMenu(NO_MENU);
				break;	
		}	
	}
	
	protected void setOptions(){
		options[0] = "Add New Tile";
		options[1] = "Remove Tile";
		options[2] = "Return";
	}
	
}
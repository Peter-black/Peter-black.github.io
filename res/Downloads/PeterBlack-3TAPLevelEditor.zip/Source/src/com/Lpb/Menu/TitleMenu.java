package com.Lpb.Menu;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.Lpb.Editor;
import com.Lpb.Level.ItemMap;
import com.Lpb.Level.Level;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class TitleMenu extends Menu {
	
	public static String mapName;
	public static int mapWidth, mapHeight;
	
	public TitleMenu(int id, boolean state, int selectedItem, int maxItems, String title) {
		super(id, state, selectedItem, maxItems, title);

		background = Sprites.menuBg[0][0];
	}

	public void chooseOption(int option){		
		switch(option){
		case 0:	newLevelPrompt();
				break;
		
		case 1:	openLevelPrompt();
				break;
		
		case 2:	setMenu(ABOUT_MENU);
				break;
		
		case 3: System.exit(0);
				break;
		}
	}
	
	protected void setOptions(){
		options[0] = "New Map";
		options[1] = "Open Map";
		options[2] = "About";
		options[3] = "Exit";
	}
	
	public void newLevelPrompt(){
		final JDialog dialog = new JDialog(Editor.frame, "New Map");
		dialog.setIconImage(Editor.frame.getIconImage());
		dialog.setLayout(new BorderLayout());
		
		JPanel contentPane = new JPanel();
		contentPane.setPreferredSize(new Dimension(300, 200));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.PAGE_AXIS));
		
		dialog.setContentPane(contentPane);
		
		JPanel namePanel = new JPanel();
		JLabel nameLabel = new JLabel("Map Name");
		final JTextField nameText = new JTextField(20);
		namePanel.add(nameLabel);
		namePanel.add(nameText);
		
		JPanel widthPanel = new JPanel();
		JLabel widthLabel = new JLabel("Width");
		final JTextField widthText = new JTextField("15",5);
		widthPanel.add(widthLabel);
		widthPanel.add(widthText);
		
		JPanel heightPanel = new JPanel();
		JLabel heightLabel = new JLabel("Height");
		final JTextField heightText = new JTextField("15",5);
		heightPanel.add(heightLabel);
		heightPanel.add(heightText);
		
		JPanel buttonPanel = new JPanel();
		JButton addButton = new JButton("Add");
		JButton cancelButton = new JButton("Cancel");
		buttonPanel.add(addButton);
		buttonPanel.add(cancelButton);
		
		contentPane.add(namePanel);
		contentPane.add(widthPanel);
		contentPane.add(heightPanel);
		contentPane.add(buttonPanel);

		dialog.pack();	
		dialog.setVisible(true);
		dialog.setResizable(false);
		dialog.setLocationRelativeTo(Editor.frame);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		
		//ACTION LISTENERS
	
		addButton.addActionListener(new ActionListener() {
	        public void actionPerformed( ActionEvent e ) {
	        	if(!nameText.getText().equals(""))mapName = nameText.getText();
	        	else mapName = "newMap";
	        	if(!widthText.getText().replaceAll("[a-zA-Z]", "").equals("")){
	        		mapWidth = Integer.parseInt(widthText.getText().replaceAll("[a-zA-Z]", ""));
	        	}else mapWidth = 1;
	        	if(!heightText.getText().replaceAll("[a-zA-Z]", "").equals("")){
	        		mapHeight = Integer.parseInt(heightText.getText().replaceAll("[a-zA-Z]", ""));
	        	}else mapHeight = 1;

	        	Sprite[][] mapSprite = new Sprite[2][1];
	        	mapSprite[0][0] = new Sprite(mapWidth, mapHeight);
	        	mapSprite[1][0] = new Sprite(mapWidth, mapHeight);
	        	Editor.currLevel = new Level(mapWidth, mapHeight, mapSprite[0][0]);
	        	Editor.currItemMap = new ItemMap(mapWidth, mapHeight, mapSprite[1][0]);
	        	Editor.currLevel.clearMap();    	
	        	Editor.filename = mapName;

				Editor.setPaused(false);
				setMenu(NO_MENU);
	        	
	        	dialog.dispose();
	        }
	    });
		
		cancelButton.addActionListener(new ActionListener() {
	        public void actionPerformed( ActionEvent e ) {
	            dialog.dispose();
	        }
	    });
	}
	
	public void openLevelPrompt(){
		final JFileChooser fc = new JFileChooser();
		int returnVal = fc.showOpenDialog(Editor.frame);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            BufferedImage img = null;
            try {
                img = ImageIO.read(file);
            } catch (IOException e){e.printStackTrace();}
            
            //MANUALLY CUT TILES;
            int w = img.getWidth()/2;
            int h = img.getHeight();
            	
    		int xTiles = (img.getWidth()) / w;
    		int yTiles = (img.getHeight()) / h;

    		Sprite[][] result = new Sprite[xTiles][yTiles];

    		for (int x = 0; x < xTiles; x++) {
    			for (int y = 0; y < yTiles; y++) {
    				result[x][y] = new Sprite(w, h);
    				img.getRGB(x * w, y * h, w, h, result[x][y].pixels, 0, w);
    			}
    		}

            Editor.currLevel = new Level(w, h, result[0][0]);  
            Editor.currItemMap = new ItemMap(w, h, result[1][0]); 
            Editor.filename = file.getName().replace(".png", "");

			Editor.setPaused(false);
			setMenu(NO_MENU);
        } else {
           return;
        }

	}
}
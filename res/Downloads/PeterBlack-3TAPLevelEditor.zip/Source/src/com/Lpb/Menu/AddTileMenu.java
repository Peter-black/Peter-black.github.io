package com.Lpb.Menu;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.Lpb.Editor;
import com.Lpb.Tiles.Tile;

public class AddTileMenu extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private static String name;
	private static String type;
	private static boolean collide;
	private static int color;

	public AddTileMenu(){		
	}
	
	public static void addTileMenu(){
		final JDialog dialog = new JDialog(Editor.frame, "Add new Tile");
		dialog.setIconImage(Editor.frame.getIconImage());
		dialog.setLayout(new BorderLayout());
		
		JPanel contentPane = new JPanel();
		contentPane.setPreferredSize(new Dimension(500, 300));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.PAGE_AXIS));
		
		dialog.setContentPane(contentPane);
		
		JPanel namePanel = new JPanel();
		JLabel nameLabel = new JLabel("Tile Name");
		final JTextField nameText = new JTextField(20);
		namePanel.add(nameLabel);
		namePanel.add(nameText);
		
		JPanel typePanel = new JPanel();
		JLabel typeLabel = new JLabel("Type");
		String[] typeStrings = {"Normal", "Overlay", "Particle", "Building"};
		@SuppressWarnings({ "rawtypes", "unchecked" })
		final JComboBox typeList = new JComboBox(typeStrings);
		typeList.setSelectedIndex(0);
		typePanel.add(typeLabel);
		typePanel.add(typeList);
		
		JPanel collisionPanel = new JPanel();
		JLabel collisionLabel = new JLabel("Collision");
		final JCheckBox collisionCheck = new JCheckBox();
		collisionPanel.add(collisionLabel);
		collisionPanel.add(collisionCheck);
		
		JPanel colorPanel = new JPanel();
		JLabel colorLabel = new JLabel("Particle Colour");
		final JTextField colorText = new JTextField(15);
		colorPanel.add(colorLabel);
		colorPanel.add(colorText);
		
		JPanel buttonPanel = new JPanel();
		JButton addButton = new JButton("Add");
		JButton cancelButton = new JButton("Cancel");
		buttonPanel.add(addButton);
		buttonPanel.add(cancelButton);
		
		contentPane.add(namePanel);
		contentPane.add(typePanel);
		contentPane.add(collisionPanel);
		contentPane.add(colorPanel);
		contentPane.add(buttonPanel);

		dialog.pack();	
		dialog.setVisible(true);
		dialog.setResizable(false);
		dialog.setLocationRelativeTo(Editor.frame);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		
		//ACTION LISTENERS
		collisionCheck.addItemListener(new ItemListener() {
			  @Override
		      public void itemStateChanged(ItemEvent e) {
				  if (e.getStateChange() == ItemEvent.SELECTED)collide = true;
				  if (e.getStateChange() == ItemEvent.DESELECTED)collide = false;
			  }
			});
		
		addButton.addActionListener(new ActionListener() {
	        public void actionPerformed( ActionEvent e ) {
	        	if(!nameText.getText().equals(""))name = nameText.getText();
	        	else name = "newTile";
	        	type = typeList.getSelectedItem().toString();
	        	if(!colorText.getText().replaceAll("[a-zA-Z]", "").equals("")){
	        		color = Integer.parseInt(colorText.getText().replaceAll("[a-zA-Z]", ""));
	        	}
	        	else color = -1;
	        	if(type.equals("Normal"))Tile.addTile(collide, color, name, Tile.NORMAL);
	        	if(type.equals("Overlay"))Tile.addTile(collide, color, name, Tile.OVERLAY);
	        	if(type.equals("Particle"))Tile.addTile(collide, color, name, Tile.PARTICLE);
	        	if(type.equals("Building"))Tile.addTile(collide, color, name, Tile.BUILDING);
	        	dialog.dispose();
	        }
	    });
		
		cancelButton.addActionListener(new ActionListener() {
	        public void actionPerformed( ActionEvent e ) {
	            dialog.dispose();
	        }
	    });
		
	}
}

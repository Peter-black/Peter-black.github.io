package com.Lpb.Menu;

import com.Lpb.Editor;
import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;

public class Menu {	
	public final int id;
	public boolean state;
	public int selectedItem;
	public final int maxItems;
	public final String TITLE;
	
	public static Menu currMenu;
	public static Menu parentMenu;

	public static String[] options = new String[10];
	
	public static int scroll = 0;
	public static boolean scrollLockUp, scrollLockDown;
	
	private static boolean initLoad = true;
	private static boolean animate = false, animDir;
	private static int animX;
	private static boolean menuDue = false;
	private static Menu setMenu;
	
	Sprite background;
	
	public static Menu[] menus = new Menu[6];
	
	public final static Menu
	NO_MENU = new Menu(0,false,0,0,""),
	TITLE_MENU = new TitleMenu(1 , false, 0, 4, "3TAP LEVEL EDITOR"),
	ABOUT_MENU = new AboutMenu(2 , false, 0, 1, "ABOUT"),
	PAUSE_MENU = new PauseMenu(3 , false, 0, 5, "PAUSED"),	
	TILE_MENU = new TileMenu(4, false, 0, 3, "TILE PICKER"),
	SPLASH_SCREEN = new SplashScreen(5 , false, 0, 0, "");

	public Menu(int id, boolean state, int selectedItem, int maxItems, String title){
		this.id = id;
		this.state = state;
		this.selectedItem = selectedItem;
		this.maxItems = maxItems;	
		this.TITLE = title;
		
		menus[id] = this;
	}
	
	public void tick(double delta){
		if(selectedItem > maxItems-1)selectedItem = 0;
		if(selectedItem < 0) selectedItem = maxItems-1;
		
		if(animate)animate(animDir, 17);
		
		if(!animate && menuDue){
			changeMenu(setMenu);
			if(setMenu == NO_MENU){
				setMenu = null;
				menuDue = false;
				return;
			}
			setMenu = null;
			menuDue = false;
			animate = true;
			animDir = true;
		}
	}
	
	private void animate(boolean dir, double delta){
		if(dir){
			animX -= delta;
			if(animX <= 0){
				animate = false;
			}
		}
		if(!dir){
			animX += delta;
			if(animX >= 110){
				animate = false;
			}
		}
	}
	
	public void render(int x, int y, Screen screen) {			
		screen.renderSprite(x, y, background);
		
		Font.drawString(TITLE, Editor.WIDTH - (TITLE.length()*12) - 12, 10, -16738125, Font.MENU_FONT, screen);
		
		for(int i = 0; i < maxItems; i++){
			if(selectedItem == i)Font.drawString(options[i] , x + 105 - options[i].length()*6 - animX, y + Editor.HEIGHT - (maxItems*15) + i * 15, -8073241, screen);
			else Font.drawString(options[i] , x + 110 - options[i].length()*6 - animX, y + Editor.HEIGHT - (maxItems*15) + i * 15, -16738125, screen);
		}	
	}
	
	public void chooseOption(int option){
	}
	
	protected void setOptions(){
	}
	
	public static void setMenu(Menu menu){
		if(initLoad){ changeMenu(menu); initLoad = false;}
		
		if(menu == PAUSE_MENU || menu == TILE_MENU)changeMenu(menu);
		
		animate = true;
		animDir = false;
		menuDue = true;
		setMenu = menu;
	}
	
	protected static void changeMenu(Menu menu){	
		if(menu == TITLE_MENU || menu == PAUSE_MENU){
			parentMenu = menu;
		}
		currMenu = menu;
		
		closeAll(); 
		
		scroll = 0;
	
		if(menu == NO_MENU)return;
		
		for(int i = 0; i < menus.length; i++){
			if(menus[i] == menu){
				menus[i].state = true;
				menus[i].setOptions();
			}
		}
	}
	
	public static Menu getMenu(){
		return currMenu;
	}
	
	public static void closeAll(){
		for(int i = 0; i < menus.length; i++){
			menus[i].state = false;
		}
	}
}
package com.Lpb.Geom;

public class Circle {
	
    public int x,y,r;
    
    public int[] area;
    
    public Circle(int x , int y, int r){
        this.x = x;
        this.y = y;
        this.r = r;
        
        area = new int[(int)(Math.PI*(r*r))];
    }
    
    public boolean intersects(Rectangle rect){
    	int Left = x - r;
		int Right = Left + r * 2;
		int Top = y - r;
		int Bottom = Top + r * 2;
		
		for (int j = Top; j <= Bottom; ++j){
		for (int i = rect.x; i< rect.x+rect.w; i++){
		for (int k = Left; k <= Right; ++k){
		for (int o = rect.y; o< rect.y+rect.h; o++){
			
			double dist = Math.pow(x - k, 2) + Math.pow(y - j, 2);
		    if (dist <= Math.pow(r, 2)){
		    	
		        if(j == i && k == o)return true;
		    }
		}}
		}}
		
		return false;
    }
    
    public boolean intersects(Circle circ){
    	int Left = x - r;
		int Right = Left + r * 2;
		int Top = y - r;
		int Bottom = Top + r * 2;
		
		int circLeft = circ.x - circ.r;
		int circRight = circLeft + circ.r * 2;
		int circTop = circ.y - circ.r;
		int circBottom = circTop + circ.r * 2;
		
		for (int j = Top; j <= Bottom; ++j){
		for (int i = circTop; i <= circBottom; ++i){
		for (int k = Left; k <= Right; ++k){
		for (int o = circLeft; o <= circRight; ++o){
					
			double dist = Math.pow(x - k, 2) + Math.pow(y - j, 2);
			double circdist = Math.pow(circ.x - o, 2) + Math.pow(circ.y - i, 2);
			
		    if (dist <= Math.pow(r, 2) && circdist <= Math.pow(circ.r, 2)){
		    	if(j == i && k == o)return true;
		    }
		}}
		}}
		
		return false;
    }
    
    public int getArea(){
    	return area.length;
    }
    
    public int getPerimeter(){
    	return (int)(2*Math.PI*r);
    }
}
package com.Lpb.Tiles;

import java.util.ArrayList;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Tile {
	
	public final static int NORMAL = 0,
							OVERLAY = 1,
							PARTICLE = 2,
							BUILDING = 3;
	
	public final int id;
	public final boolean collide;
	public final int color;
	public final String name;
	
	public Sprite tile;

	public static ArrayList<Tile> tiles = new ArrayList<Tile>();

	public static Tile noTile = new Tile(0, false, -16777216, "none");
	public static Tile grassTile = new Tile(1, false, -16759296, "Grass");
	public static Tile flowergrassTile = new Tile(2, false, -16759296, "Daisy");
	public static Tile longgrassTile = new Tile(3, false, -16759296, "Weed");
	public static Tile rockTile = new Tile(4, true, -12171706, "Rock");
	public static Tile dirtTile = new OverlayTile(5, false, -11524096, "Dirt");
	public static Tile dirtOverlay = new Tile(6, false, -11524096, "Dirt");
	public static Tile fireTile = new ParticleTile(7, false, -16777216, "Fire");
	public static Tile building = new Building(8, true, -32768, "Build");

	public Tile(int id, boolean collide, int color, String name) {
		this.id = id;
		this.collide = collide;
		this.color = color;
		this.name = name;
		int x = id%16;
		int y = (id-x)/16;
		this.tile = Sprites.terrain[x][y];
		tiles.add(this);
	}
	
	@SuppressWarnings("unused")
	public static void addTile(boolean collide, int color, String name, int type){
		if(type == NORMAL){Tile t = new Tile(tiles.size(), collide, color, name);return;}
		else if(type == OVERLAY){Tile t = new OverlayTile(tiles.size(), collide, color, name);return;}
		else if(type == PARTICLE){Tile t = new ParticleTile(tiles.size(), collide, color, name);return;}
		else if(type == BUILDING){Tile t = new Building(tiles.size(), collide, color, name);return;}
		
	}
	
	public static void removeTile(){
		int index = tiles.size()-1;
		tiles.remove(index);
	}

	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x * tile.w, y * tile.h, tile);
	}

	public void renderInv(int x, int y, Screen screen){
		screen.renderSprite(x, y, tile);
		Font.drawString(name, x-(name.length()*6)-6, y+4, -16777216, screen);
	}

}
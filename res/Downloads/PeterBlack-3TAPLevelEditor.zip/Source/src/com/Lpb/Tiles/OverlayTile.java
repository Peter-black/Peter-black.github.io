package com.Lpb.Tiles;

import com.Lpb.Editor;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class OverlayTile extends Tile {

	Sprite OverlayLeft, OverlayTop, OverlayRight, OverlayBottom;
	
	public OverlayTile(int id, boolean collide, int color, String name) {
		super(id, collide, color, name);
		int x = (id+1)%16;
		int y = ((id+1)-x)/16;
		OverlayLeft = Sprites.dirtOverlayVert[x*8][y];
		OverlayTop = Sprites.dirtOverlayHorz[id+1][y];
		OverlayRight = Sprites.dirtOverlayVert[(x*8)+7][y];
		OverlayBottom = Sprites.dirtOverlayHorz[id+1][y+7];
	}

	public void render(int x, int y, Screen screen) {	
		screen.renderSprite(x * tile.w, y * tile.h, tile);
		if(Editor.currLevel.getTile(x, y-1) != this){
			screen.renderSprite(x* tile.w, y * tile.h, OverlayTop);
		}
		if(Editor.currLevel.getTile(x+1, y) != this){
			screen.renderSprite(x* tile.w+14, y * tile.h, OverlayRight);
		}
		if(Editor.currLevel.getTile(x, y+1) != this){
			screen.renderSprite(x* tile.w, y * tile.h+14, OverlayBottom);
		}
		if(Editor.currLevel.getTile(x-1, y) != this){
			screen.renderSprite(x* tile.w, y * tile.h, OverlayLeft);
		}
	}
	
}
package com.Lpb.Tiles;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprites;

public class Building extends Tile {
	
	public static int xCoord = 96, yCoord = 64;
	
	public Building(int id, boolean collide, int color, String name) {
		super(id, collide, color, name);

		tile = Sprites.buildings[0][0];
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y , tile);
	}
	
	public void renderInv(int x, int y, Screen screen){
		screen.renderSprite(x, y, x, y, x+16, y+16, tile);
		Font.drawString(name, x-(name.length()*6)-6, y+4, -16777216, screen);
	}
	
}
package com.Lpb.Tiles;

public class ParticleTile extends Tile {
	
	public ParticleTile(int id, boolean collide, int color, String name) {
		super(id, collide, color, name);
	}
}
package com.Lpb.Sprites;

public class Sprites {
	//LEVEL
	public static Sprite[][] terrain = SpriteSheetLoader.cutTiles("/level/terrain.png", 16, 16);
	public static Sprite[][] dirtOverlayVert = SpriteSheetLoader.cutTiles("/level/terrain.png", 2, 16);
	public static Sprite[][] dirtOverlayHorz = SpriteSheetLoader.cutTiles("/level/terrain.png", 16, 2);
	public static Sprite[][] buildings = SpriteSheetLoader.cutTiles("/level/buildings.png", 64, 48);
	public static Sprite[][] level = SpriteSheetLoader.cutTiles("/level/level.png", 16, 16);
	//ITEMS
	public static Sprite[][] items = SpriteSheetLoader.cutTiles("/items/items.png", 32, 16);
	public static Sprite[][] droppedItems = SpriteSheetLoader.cutTiles("/items/items.png", 16, 16);
	public static Sprite[][] jawkModel = SpriteSheetLoader.cutTiles("/items/jawkModel.png", 16, 18);
	public static Sprite[][] SG019Model = SpriteSheetLoader.cutTiles("/items/SG019Model.png", 16, 18);
	public static Sprite[][] knifeModel = SpriteSheetLoader.cutTiles("/items/knifeModel.png", 16, 18);
	public static Sprite[][] knifeSwing = SpriteSheetLoader.cutTiles("/items/knifeSwing.png", 10, 10);
	//FONT
	public static Sprite[][] font = SpriteSheetLoader.cutTiles("/fonts/font.png", 6, 10);
	public static Sprite[][] menuFont = SpriteSheetLoader.cutTiles("/fonts/menuFont.png", 12, 20);
	//GUI
	public static Sprite[][] guiSlots = SpriteSheetLoader.cutTiles("/gui/gui.png", 80, 24);
	//MENU
	public static Sprite[][] menuBg = SpriteSheetLoader.cutTiles("/gui/menubg.png", 480, 270);
	public static Sprite[][] splash = SpriteSheetLoader.cutTiles("/gui/splash.png", 480, 270);
}
package com.Lpb.Entity;

public class Camera {
	public int cX = 40;
	public int cY = 20;
	public double dX = 0;
	public double dY = 0;
	
	public int dirFacing = 0;
	public int lastFacing = 0;
	
	public Camera(){
	}

	public void setDX(double dx){
		dX = dx;
	}
	
	public void setDY(double dy){
		dY = dy;
	}
	
	public double getDX(){
		return dX;
	}
	
	public double getDY(){
		return dY;
	}
	
	public void tick(){		
		if(dX > 0.00)cX += 17 * dX * 0.1;
		if(dX < 0.00)cX += 17 * dX * 0.1;
		if(dY < 0.00)cY += 17 * dY * 0.1;
		if(dY > 0.00)cY += 17 * dY * 0.1;
	}
	
}

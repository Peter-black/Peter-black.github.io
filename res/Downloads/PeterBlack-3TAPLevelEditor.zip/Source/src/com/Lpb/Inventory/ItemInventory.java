package com.Lpb.Inventory;

import com.Lpb.Graphics.Font;
import com.Lpb.Graphics.Screen;

public class ItemInventory {
	public static int itemCount = 0;
	public static int maxItems = 12;
	public static int selectedItem = 0;
	
	public static Item[] inventory = new Item[maxItems];

	public ItemInventory(){	
		inventory[0] = Item.Smg;
		inventory[1] = Item.jawk;
		inventory[2] = Item.knife;
		inventory[3] = Item.KA32;
		inventory[4] = Item.G46;
		inventory[5] = Item.MA19;
		inventory[6] = Item.SG019;
		inventory[7] = Item.healthpack;
		inventory[8] = Item.ammo1;
		inventory[9] = Item.ammo2;
		inventory[10] = Item.ammo3;
		inventory[11] = Item.ammo4;
	}
	
	public void tick(){
		if(selectedItem < 0) selectedItem = maxItems-1;
		if(selectedItem > maxItems-1) selectedItem = 0;
		if(itemCount < 0)itemCount = 0;
		if(itemCount > maxItems)itemCount = maxItems;
	}
	
	public void render(int xPos, int yPos, Screen screen) {
		for(int i = 0; i < maxItems; i++){
			if(inventory[i] != null){
				inventory[i].render(screen.w - 28, (screen.h-12) -i*24, screen);
				Font.drawString(ItemInventory.inventory[i].name, screen.w - 50 - ItemInventory.inventory[i].name.length(), (screen.h-7)-i*24, -1, screen);
			}
		}
	}

}

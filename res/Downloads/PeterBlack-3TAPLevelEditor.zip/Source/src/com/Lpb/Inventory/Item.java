package com.Lpb.Inventory;

import com.Lpb.Graphics.Screen;
import com.Lpb.Sprites.Sprite;
import com.Lpb.Sprites.Sprites;

public class Item {
	public int id;
	public String name;
	
	Sprite sprite;
	Sprite dropped;
	
	public static Item[] items = new Item[13];
	
	//GUNS
	public static Item none = new Item(0, "NONE");
	public static Item Smg = new Item(1, "SMG");
	public static Item jawk = new Item(2, "Jawk");
	public static Item knife = new Item(3, "Knife");
	public static Item KA32 = new Item(4, "KA32");
	public static Item G46 = new Item(5, "G46");
	public static Item MA19 = new Item(6, "MA19");
	public static Item SG019 = new Item(7, "SG019");
	public static Item healthpack = new Item(8, "Health");
	public static Item ammo1 = new Item(9, "ammo1");
	public static Item ammo2 = new Item(10, "ammo2");
	public static Item ammo3 = new Item(11, "ammo3");
	public static Item ammo4 = new Item(12, "ammo4");

	
	public Item(int id, String name){
		this.id = id;
		this.name = name;
		int x = id%8;
		int y = (id-x)/4;
		sprite = Sprites.items[x][y];
		dropped = Sprites.droppedItems[x*2][y+1];
		items[id] = this;
	}
	
	public void render(int x, int y, Screen screen) {
		screen.renderSprite(x, y, sprite);
	}
	
	public void renderDropped(int x, int y, Screen screen) {
		screen.renderSprite(x, y, dropped);
	}
	
}

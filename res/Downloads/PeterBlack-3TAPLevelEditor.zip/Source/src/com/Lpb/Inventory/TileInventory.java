package com.Lpb.Inventory;

import com.Lpb.Graphics.Screen;
import com.Lpb.Tiles.Tile;

public class TileInventory {
	public static int tileCount = 0;
	public static int maxTiles = 10;
	public static int selectedTile = 0;
	
	public static Tile[] inventory = new Tile[maxTiles];

	public TileInventory(){		
	}
	
	public void tick(){
		if(selectedTile < 0) selectedTile = maxTiles-1;
		if(selectedTile > maxTiles-1) selectedTile = 0;
		if(tileCount < 0)tileCount = 0;
		if(tileCount > maxTiles)tileCount = maxTiles;
	}
	
	public static void addTile(Tile tile){
		if(tileCount == maxTiles){
			for(int i = 0; i < maxTiles-1; i++){
				inventory[i] = inventory[i+1];
			}
			inventory[maxTiles-1] = tile;
		}
		for(int i = 0; i < maxTiles; i++){
			if(inventory[i] == null){
				tileCount ++;
				inventory[i] = tile; 
				return;
			}
		}
	}
	
	public void render(int xPos, int yPos, Screen screen) {
		for(int i = 0; i < maxTiles; i++){
			if(inventory[i] != null){
				inventory[i].renderInv(screen.w - 19, (screen.h-28) -i*24, screen);
			}
		}
	}

}

This is the level editor for my first ever game The Tower That Ate People (3TAP). 
It uses a visual interface to place tiles on a map of a size of your choosing
the map can be saved as a .png file. It is also possible to add tiles to the tileset
in the editor.

Controls:

WASD:	Look around
Q:	Tile Chooser Menu
I:	Item Dropper Mode
Mouse:	Paint tiles
Scroll:	Choose Tile
1-3:	Choose Tile
ESC: 	Pause Menu